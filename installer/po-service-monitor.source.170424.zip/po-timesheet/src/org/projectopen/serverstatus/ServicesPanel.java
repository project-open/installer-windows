package org.projectopen.serverstatus;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import org.projectopen.debug.*;


@SuppressWarnings({"unchecked", "rawtypes"})
public class ServicesPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6360295344991781939L;
	private static Logger logger = null;

	// A queue for the last 10 log file sizes, to track advance
	private static long[] aolLogFileSizeArray = new long[10];
	
	/*
	 * The status of the ServicesPanel
	 * Contains available ports, processes, services etc.
	 * which get updated gradually after a refresh.
	 */
	private Map ports = new HashMap();
	private Map processes = new HashMap();
	private Map services = new HashMap();
	
	private Image backgroundImage = new ImageIcon(ServicesPanel.class.getResource("/org/projectopen/serverstatus/background.png")).getImage();
	
	// Action Icons
	final ImageIcon startIconBlue = new ImageIcon(ServicesPanel.class.getResource("/org/projectopen/serverstatus/control_play_blue.png"));
	final ImageIcon startIconGrey = new ImageIcon(ServicesPanel.class.getResource("/org/projectopen/serverstatus/control_play.png"));
	final ImageIcon stopIconBlue = new ImageIcon(ServicesPanel.class.getResource("/org/projectopen/serverstatus/control_stop_blue.png"));
	final ImageIcon stopIconGrey = new ImageIcon(ServicesPanel.class.getResource("/org/projectopen/serverstatus/control_stop.png"));
	final ImageIcon reloadIcon = new ImageIcon(ServicesPanel.class.getResource("/org/projectopen/serverstatus/arrow_refresh.png"));

	private static final String aolserverServiceName = "po-projop";
	private static final Integer aolserverPort = new Integer(8000);
	private static final 	String aolserverProcess = "nsd.exe";
	private HashMap aolserverMap;
	private String aolserverInstalledColor;
	private String aolserverPortColor;
	private String aolserverProcessColor;
	private String aolserverLogColor;
	
	private static final String postgresServiceName = "postgresql-9.2";
	private static final Integer postgresPort = new Integer(5432);
	private static final String postgresProcess = "postgres.exe";
	private HashMap postgresMap;
	private String postgresInstalledColor;
	private String postgresPortColor;
	private String postgresProcessColor;
	private String postgresLogColor;
	
	private static final String eximServiceName = "exim";
	private static final Integer eximPort = new Integer(25);
	private static final String eximProcess = "exim.exe";
	private HashMap eximMap = new HashMap();
	private String eximInstalledColor;
	private String eximPortColor;
	private String eximProcessColor;
	private String eximLogColor;
	
	/**
	 * Overwritten paint method in order to add a background image.
	 */
	public void paintComponent(Graphics g) {
		g.drawImage(backgroundImage, 0, 0, null); //no need for ImageObserver here
	}
	    
    
	/**
	 * Constructor
	 */
	public ServicesPanel(Logger l) {

		// Store the passed logger as the default logger
		logger = l;
		
		// Set 400 x 300 size
		this.setPreferredSize(new Dimension(380,280));
		
		// Setup the grid bag layout of the container
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{10, 80, 5, 5, 5, 100};
		gridBagLayout.rowHeights = new int[]{80, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);

		
		// Initial setup of the panel
		// with "clear" status
    	updateDisplay();
		
    	
		class UpdateWorker extends SwingWorker {
			
			protected String doInBackground() throws Exception {
		    	ports = SystemInterface.busyPorts(logger);
		    	processes = SystemInterface.activePocesses(logger);
		    	services = SystemInterface.installedServices(logger);		
				return "ready";
			}

			protected void done() {
				try	{
			    	updateDisplay();
					// JOptionPane.showMessageDialog(null, get());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		// Start immediately
		new UpdateWorker().execute();
		
		// Schedule a new update every 3 seconds or so.
		int delay = 40000;
		ActionListener taskPerformer = new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
		    	logger.logMessage(Logger.INFO, "Timer", "Starting", "");
		    	new UpdateWorker().execute();
		    }
		};
		javax.swing.Timer timer = new javax.swing.Timer(delay, taskPerformer);
		timer.setRepeats(true);
		timer.start();
	}
	
	
	/*
	 * Update the display.
	 * This function is called every 5 seconds or so from UpdateWorker.
	 */
	private void updateDisplay() {
		
		/* **********************************************************************************
		 * AOLserver Status
		 ***********************************************************************************/
		aolserverMap = new HashMap();
		aolserverInstalledColor = services.containsKey(aolserverServiceName) ? "green" : "red";
		aolserverPortColor = ports.containsKey(aolserverPort) ? "green" : "red";
		aolserverProcessColor = processes.containsKey(aolserverProcess) ? "green" : "red";
		
    	// Array with the last 10 values of log file size
    	for (int i = aolLogFileSizeArray.length-2; i >= 0; i--){
    		aolLogFileSizeArray[i+1] = aolLogFileSizeArray[i];
    	}
    	long len = SystemInterface.naviServerLogFileSize();
    	aolLogFileSizeArray[0] = len;
		aolserverLogColor = "clear";
		if (aolLogFileSizeArray[0] - aolLogFileSizeArray[9] > 0) { aolserverLogColor = "green"; }
		
		// show color for log files too long (and not rolled)
		if (len > (long)1000 * 1000 * 1000) { aolserverLogColor = "yellow"; }
		if (len > (long)1000 * 1000 * 1000 * 10) { aolserverLogColor = "red"; }
		
		
		if (ports.isEmpty()) {
			aolserverInstalledColor = "clear";
			aolserverPortColor = "clear";
			aolserverProcessColor = "clear";
			aolserverLogColor = "clear";
		}
		
		aolserverMap.put("service_name", "AOLserver");
		aolserverMap.put("service_status", "green");
		aolserverMap.put("installed_status", aolserverInstalledColor);
		aolserverMap.put("port_status", aolserverPortColor);
		aolserverMap.put("process_status", aolserverProcessColor);
		aolserverMap.put("log_status", aolserverLogColor);
		aolserverMap.put("service_tooltip", "AOLserver (]project-open[ application server)");


		/***********************************************************************************
		 * PostgreSQL Status
		 ***********************************************************************************/
		
		postgresMap = new HashMap();
		postgresInstalledColor = services.containsKey(postgresServiceName) ? "green" : "red";
		postgresPortColor = ports.containsKey(postgresPort) ? "green" : "red";
		postgresProcessColor = processes.containsKey(postgresProcess) ? "green" : "red";
		postgresLogColor = "clear";
		
		if (ports.isEmpty()) {
			postgresInstalledColor = "clear";
			postgresPortColor = "clear";
			postgresProcessColor = "clear";
			postgresLogColor = "clear";
		}
		postgresMap.put("service_name", "PostgreSQL");
		postgresMap.put("service_status", "green");
		postgresMap.put("installed_status", postgresInstalledColor);
		postgresMap.put("port_status", postgresPortColor);
		postgresMap.put("process_status", postgresProcessColor);
		postgresMap.put("log_status", "clear");
		postgresMap.put("service_tooltip", "PostgreSQL (]project-open[ database server)");

		
		/***********************************************************************************
		 * Exim Status
		 ***********************************************************************************/
		
		eximMap = new HashMap();
		eximInstalledColor = services.containsKey(eximServiceName) ? "green" : "red";
		eximPortColor = ports.containsKey(eximPort) ? "green" : "red";
		eximProcessColor = processes.containsKey(eximProcess) ? "green" : "red";
		eximLogColor = "clear";
		
		if (ports.isEmpty()) {
			eximInstalledColor = "clear";
			eximPortColor = "clear";
			eximProcessColor = "clear";
			eximLogColor = "clear";
		}
		
		eximMap.put("service_name", "Exim");
		eximMap.put("service_status", "yellow");
		eximMap.put("installed_status", eximInstalledColor);
		eximMap.put("port_status", eximPortColor);
		eximMap.put("process_status", eximProcessColor);
		eximMap.put("log_status", "clear");
		eximMap.put("service_tooltip", "Exim (]project-open[ mail server)");

		// Update the actual GUI elements
		updateGUI();
	}
	

	/*
	 * Update the display
	 */
	private void updateGUI() {

		this.removeAll();
		
		// Placeholder on the top
		JPanel placeholderPanel = new JPanel();
		placeholderPanel.setPreferredSize(new Dimension(10,80));
		placeholderPanel.setOpaque(false); // Set transparent
		GridBagConstraints gbc4 = new GridBagConstraints();
		gbc4.gridx = 0;
		gbc4.gridy = 0;
		add(placeholderPanel, gbc4);
		
		/* **********************************************************************************
		 * AOLserver 
		 ***********************************************************************************/
		
		JPanel aolserverPanel = new ServicePanel(logger, aolserverMap);
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.gridy = 1;
		add(aolserverPanel, gbc);

		// Start Button
		JButton btnAOLserverStart = new JButton(startIconBlue);
		btnAOLserverStart.setBorder(BorderFactory.createEmptyBorder());
		btnAOLserverStart.setContentAreaFilled(false);		
		btnAOLserverStart.setToolTipText("Start AOLserver (]project-open[ application server)");
		btnAOLserverStart.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	SystemInterface.startService(logger, aolserverServiceName);
	        }
	    });
		GridBagConstraints gbc_btnAOLserverStart = new GridBagConstraints();
		gbc_btnAOLserverStart.insets = new Insets(5, 0, 5, 0);
		gbc_btnAOLserverStart.gridx = 2;
		gbc_btnAOLserverStart.gridy = 1;
		add(btnAOLserverStart, gbc_btnAOLserverStart);

		btnAOLserverStart.setEnabled(true);

		// Stop Button
		JButton btnAOLserverstop = new JButton(stopIconBlue);
		btnAOLserverstop.setBorder(BorderFactory.createEmptyBorder());
		btnAOLserverstop.setContentAreaFilled(false);
		btnAOLserverstop.setToolTipText("Stop AOLserver (]project-open[ application server)");
		btnAOLserverstop.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	SystemInterface.stopService(logger, aolserverServiceName);
	        }
	    });
		GridBagConstraints gbc_btnAOLserverstop = new GridBagConstraints();
		gbc_btnAOLserverstop.insets = new Insets(5, 0, 5, 0);
		gbc_btnAOLserverstop.gridx = 3;
		gbc_btnAOLserverstop.gridy = 1;
		add(btnAOLserverstop, gbc_btnAOLserverstop);

		btnAOLserverstop.setEnabled(true);


		/***********************************************************************************
		 * PostgreSQL Status
		 ***********************************************************************************/
		
		JPanel postgresPanel = new ServicePanel(logger, postgresMap);
		GridBagConstraints gbc2 = new GridBagConstraints();
		gbc2.gridx = 1;
		gbc2.gridy = 2;
		add(postgresPanel, gbc2);


		// Start Button
		JButton btnpostgresStart = new JButton(startIconBlue);
		btnpostgresStart.setBorder(BorderFactory.createEmptyBorder());
		btnpostgresStart.setContentAreaFilled(false);		
		btnpostgresStart.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	SystemInterface.startService(logger, postgresServiceName);
	        }
	    });
		GridBagConstraints gbc_btnpostgresStart = new GridBagConstraints();
		gbc_btnpostgresStart.insets = new Insets(5, 0, 5, 0);
		gbc_btnpostgresStart.gridx = 2;
		gbc_btnpostgresStart.gridy = 2;
		add(btnpostgresStart, gbc_btnpostgresStart);

		btnpostgresStart.setEnabled(true);

		// Stop Button
		JButton btnpostgresstop = new JButton(stopIconBlue);
		btnpostgresstop.setBorder(BorderFactory.createEmptyBorder());
		btnpostgresstop.setContentAreaFilled(false);		
		btnpostgresstop.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	SystemInterface.stopService(logger, postgresServiceName);
	        }
	    });
		GridBagConstraints gbc_btnpostgresstop = new GridBagConstraints();
		gbc_btnpostgresstop.insets = new Insets(5, 0, 5, 0);
		gbc_btnpostgresstop.gridx = 3;
		gbc_btnpostgresstop.gridy = 2;
		add(btnpostgresstop, gbc_btnpostgresstop);

		btnpostgresstop.setEnabled(true);
		
		/***********************************************************************************
		 * Exim Status
		 ***********************************************************************************/
/*		
		JPanel eximPanel = new ServicePanel(eximMap);
		GridBagConstraints gbc3 = new GridBagConstraints();
		gbc3.gridx = 1;
		gbc3.gridy = 3;
		add(eximPanel, gbc3);
		
		// Start Button
		JButton btneximStart = new JButton(startIconBlue);
		btneximStart.setBorder(BorderFactory.createEmptyBorder());
		btneximStart.setContentAreaFilled(false);		
		btneximStart.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	SystemInterface.startService(logger, eximServiceName);
	        }
	    });
		GridBagConstraints gbc_btneximStart = new GridBagConstraints();
		gbc_btneximStart.insets = new Insets(5, 0, 5, 0);
		gbc_btneximStart.gridx = 2;
		gbc_btneximStart.gridy = 3;
		add(btneximStart, gbc_btneximStart);

		btneximStart.setEnabled(true);

		// Stop Button
		JButton btneximstop = new JButton(stopIconBlue);
		btneximstop.setBorder(BorderFactory.createEmptyBorder());
		btneximstop.setContentAreaFilled(false);		
		btneximstop.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	SystemInterface.stopService(logger, eximServiceName);
	        }
	    });
		GridBagConstraints gbc_btneximstop = new GridBagConstraints();
		gbc_btneximstop.insets = new Insets(5, 0, 5, 0);
		gbc_btneximstop.gridx = 3;
		gbc_btneximstop.gridy = 3;
		add(btneximstop, gbc_btneximstop);

		btneximstop.setEnabled(true);

*/
		
		/***********************************************************************************
		 * JTextArea with the bottom text.
		 ***********************************************************************************/
		
		final JTextArea textArea = new JTextArea("You are running the ]po[ 5.0 community edition:\n" +
				" � Based on 32 bit code,\n" +
				" � suitable for small and medium enterprises,\n" +
				" � without support and \n" +
				" � without enterprise packages.\n" +
				"Please contact info@project-open.com for pro & enterprise editions\n" +
				"");
		textArea.setEditable(false);
		textArea.setBounds(10, 152, 456, 255);
		// textArea.setBorder(border);
		textArea.setLineWrap(true);		
		textArea.setForeground(new Color(0,0,153));
		Font font = new Font("Arial", Font.PLAIN, 12);
		textArea.setFont(font);
		textArea.setOpaque(false);
		
		GridBagConstraints gbc_messageLabel = new GridBagConstraints();
		gbc_messageLabel.insets = new Insets(5,5,5,5);
		gbc_messageLabel.gridx = 1;
		gbc_messageLabel.gridy = 4;
		gbc_messageLabel.gridwidth = 4;
		
		add(textArea, gbc_messageLabel);
		
		
		
		/***********************************************************************************
		 * JEditorPane with the bottom text.
		 ***********************************************************************************/
		
		JEditorPane editorPane = new JEditorPane();
		editorPane.setEditable(false);
		
		java.net.URL indexURL = ServicesPanel.class.getResource("/org/projectopen/serverstatus/service-monitor/index.html");
		if (indexURL != null) {
		    try {
		        editorPane.setPage(indexURL);
		    } catch (IOException e) {
		        System.err.println("Attempted to read a bad URL: " + indexURL);
		    }
		} else {
		    System.err.println("Couldn't find file: "+indexURL);
		}

		//Put the editor pane in a scroll pane.
		JScrollPane editorScrollPane = new JScrollPane(editorPane);
		editorScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		// add(editorPane, gbc_messageLabel);
		
		
		
		/***********************************************************************************
		 * Redraw the panel
		 ***********************************************************************************/
		
		// tell the component to repaint
		this.revalidate();
		this.repaint();
	}

	
	
}
