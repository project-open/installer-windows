package org.projectopen.serverstatus;

import java.io.*;
import java.net.*;
import java.util.*;

import org.projectopen.debug.Logger;
import org.projectopen.debug.SystemLogger;
import org.projectopen.winservice.*;

import com.sun.jna.platform.win32.Advapi32Util;
import static com.sun.jna.platform.win32.WinReg.HKEY_LOCAL_MACHINE;


public class SystemInterface {
	
	
	public static int startService(Logger logger, String serviceName) {
		String cmd = "sc start " + serviceName;
		
		WinClient cli = new WinClient();
		cli.exec(cmd);
		if (0 != cli.getReturnCode()) {
			logger.logMessage(Logger.ERROR, cmd, cli.getServerResponse(), "");
		}
		cli.close();
		
/*		
	    String line = null;
		Process process = null;
		int returnCode;
		int logLevel = Logger.INFO;
		StringBuffer errorMessageBuffer = new StringBuffer();
		try {
		    process = Runtime.getRuntime().exec(cmd);
		    BufferedReader input = new BufferedReader(new InputStreamReader(process.getInputStream()), 13107200);
		    while ((line = input.readLine()) != null) {
		    	if (0 == line.length()) { continue; }
		    	errorMessageBuffer.append(line).append("\n"); 
		    }
		    
		    try {
		    	returnCode = process.waitFor();
		    	if (returnCode > 0) { logLevel = Logger.ERROR; }
		    	logger.logMessage(logLevel, cmd, errorMessageBuffer.toString(), "");
	        } catch (InterruptedException e) {
	        	e.printStackTrace();
	        }
		} catch (Exception e) {
		    e.printStackTrace(System.err);
		}
*/		
		return 0;
	}

	public static int stopService(Logger logger, String serviceName) {
		String cmd = "sc stop " + serviceName;
		
		WinClient cli = new WinClient();
		cli.exec(cmd);
		if (0 != cli.getReturnCode()) {
			logger.logMessage(Logger.ERROR, cmd, cli.getServerResponse(), "");
		}
		cli.close();
		
/*		
	    String line = null;
		Process process = null;
		int returnCode;
		int logLevel = Logger.INFO;
		StringBuffer errorMessageBuffer = new StringBuffer();
		try {
		    process = Runtime.getRuntime().exec(cmd);
		    BufferedReader input = new BufferedReader(new InputStreamReader(process.getInputStream()), 13107200);
		    while ((line = input.readLine()) != null) {
		    	if (0 == line.length()) { continue; }
		    	errorMessageBuffer.append(line).append("\n"); 
		    }
		    
		    try {
		    	returnCode = process.waitFor();
		    	if (returnCode > 0) { logLevel = Logger.ERROR; }
		    	logger.logMessage(logLevel, cmd, errorMessageBuffer.toString(), "");
	        } catch (InterruptedException e) {
	        	e.printStackTrace();
	        }
		} catch (Exception e) {
		    e.printStackTrace(System.err);
		}
*/		
		return 0;
	}
	

	
	/*
	 * Get the list of ports that are busy on this machine.
	 * Parses the output of "netstat -ano".
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static HashMap busyPorts(Logger logger) {
		final String cmd = "netstat -ano";
		HashMap result = new HashMap();
		Process process = null;
		try {
		    /* Run netstat - produces an output like this:
			 * Active Connections
			 *
			 * Proto  Local Address          Foreign Address        State           PID
			 * TCP    0.0.0.0:80             0.0.0.0:0              LISTENING       4308
			 * TCP    0.0.0.0:135            0.0.0.0:0              LISTENING       1072
			 * TCP    0.0.0.0:443            0.0.0.0:0              LISTENING       4308
			 */
		    process = Runtime.getRuntime().exec(cmd);
		} catch (Exception e) {
		    e.printStackTrace(System.err);
		}
		
		// Parse the netstat output line by line
		InputStream stream = process.getInputStream();
		java.util.Scanner s = new java.util.Scanner(stream).useDelimiter("\\r\\n");
		while (s.hasNext()) {
			String str = s.next();
        	// logger.logMessage(Logger.INFO, "netstat", str, "");        	
        	String[] strings = str.split("\\s+");
        	
        	/* Only get active if there are 5 elements:
        	 * 0 - empty string (leading spaces)
        	 * 1 - Proto
        	 * 2 - Local Address
        	 * 3 - Foreign Address
        	 * 4 - State
        	 * 5- PID
        	 */ 
        	// Make sure there are all 6 pieces
        	if (6 != strings.length) { continue; }
        	
        	// Protocol = TCL
        	if (!strings[1].equals("TCP")) { continue; }
        	
        	// Foreign address is "0.0.0.0:0"
        	if (!strings[3].equals("0.0.0.0:0")) { continue; }
        	
        	// Get the port number from #2
        	String[] ip_port = strings[2].split(":");
        	Integer port = new Integer(ip_port[1]);
        	result.put(port, port);
		}
		

		return result;
	}
	
	
	
	/*
	 * Get the list of services installed on this machine.
	 * Parses the output of "sc query
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static HashMap installedServices(Logger logger) {
		final String cmd = "sc queryex state= all";
		HashMap result = new HashMap();
		Process process = null;
		
		String serviceName = null;
		String displayName = null;
		String state = null;
		String key, value;
		
		try {
		    /* Run sc produces an output like this:
		     * 
			 * SERVICE_NAME: AOLserver-projop
			 * DISPLAY_NAME: ]po[ AOLserver Projop
        	 * TYPE               : 10  WIN32_OWN_PROCESS
        	 * STATE              : 1  STOPPED
        	 * WIN32_EXIT_CODE    : 1067  (0x42b)
        	 * SERVICE_EXIT_CODE  : 0  (0x0)
        	 * CHECKPOINT         : 0x0
        	 * WAIT_HINT          : 0x0
        	 * PID                : 0
        	 * FLAGS              :
			 */
		    process = Runtime.getRuntime().exec(cmd);
		} catch (Exception e) {
		    e.printStackTrace(System.err);
		}
		
		// Parse the netstat output line by line
		InputStream stream = process.getInputStream();
		java.util.Scanner s = new java.util.Scanner(stream).useDelimiter("\\r\\n");
		
		int lineCount = 0;
		while (s.hasNext()) {
			String str = s.next().trim().toLowerCase();
        	// logger.logMessage(Logger.INFO, "netstat", lineCount + " : " + str, "");        	
        	String[] strings = str.split(":");
        	 
        	// reset the line counter after an empty line
        	if ("".equals(str)) { 
        		lineCount = 0;
        		continue;
        	}
        	
        	// Make sure there are all 6 pieces
        	if (2 != strings.length) { continue; }
        	key = strings[0].trim();
        	value = strings[1].trim();
        	
        	// line 0 => service name, 
        	// line 1 => display name
        	// line 3 => status
        	if (0 == lineCount) { serviceName = value; }
        	if (1 == lineCount) { displayName = value; }
        	if (3 == lineCount) { 
        		state = value.substring(0, 1);
        		
        		// Write into result
        		result.put(serviceName, state);
        		logger.logMessage(Logger.INFO, "netstat", serviceName + " -> " + state, "");
        	}
        	lineCount++;
		}
		return result;
	}
	
	
	/*
	 * Get the list of processes running on this machine.
	 * Parses the output of "tasklist /V /FO CSV".
	 */
	public static HashMap activePocesses(Logger logger) {
		final String cmd = "tasklist /V /FO CSV";
		HashMap result = new HashMap();
		Process process = null;
		try {
		    /* Run tasklist /V /FO CSV - produces an output like this:
			 * "Image Name","PID","Session Name","Session#","Mem Usage","Status","User Name","CPU Time","Window Title"
			 * "System Idle Process","0","Services","0","24 K","Unknown","NT AUTHORITY\SYSTEM","40:31:37","N/A"
			 * "System","4","Services","0","328 K","Unknown","N/A","0:05:56","N/A"
			 * "smss.exe","488","Services","0","120 K","Unknown","N/A","0:00:01","N/A"
			 */
		    process = Runtime.getRuntime().exec(cmd);
		} catch (Exception e) {
		    e.printStackTrace(System.err);
		}
		
		// Parse the output line by line
		InputStream stream = process.getInputStream();
		java.util.Scanner s = new java.util.Scanner(stream).useDelimiter("\\r\\n");
		while (s.hasNext()) {
			String str = s.next();
        	// logger.logMessage(Logger.INFO, "tasklist", str, "");        	
        	String[] strings = str.split(",");
        	
        	// Make sure there are all 9 columns
        	if (9 > strings.length) { continue; }
        	        	
        	// Get the port number from #2
        	String image = strings[0].replaceAll("\"", "");
        	result.put(image, image);
		}
		
		return result;
	}
	
	
	/*
	 * Where is the log file located for AOLserver?
	 */
	public static String aolServerLogFile() {
		String cygDir = Advapi32Util.registryGetStringValue(HKEY_LOCAL_MACHINE, "SOFTWARE\\Cygwin\\setup", "rootdir");
		String cygDirLinux = cygDir.replace("\\", "/");
		String logDir = cygDirLinux + "/servers/projop/log";
		return logDir + "/" + "error.log";
	}	
	
	/*
	 * Size of the logfile - check that it's advancing...
	 */
	public static long naviServerLogFileSize() {
		String logFile = aolServerLogFile();
		
		java.io.File file = new java.io.File(logFile);
		long len = file.length();
		return len;
	}	
	
	
	/*
	 * Get the list of processes running on this machine.
	 * Parses the output of "tasklist /V /FO CSV".
	 */
	public static HashMap parseAolserverLogfile(Logger logger) {
		String logFile = aolServerLogFile();
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(logFile));

			String line;
			int ctr = 0;
			while ((line = br.readLine()) != null) {
				// process the line.
				System.out.println(line);
				ctr = ctr + 1;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
		
	
	/**
	 * Main Procedure
	 * 
	 * Test some of the system interfaces
	 */
	public static void main(String[] args) {
		Logger logger = new SystemLogger();
		HashMap installedProcesses = installedServices(logger);
		
		String logFile = aolServerLogFile();
		System.out.println(logFile);
		
		java.io.File file = new java.io.File(logFile);
		long len = file.length();
		System.out.println("len = "+len);
		
		//HashMap aolIssues = parseAolserverLogfile(logger);		
		/*
    	HashMap ports = SystemInterface.busyPorts(logger);
    	HashMap processes = SystemInterface.activePocesses(logger);
    	*/
    	
	}

}
