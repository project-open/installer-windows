/**
 * 
 */
/**
 * @author fraber
 *
 */
package org.projectopen.serverstatus;