package org.projectopen.serverstatus;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import org.projectopen.debug.*;


@SuppressWarnings({"unchecked", "rawtypes"})
public class ServicesPanel50 extends JPanel {
	
	private static final long serialVersionUID = 6360295344991781939L;
	private static Logger logger = null;
	private long[] naviServerLastLogFileSize = new long[20];
	
	/*
	 * The status of the ServicesPanel
	 * Contains available ports, processes, services etc.
	 * which get updated gradually after a refresh.
	 */
	private Map ports = new HashMap();
	private Map processes = new HashMap();
	private Map services = new HashMap();
	
	private Image backgroundImage = new ImageIcon(ServicesPanel50.class.getResource("/org/projectopen/serverstatus/service-monitor/img/background.png")).getImage();
	public int backgroundWidth = backgroundImage.getWidth(null);
	public int backgroundHeight = backgroundImage.getHeight(null);
	
	// Action Icons
	final ImageIcon startIconBlue = new ImageIcon(ServicesPanel50.class.getResource("/org/projectopen/serverstatus/service-monitor/img/Start1_32.png"));
	final ImageIcon startIconGrey = new ImageIcon(ServicesPanel50.class.getResource("/org/projectopen/serverstatus/service-monitor/img/Start1_32.png"));
	final ImageIcon stopIconBlue = new ImageIcon(ServicesPanel50.class.getResource("/org/projectopen/serverstatus/service-monitor/img/Stop1_32.png"));
	final ImageIcon stopIconGrey = new ImageIcon(ServicesPanel50.class.getResource("/org/projectopen/serverstatus/service-monitor/img/Stop1_32.png"));

	private static final String naviServerServiceName = "po-projop";
	private static final Integer naviServerPort = new Integer(8000);
	private static final String naviServerProcess = "nsd.exe";
	private HashMap naviServerMap;
	private String naviServerInstalledColor;
	private String naviServerPortColor;
	private String naviServerProcessColor;
	private String naviServerLogColor;
	
	private static final String postgresServiceName = "postgresql-9.2";
	private static final Integer postgresPort = new Integer(5432);
	private static final String postgresProcess = "postgres.exe";
	private HashMap postgresMap;
	private String postgresInstalledColor;
	private String postgresPortColor;
	private String postgresProcessColor;
	private String postgresLogColor;
	
	/**
	 * Overwritten paint method in order to add a background image.
	 */
	public void paintComponent(Graphics g) {
		g.drawImage(backgroundImage, 0, 0, backgroundWidth, backgroundHeight, null); //no need for ImageObserver here
	}
	    
    
	/**
	 * Constructor
	 */
	public ServicesPanel50(Logger l) {

		// Store the passed logger as the default logger
		logger = l;
		
		// Set size depending on background image
		this.setPreferredSize(new Dimension(backgroundWidth-10, backgroundHeight));
		setBackground(Color.red);
	    setForeground(Color.pink);
		
		// Setup the grid bag layout of the container
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{80, 80, 80, 80};
		gridBagLayout.rowHeights = new int[]{30, 30, 30, 30};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		setLayout(null);
		
		
		// Initial setup of the panel with "clear" status
    	updateDisplay();
		
    	
		class UpdateWorker extends SwingWorker {
			
			protected String doInBackground() throws Exception {
		    	ports = SystemInterface.busyPorts(logger);
		    	processes = SystemInterface.activePocesses(logger);
		    	services = SystemInterface.installedServices(logger);		
				return "ready";
			}

			protected void done() {
				try	{
			    	updateDisplay();
					// JOptionPane.showMessageDialog(null, get());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		// Start immediately
		new UpdateWorker().execute();
		
		// Schedule a new update every 1 seconds or so.
		int delay = 1000;
		ActionListener taskPerformer = new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
		    	logger.logMessage(Logger.INFO, "Timer", "Starting", "");
		    	new UpdateWorker().execute();
		    }
		};
		javax.swing.Timer timer = new javax.swing.Timer(delay, taskPerformer);
		timer.setRepeats(true);
		timer.start();
		
        MouseListener mouseListener = new MouseListener() {
            public void mouseClicked(MouseEvent e) {
            	int mouseX = e.getX();
            	int mouseY = e.getY();
                switch (e.getButton()) {
            		case 1: {
            			System.out.println("ServicePanel50: clicked: x="+mouseX+", y="+mouseY);
            			if (mouseY < 160) {		// clicked into the upper part of the display
            				if (mouseX < 153) {  
            					// clicked into the logo / community edition area
            					this.browserUrl("http://www.project-open.com/en/products/editions.html");
            				}
            			} else {
            				if (mouseX < backgroundWidth / 3) { 
            					// left icon - "Assistance"
            					this.browserUrl("http://www.project-open.com/en/services/project-open-support.html");
            					return;
            				}
            				if (mouseX > 2 * backgroundWidth / 3) {
            					// right icon - "Enterprise"
            					this.browserUrl("http://www.project-open.com/en/products/editions.html");
            					return;
            				}
            				// middle icon - "SaaS Hosting"
            				this.browserUrl("http://www.project-open.com/en/services/project-open-hosting-saas.html");
            				return;
            			}
            		}
            	}
            }
        	private void browserUrl(String url) {
        		if (!Desktop.isDesktopSupported()) return;
        		try {
        			Desktop.getDesktop().browse(new URI(url));
        		} catch (IOException e1) {
        			// TODO Auto-generated catch block
        			e1.printStackTrace();
        		} catch (URISyntaxException e1) {
        			// TODO Auto-generated catch block
        			e1.printStackTrace();
        		}
        	}
        	
			public void mouseEntered(MouseEvent e) { }
            public void mouseExited(MouseEvent e) {  }
            public void mousePressed(MouseEvent e) { }
            public void mouseReleased(MouseEvent e) { }
        };
		
        this.addMouseListener(mouseListener);
	}
	
	
	/*
	 * Update the display.
	 * This function is called every 5 seconds or so from UpdateWorker.
	 */
	private void updateDisplay() {
		
		/* **********************************************************************************
		 * NaviServer Status
		 ***********************************************************************************/
		naviServerMap = new HashMap();
		naviServerInstalledColor = services.containsKey(naviServerServiceName) ? "green" : "red";
		naviServerPortColor = ports.containsKey(naviServerPort) ? "green" : "red";
		naviServerProcessColor = processes.containsKey(naviServerProcess) ? "green" : "red";
		
    	// Calculate log file size change
		naviServerLogColor = "clear";
		int arrayLen = naviServerLastLogFileSize.length;
    	long len = SystemInterface.naviServerLogFileSize();
		if (len - naviServerLastLogFileSize[arrayLen-1] > 0) { naviServerLogColor = "green"; }
		for (int i = arrayLen-2; i >= 0; i--) {
			naviServerLastLogFileSize[i+1] = naviServerLastLogFileSize[i];
		}
		naviServerLastLogFileSize[0] = len;
		// show color for log files too long (and not rolled)
		if (len > (long)1000 * 1000 * 1000) { naviServerLogColor = "yellow"; }
		if (len > (long)1000 * 1000 * 1000 * 10) { naviServerLogColor = "red"; }
		
		
		if (ports.isEmpty()) {
			naviServerInstalledColor = "clear";
			naviServerPortColor = "clear";
			naviServerProcessColor = "clear";
			naviServerLogColor = "clear";
		}
		
		naviServerMap.put("service_pretty", "NaviServer");
		naviServerMap.put("service_name", "po-projop");
		naviServerMap.put("service_status", "green");
		naviServerMap.put("installed_status", naviServerInstalledColor);
		naviServerMap.put("port_status", naviServerPortColor);
		naviServerMap.put("process_status", naviServerProcessColor);
		naviServerMap.put("log_status", naviServerLogColor);
		naviServerMap.put("service_tooltip", "NaviServer (application server)");


		/***********************************************************************************
		 * PostgreSQL Status
		 ***********************************************************************************/
		
		postgresMap = new HashMap();
		postgresInstalledColor = services.containsKey(postgresServiceName) ? "green" : "red";
		postgresPortColor = ports.containsKey(postgresPort) ? "green" : "red";
		postgresProcessColor = processes.containsKey(postgresProcess) ? "green" : "red";
		postgresLogColor = "clear";
		
		if (ports.isEmpty()) {
			postgresInstalledColor = "clear";
			postgresPortColor = "clear";
			postgresProcessColor = "clear";
			postgresLogColor = "clear";
		}
		postgresMap.put("service_pretty", "PostgreSQL");
		postgresMap.put("service_name", "postgresql-9.2");
		postgresMap.put("service_status", "green");
		postgresMap.put("installed_status", postgresInstalledColor);
		postgresMap.put("port_status", postgresPortColor);
		postgresMap.put("process_status", postgresProcessColor);
		postgresMap.put("log_status", "clear");
		postgresMap.put("service_tooltip", "PostgreSQL (database server)");

		this.removeAll();
			
		// Panels for NaviServer and PostgreSQL
		JPanel naviServerPanel = new ServicePanel(logger, naviServerMap);
		JPanel postgresPanel = new ServicePanel(logger, postgresMap);

		// Add panels to pane
		naviServerPanel.setSize(80,150);
		naviServerPanel.setLocation(161, 5);
		this.add(naviServerPanel);
		
		postgresPanel.setSize(80,148);
		postgresPanel.setLocation(241, 5);		
		this.add(postgresPanel);
		
		/***********************************************************************************
		 * Redraw the panel
		 ***********************************************************************************/
		
		// tell the component to repaint
		this.revalidate();
		this.repaint();
	}

	
	
}
