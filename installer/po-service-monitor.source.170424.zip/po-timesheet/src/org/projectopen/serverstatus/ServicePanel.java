/**
 * 
 */
package org.projectopen.serverstatus;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import org.projectopen.debug.*;

/**
 * @author fraber
 *
 */
public class ServicePanel extends JPanel implements Logger {

	/**
	 * This is a small vertical panel in BoxLayout 
	 * that show the status of a Windows service 
	 * based on a number of parameters passed as a Map.
	 */
	private static final long serialVersionUID = 6360295344991781929L;
	private static Logger logger = null;

	public ServicePanel(Logger l, Map map) {
		super();						// Setup the panel 
		this.logger = l;
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));      // vertical 

		// Set transparent background
		this.setOpaque(false);
		
		// Extract the interesting values from the map
		String servicePretty = map.containsKey("service_pretty") ? (String)map.get("service_pretty") : "undefined";
		String serviceName = map.containsKey("service_name") ? (String)map.get("service_name") : "undefined";
		String toolTipText = map.containsKey("service_tooltip") ? (String)map.get("service_tooltip") : "undefined";
		String installStatus = map.containsKey("installed_status") ? (String)map.get("installed_status") : "clear";
		String processStatus = map.containsKey("process_status") ? (String)map.get("process_status") : "clear";
		String portStatus = map.containsKey("port_status") ? (String)map.get("port_status") : "clear";
		String logStatus = map.containsKey("log_status") ? (String)map.get("log_status") : "clear";
		
		// calculate service status as a summary of individual states
		String serviceStatus = "green";
		if ("orange" == installStatus | "orange" == processStatus | "orange" == portStatus | "orange" == logStatus) { serviceStatus = "orange"; }
		if ("red" == installStatus | "red" == processStatus | "red" == portStatus | "red" == logStatus) { serviceStatus = "red"; }

		
		// Global Status + Service Description
		JLabel serviceLabel = new JLabel(servicePretty);
		serviceLabel.setToolTipText(toolTipText);
		serviceLabel.setFont(new Font("",0,12));
		serviceLabel.setHorizontalTextPosition(JLabel.CENTER);
		serviceLabel.setVerticalTextPosition(JLabel.CENTER);
		serviceLabel.setAlignmentX(Component.CENTER_ALIGNMENT );
		serviceLabel.setBorder(new EmptyBorder(5,5,5,5));
		this.add(serviceLabel);

		// Start/Stop Sub-Panel
		Panel startStopPanel = new Panel();
		startStopPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 1, 1));
		
		// Start Button
		ImageIcon startIcon = new ImageIcon(ServicesPanel50.class.getResource("/org/projectopen/serverstatus/service-monitor/img/Start1_32.png"));
		JButton btnAOLserverStart = new JButton(startIcon);
		// btnAOLserverStart.setBorder(BorderFactory.createEmptyBorder());
		btnAOLserverStart.setBorder(BorderFactory.createEmptyBorder());
		btnAOLserverStart.setContentAreaFilled(false);		
		btnAOLserverStart.setToolTipText("Start "+toolTipText);
		btnAOLserverStart.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	SystemInterface.startService(logger, serviceName);
	        }
	    });
		btnAOLserverStart.setEnabled(true);
		startStopPanel.add(btnAOLserverStart);

		// Stop Button
		ImageIcon stopIcon = new ImageIcon(ServicesPanel50.class.getResource("/org/projectopen/serverstatus/service-monitor/img/Stop2_32.png"));	
		JButton btnAOLserverStop = new JButton(stopIcon);
		btnAOLserverStop.setBorder(BorderFactory.createEmptyBorder());
		//btnAOLserverStop.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		btnAOLserverStop.setContentAreaFilled(false);
		btnAOLserverStop.setToolTipText("Stop "+toolTipText);
		btnAOLserverStop.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	SystemInterface.stopService(logger, serviceName);
	        }
	    });
		btnAOLserverStop.setEnabled(true);
		startStopPanel.add(btnAOLserverStop);
		startStopPanel.setPreferredSize(startStopPanel.getMinimumSize());
		startStopPanel.validate();
		this.add(startStopPanel);
		
		
		// Install Status
		ImageIcon installedIcon = new ImageIcon(ServicesPanel.class.getResource("/org/projectopen/serverstatus/service-monitor/img/status_" + installStatus + ".png"));
		JLabel installLabel = new JLabel(installedIcon);
		installLabel.setAlignmentX( Component.CENTER_ALIGNMENT );
		installLabel.setBorder(new EmptyBorder(1,1,1,1));
		this.add(installLabel);

		// Process Status
		ImageIcon processIcon = new ImageIcon(ServicesPanel.class.getResource("/org/projectopen/serverstatus/service-monitor/img/status_" + processStatus + ".png"));
		JLabel processLabel = new JLabel(processIcon);
		processLabel.setAlignmentX( Component.CENTER_ALIGNMENT );
		processLabel.setBorder(new EmptyBorder(1,1,1,1));
		this.add(processLabel);

		// Port Status
		ImageIcon portIcon = new ImageIcon(ServicesPanel.class.getResource("/org/projectopen/serverstatus/service-monitor/img/status_" + portStatus + ".png"));
		JLabel portLabel = new JLabel(portIcon);
		portLabel.setAlignmentX( Component.CENTER_ALIGNMENT );
		portLabel.setBorder(new EmptyBorder(1,1,1,1));
		this.add(portLabel);

		// log Status
		ImageIcon logIcon = new ImageIcon(ServicesPanel.class.getResource("/org/projectopen/serverstatus/service-monitor/img/status_" + logStatus + ".png"));
		JLabel logLabel = new JLabel(logIcon);
		logLabel.setAlignmentX( Component.CENTER_ALIGNMENT );
		logLabel.setBorder(new EmptyBorder(1,1,1,1));
		this.add(logLabel);

	}
	
	/* (non-Javadoc)
	 * @see org.projectopen.debug.Logger#logMessage(int, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public void logMessage(int level, String domain, String message, String details) {
		// TODO Auto-generated method stub
		System.out.println("Message: "+message);
		System.out.println("Details: "+details);
	}

	/**
	 * @param args
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) {
		
		HashMap map = new HashMap();
		map.put("service_name", "AOLserver");
		map.put("service_status", "green");
		map.put("port_status", "yellow");
		map.put("process_status", "clear");
		map.put("port_status", "yellow");

		// Launch a frame with the panel
        JFrame frame = new JFrame("Single Service Panel");
        frame.setBounds(0, 0, 400, 300);

		JPanel p = new ServicePanel(logger, map);
        frame.getContentPane().add(p);

        frame.setVisible(true);
		
	}

}
