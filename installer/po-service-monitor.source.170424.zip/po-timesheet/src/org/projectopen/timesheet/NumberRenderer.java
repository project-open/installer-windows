package org.projectopen.timesheet;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 *  @author Frank Bergmann (frank.bergmann@project-open.com)
 */


import java.awt.Component;
import java.text.NumberFormat;
import java.util.Locale;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * 
 * Slightly customized TableCellRenderer that prints out
 * numbers right-aligned and with US-American locale format,
 * to be consistent with the ]project-open[ Web application.
 * 
 * @author Frank Bergmann 
 *
 */
public class NumberRenderer extends DefaultTableCellRenderer {
	private static final long serialVersionUID = -4523810862313323910L;
	NumberFormat formatter;
	
    public NumberRenderer() { 
    	super(); 
    }

    /*
     * Modify the formatting rules to use a US American locale
     */
    public void setValue(Object value) {
    	// formatter = null;
        if (formatter==null) {
            formatter = NumberFormat.getInstance(Locale.US);
            formatter.setMinimumFractionDigits(1);
        }
        setText((value == null) ? "" : formatter.format(value));
    }
    
    /*
     * Make sure the result is right aligned
     */
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    	JLabel renderedLabel = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
    	renderedLabel.setHorizontalAlignment(SwingConstants.RIGHT);
    	return renderedLabel;
    }
    
}