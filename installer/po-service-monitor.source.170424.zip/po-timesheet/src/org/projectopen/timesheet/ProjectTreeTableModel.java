package org.projectopen.timesheet;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import org.projectopen.rest.*;
import org.projectopen.treetable.AbstractTreeTableModel;
import org.projectopen.treetable.TreeTableModel;


/**
 * Data model for JTreeTable.
 * This class basically delegates getValueAt and setValueAt calls
 * from the JTreeTable to the REST interface, apart from interfacing
 * with the project hierarchy.
 */
public class ProjectTreeTableModel extends AbstractTreeTableModel implements TreeTableModel {

    static protected String[] cNames = {"Name", "Hours", "Note"};
	static protected Class[] cTypes = {TreeTableModel.class, Float.class, String.class};
	
    // hours logged today by the current user,
    // represented by a Hash from project_id to hours.
	private Hashtable<Integer,ProjopObject> loggedHoursToday = null;
	
	public ProjectTreeTableModel() {
		super(new ProjopProject());
		System.out.println("ProjectTreeTableModel.ProjectTreeTableModel");
		initialize();
	}
	
	private void initialize() {
		System.out.println("ProjectTreeTableModel.initialize");

        // create a dummy project at the top of the tree
        root = new ProjopProject();
        ((ProjopObject)root).set("project_name", "]project-open[ Projects");

		// here we will store the last parents of each level,
		// in order to create a hierarchy of projects.
        ProjopObject[] node = new ProjopObject[1000];
        node[0] = ((ProjopObject)root);

        // count the level of depth of the projects.
        int level;

        // get the list of projects to which the current user can
        // log hours.
        List<ProjopObject> projects = ProjopProject.myTimesheetProjects();

        // go through the list and add them to the project hierarchy
        Iterator<ProjopObject> itr = projects.iterator(); 
        while(itr.hasNext()) {

        	// get the next project
            ProjopObject p = itr.next(); 

            // Main-Projects in ]po[ have level=0, but here they are
            // level=1, because the are located below the ficticous
            // "]project-open[ Projects" node which occupies level=0
            level = 1 + p.getInt("level");
            
            // Set the parent as the project one above in the hierarchy
            p.setParent(node[level-1]);

            // set the new projectNode as the parent for the next projects..
            node[level] = p;
 
            // add this project to the list of parent's children
            node[level-1].getChildObjects().add(p);
        }
	    
		System.out.println("ProjectTreeTableModel.initialize end");
	}
	
	public Class getColumnClass(int column) {
		return cTypes[column];
	}

	public int getColumnCount() {
		return cTypes.length;
	}

	public String getColumnName(int column) {
		return cNames[column];
	}

	public Object getValueAt(Object node, int column) {
		int projectId = ((ProjopObject)node).getObjectId();
		ProjopObject h = cacheGetHourForProject(projectId);
    
	    switch(column) {
	    	case 0:	{
	    		// return a string with the name of the project.
	    		if (projectId == 0) { return ""; }
	    		return node.toString();
	    	}
	    	case 1:	{
	    		// return the number of hours logged
	    		if (h != null) {
	    			String hoursString = h.get("hours");
	    			if ("" != hoursString) {
	    				return new Double(hoursString);
	    			}
	    		}
	    		return null;
	    	}
	    	case 2:	{
	    		if (h != null) {
	    			return h.get("note");
	    		}
	    		return null;
	    	}
	    }
	    return null;
	}

    
   	/**
   	 * Query the REST server for 
   	 * @param projectId
   	 * @return
   	 */
	private ProjopObject cacheGetHourForProject(int projectId) {
    	if (loggedHoursToday == null) {
			loggedHoursToday = new Hashtable<Integer,ProjopObject>();
			List<ProjopObject> hours = ProjopHour.fromToday();	// get the list of all hours logged by the current user today
	        Iterator<ProjopObject> itr = hours.iterator(); 
	        while(itr.hasNext()) {
	        	ProjopObject h = (ProjopObject) itr.next(); 		// get the next Hour object
	            Integer pId = Integer.parseInt(h.get("project_id"));// extract the project_id from the Hour object
				loggedHoursToday.put(pId, h);	            	// write the object into the cache	            
	        }			
		}

    	// myHours now contains the list of all hours logged today by the current user.
    	Integer key = new Integer(projectId);
    	ProjopObject loggedHour = (ProjopObject)loggedHoursToday.get(key);
    	return loggedHour;
	}  
	
    
    /**
     * Write the updated values for either "hours" or "comment"
     * to the local cache and then "write through" to the REST
     * server. 
     */
   	public void cacheUpdateHourForProject(String column, int projectId, Object value) {
   		RESTClient rest = RESTClient.defaultInstance();
   		if (null == value) { value = ""; }		// avoid ugly errors...
   		int userId = rest.getMyUserId();

   		// Check if there is already a ProjopHour object in our local cache.
   		Integer key = new Integer(projectId);
   		ProjopObject h = (ProjopObject)(loggedHoursToday.get(key));

   		if (h == null) {
   			// We create a new ProjopHour object without hour_id.
   			// This will indicate to the REST interface, that the
   			// object hasn't created yet on the server side.
   			h = new ProjopHour();
   			h.set("project_id", projectId+"");
   	   		h.set("user_id", userId+"");
   			h.set("hours", "0");
   	   		h.set("note", "");
   	   		
   	   		// set the date of today
   	   		Date date = Calendar.getInstance().getTime();
   	   		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
   	   		String today = formatter.format(date);
   	   		h.set("day", today.toString());	
   		}

   		// Skip if the user_id == 0 (unsuccessful determine user)
   		if (userId == 0) { return; }
   		
   		
   		// Actually update the "hours" or "note" field of the object.
   		// The "column" contains exactly one of these two values, which
   		// corresponds to the local variables of the ProjopHour object.
   		h.set(column, value.toString());

   		// Write the Hour object to our local cache.
   		loggedHoursToday.put(key, h);

   		// Write through the updated object to our ]po[ server
   		h.persist();
   		
		// ]project-open[ will delete the im_hours object if it's
		// "hours" field is empty of equal to 0.0.
		// This is a non-standard behavior, because im_hours is not
		// a real object actually.
		// So we also need to mark our object in the loggedHoursToday
		// as deleted.
    	String hoursString = h.get("hours").trim();
    	Float hoursFloat = new Float(1.0);
    	try { hoursFloat = Float.parseFloat(hoursString); } catch (Exception e) {};    	
		if ("" == hoursString || 0.0 == hoursFloat) {
			loggedHoursToday.remove(key);
		}
   		
   		return;
	}	
	
    public void setValueAt(Object aValue, Object node, int column) {
    	int projectId = ((ProjopObject)node).getObjectId();
		if (projectId == 0) { return; }
    
	    switch(column) {
	    	case 0:	{
	    		// Don't change the project name...
	    		break; 
	    	}
	    	case 1:	{
	    		// store the new number of hours
	    		cacheUpdateHourForProject("hours", projectId, aValue);
	    		break; 
	    	}
	    	case 2:	{
	    		// store the new comment about the logged hours
	    		if (aValue == null) { aValue = ""; }
	    		aValue = ProjopObject.htmlEncode(aValue.toString());
	    		cacheUpdateHourForProject("note", projectId, aValue);
	    		break; 
	    	}
	    }    	
    }
	
	
	@Override
	public boolean isCellEditable(Object node, int column) {
	    switch(column) {
    		case 0:	return true;
    		case 1:	return true;
    		case 2:	return true;
	    }
	    return false;
	}

	@Override
	public Object getChild(Object parent, int index) {
		Object child = ((ProjopObject) parent).getChildObjects().get(index); 
		return child;
	}

    public Object[] getChildren(Object node) {
    	Object[] children = ((ProjopObject)node).getChildObjects().toArray();
       	return children; 
    }
	
	@Override
	public int getChildCount(Object parent) {
		int count = ((ProjopObject) parent).getChildObjects().size();
		return count;
	}
	
	public boolean isLeaf(Object node) {
		int count = ((ProjopObject) node).getChildObjects().size();
		boolean r = (count == 0);
		return r;
	}

}
