/*
 * Copyright (c) 1995 - 2008 Sun Microsystems, Inc.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

package org.projectopen.timesheet;

import java.awt.*;
import javax.swing.*;
import org.projectopen.debug.Logger;

/**
 * Simple debug panel for the ]po[ Time Sheet application.
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 */
public class DebugPanel extends JPanel implements Logger {
	private static final long serialVersionUID = 6001389192607262150L;
	protected JTextField textField;
    protected JTextArea textArea;
    private final static String newline = "\n";

    public DebugPanel() {
        super(new GridBagLayout());

        textArea = new JTextArea(30, 40);
        textArea.setEditable(false);
        
        // use a small font for loads of debugging output...
        textArea.setFont(new Font("Tahoma", Font.PLAIN, 11));

        JScrollPane scrollPane = new JScrollPane(textArea);

        //Add Components to this panel.
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;

        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
        add(scrollPane, c);
    }

	public void logMessage(int level, String domain, String message, String details) {
		
		String levelString = "undefined";
		switch (level) {
			case Logger.DEBUG: levelString = "DEBUG"; break; 
			case Logger.INFO: levelString = "INFO"; break; 
			case Logger.WARNING: levelString = "WARNING"; break; 
			case Logger.ERROR: levelString = "ERROR"; break; 
			case Logger.FATAL: levelString = "FATAL"; break; 
		}
		
		String msg = levelString + ": " + domain + ": " + message;
		
        textArea.append(msg + newline);

        if (null != details && "" != details) {
            textArea.append(details + newline);        	
        }
        
        //Make sure the new text is visible, even if there
        //was a selection in the text area.
        textArea.setCaretPosition(textArea.getDocument().getLength());
		
	}
}
