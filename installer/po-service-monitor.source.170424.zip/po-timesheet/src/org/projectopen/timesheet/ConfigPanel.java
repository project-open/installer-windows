package org.projectopen.timesheet;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 *  @author Frank Bergmann (frank.bergmann@project-open.com)
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import org.json.simple.JSONObject;
import org.projectopen.rest.RESTClient;
import org.projectopen.debug.Logger;


@SuppressWarnings("deprecation")

/*
 * A GUI panel to configure the connection parameters
 * of for the REST Web Service: 
 * server, port, email and password.
 */
public class ConfigPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel emailLabel = null;
	private JTextField emailTextField = null;
	private JLabel serverLabel = null;
	private JTextField serverTextField = null;
	private JLabel passwordLabel = null;
	private JPasswordField passwordPasswordField = null;
	private JButton testButton = null;
	private JPanel buttonPanel = null;
	private JButton saveButton = null;
	private JLabel emptyLabel = null;
	
	private JLabel statusLabel = null;
	private JTextField statusTextField = null;
	
	/**
	 * Save the local variables to the RESTClient's properties store.
	 */

	public void saveConfiguration (boolean writeToDisk) {
        String server = getServerTextField().getText();
        String email = getEmailTextField().getText();
        String password = getPasswordPasswordField().getText();

        // Write out a log message
        String details = "server="+server+"\n" + "email="+email+"\n" + "password="+password+"\n";
        RESTClient.defaultInstance().logMessage(Logger.INFO, "Application", "Saving properties", details);

        // Write the values into the RESTClient's properties 
    	RESTClient.defaultInstance().getProperties().setProperty("server", server);
        RESTClient.defaultInstance().getProperties().setProperty("email", email);
        RESTClient.defaultInstance().getProperties().setProperty("password", password);

        // save the properties to disk
        if (writeToDisk) {
        	RESTClient.defaultInstance().storeProperties();
        }
                
    }
	
	/**
	 * This method initializes emailTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getEmailTextField() {
		if (emailTextField == null) {
			emailTextField = new JTextField();
			emailTextField.setText(RESTClient.defaultInstance().getProperties().getProperty("email"));
			emailTextField.setHorizontalAlignment(JTextField.LEFT);
			emailTextField.setPreferredSize(new Dimension(200, 20));
		}
		return emailTextField;
	}

	/**
	 * This method initializes serverTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getServerTextField() {
		if (serverTextField == null) {
			serverTextField = new JTextField();
			serverTextField.setPreferredSize(new Dimension(250, 20));
			serverTextField.setText(RESTClient.defaultInstance().getProperties().getProperty("server"));
		}
		return serverTextField;
	}

	/**
	 * This method initializes passwordPasswordField	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getPasswordPasswordField() {
		if (passwordPasswordField == null) {
			passwordPasswordField = new JPasswordField();
			passwordPasswordField.setPreferredSize(new Dimension(200, 20));
			passwordPasswordField.setText("ben");
		}
		return passwordPasswordField;
	}

	/**
	 * This method initializes testButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getTestButton() {
		if (testButton == null) {
			
	        // Test the connection
	        ActionListener testButtonListener = new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					RESTClient rest = RESTClient.defaultInstance();
					
					// Log the action
			        rest.logMessage(Logger.INFO, "Application", "Test Connection", "");

					// Write the new parameters to RESTClien, 
					// and write the new parameters to disk. 
					saveConfiguration(true);
					
			        // boolean quiet, String method, URL url, String username, String password, InputStream body
	                JSONObject dom = null;
	                try {
		                dom = rest.httpRequest("GET", "/intranet-rest/index", null);	                	
	                } catch (Exception x) { System.err.println(x); }

	                if (dom != null) {
	                	statusLabel.setText("Status");
	                	statusTextField.setText("Successfully Connected");
	                	statusTextField.setVisible(true);

	                	RESTClient.defaultInstance().logMessage(Logger.INFO, "Application", "Test Connection successfull", "");
	                } else {
				        RESTClient.defaultInstance().logMessage(Logger.INFO, "Application", "Test Connection not successfull", "");	                	
	                }
	                
	            }
	        };		
			
			testButton = new JButton();
			testButton.setText("Test Connection");
            testButton.addActionListener(testButtonListener);
			
		}
		return testButton;
	}

	/**
	 * This method initializes buttonPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.gridx = -1;
			gridBagConstraints1.gridy = -1;
			
			GridBagConstraints gridBagConstraints10 = new GridBagConstraints();
			gridBagConstraints10.gridx = -1;
			gridBagConstraints10.anchor = GridBagConstraints.WEST;
			gridBagConstraints10.gridy = -1; 
			
			buttonPanel = new JPanel();
			buttonPanel.setLayout(new GridBagLayout());
			buttonPanel.add(getTestButton(), gridBagConstraints10);
			buttonPanel.add(getSaveButton(), gridBagConstraints1);
		}
		return buttonPanel;
	}

	/**
	 * This method initializes saveButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getSaveButton() {
		if (saveButton == null) {

			// Save the new parameters
	        ActionListener saveButtonListener = new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	
	            	// store configuration to RESTClient's properties
	            	// and write to disk.
	            	saveConfiguration(true);
	                
	            }
	        };		
	        saveButton = new JButton();
			saveButton.setText("Save");
	        saveButton.addActionListener(saveButtonListener);
		}
		return saveButton;
	}

	/**
	 * This method initializes statusTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getStatusTextField() {
		if (statusTextField == null) {
			statusTextField = new JTextField();
			statusTextField.setPreferredSize(new Dimension(200, 20));
			statusTextField.setEnabled(false);
			statusTextField.setText("untested");
			statusTextField.setVisible(true);
		}
		return statusTextField;
	}

	/**
	 * This is the default constructor
	 */
	public ConfigPanel(TrayIconStarter p) {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		
		GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
		gridBagConstraints3.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints3.gridy = 4;
		gridBagConstraints3.weightx = 1.0;
		gridBagConstraints3.anchor = GridBagConstraints.WEST;
		gridBagConstraints3.gridx = 1;
		GridBagConstraints gridBagConstraints12 = new GridBagConstraints();
		gridBagConstraints12.gridx = 0;
		gridBagConstraints12.anchor = GridBagConstraints.EAST;
		gridBagConstraints12.gridy = 4;
		statusLabel = new JLabel();
		statusLabel.setText("Status");
		statusLabel.setEnabled(false);
		statusLabel.setVisible(true);
		GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
		gridBagConstraints11.gridx = 0;
		gridBagConstraints11.gridy = 0;
		emptyLabel = new JLabel();
		emptyLabel.setText("");
		GridBagConstraints gridBagConstraints = new GridBagConstraints();
		gridBagConstraints.gridx = 1;
		gridBagConstraints.anchor = GridBagConstraints.WEST;
		gridBagConstraints.gridy = 5;
		GridBagConstraints gridBagConstraints9 = new GridBagConstraints();
		gridBagConstraints9.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints9.gridy = 3;
		gridBagConstraints9.weightx = 1.0;
		gridBagConstraints9.anchor = GridBagConstraints.WEST;
		gridBagConstraints9.gridx = 1;
		GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
		gridBagConstraints8.gridx = 0;
		gridBagConstraints8.anchor = GridBagConstraints.EAST;
		gridBagConstraints8.gridy = 3;
		passwordLabel = new JLabel();
		passwordLabel.setText("Password");
		GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
		gridBagConstraints7.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints7.gridy = 1;
		gridBagConstraints7.weightx = 1.0;
		gridBagConstraints7.anchor = GridBagConstraints.WEST;
		gridBagConstraints7.gridx = 1;
		GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
		gridBagConstraints6.gridx = 0;
		gridBagConstraints6.anchor = GridBagConstraints.EAST;
		gridBagConstraints6.gridy = 1;
		serverLabel = new JLabel();
		serverLabel.setText("Server");
		GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
		gridBagConstraints5.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints5.gridy = 2;
		gridBagConstraints5.weightx = 1.0;
		gridBagConstraints5.anchor = GridBagConstraints.WEST;
		gridBagConstraints5.gridx = 1;
		GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
		gridBagConstraints4.gridx = 0;
		gridBagConstraints4.anchor = GridBagConstraints.EAST;
		gridBagConstraints4.gridy = 2;
		emailLabel = new JLabel();
		emailLabel.setText("Email ");
		this.setSize(328, 154);
		this.setLayout(new GridBagLayout());
		this.add(emailLabel, gridBagConstraints4);
		this.add(getEmailTextField(), gridBagConstraints5);
		this.add(serverLabel, gridBagConstraints6);
		this.add(getServerTextField(), gridBagConstraints7);
		this.add(passwordLabel, gridBagConstraints8);
		this.add(getPasswordPasswordField(), gridBagConstraints9);
		this.add(getButtonPanel(), gridBagConstraints);
		this.add(emptyLabel, gridBagConstraints11);
		this.add(statusLabel, gridBagConstraints12);
		this.add(getStatusTextField(), gridBagConstraints3);
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
