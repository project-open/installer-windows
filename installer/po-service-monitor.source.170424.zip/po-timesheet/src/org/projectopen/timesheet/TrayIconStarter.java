package org.projectopen.timesheet;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.TrayIcon.MessageType;
import java.net.URL;
import javax.swing.table.TableColumn;

import org.projectopen.browser.ObjectBrowserFrame;
import org.projectopen.custportal.ProjectList;
import org.projectopen.rest.RESTClient;
import org.projectopen.treetable.JTreeTable;
import org.projectopen.debug.Logger;

@SuppressWarnings("deprecation")

/**
 * Starts the ]po[-Timesheet application as a "Tray Icon".
 * This class encapsulates user facing and GUI activities. 
 * - Setup a TrayIcon in the system tray
 * - Setup the menu for the TrayIcon
 * - Handle menu events for:
 * 		- Setup tool tips for the tray icon
 * 		- Configuration panel - Edit properties
 * 		- Time sheet log panel - log hours
 * 		- Browser login - open a browser window and perform a login
 */
public class TrayIconStarter implements Logger {
    static TrayIcon trayIcon = null;
	public static JFrame treeFrame;
    public static JFrame configFrame;
    public static JFrame debugFrame;
    public static JFrame browserFrame;
    public static DebugPanel debugPanel = null;
    
    static int mouseX, mouseY;

	//Optionally set the look and feel.
    private static boolean useSystemLookAndFeel = true;

    /**
     * Provide the rest of the application with a way
     * to communicate error messages to the user.
     */
    public static void trayIconError(TrayIcon.MessageType errorType, String title, String message) {
    	TrayIcon trayIcon = TrayIconStarter.getTrayIcon();
    	trayIcon.displayMessage(title, message, errorType);
    }	
	
    
    private static TrayIcon getTrayIcon() {
		return trayIcon;
	}   

    /**
     * Launch a panel with the main time sheet logging functionality
     */
	private void launchHoursPanel() {

    	System.out.println("SystemTrayTest.launchHoursPanel");
		
    	//Create and set up the window.
    	if (treeFrame == null) {
    		treeFrame = new JFrame("TreeTable");

        	System.out.println("SystemTrayTest.launchHoursPanel: before new model");

    		ProjectTreeTableModel model = new ProjectTreeTableModel();
    		JTreeTable treeTable = new JTreeTable(model);

    		// show number in US-American locale "12.34", as it is
    		// standard in ]po[.
    		treeTable.setDefaultRenderer(Float.class, new NumberRenderer());
    		treeTable.setDefaultRenderer(Double.class, new NumberRenderer());
    		treeTable.setDefaultRenderer(Number.class, new NumberRenderer());
    		
    		// set the column width
    		int colWidth[] = {300, 50, 200};
    		TableColumn column = null;
    		for (int i = 0; i < 3; i++) {
    		    column = treeTable.getColumnModel().getColumn(i);
    		    column.setPreferredWidth(colWidth[i]);
    		}
    		
    		// set alignment of Hours column
		    column = treeTable.getColumnModel().getColumn(1);
    		
    		treeFrame.getContentPane().add(new JScrollPane(treeTable));
    		treeFrame.pack();

    		// lower right corner of the frame => mouse position
    		Dimension dim = treeFrame.getSize();
    		treeFrame.setLocation(mouseX - dim.width, mouseY-dim.height);

    		// show the frame
    		treeFrame.show();

    	}
        treeFrame.setVisible(true);
    };
    
    
    /**
     * Launch a panel allowing the user to change 
     * server/email/password parameters.
     */
    private void launchConfigPanel(boolean visible) {
        if (configFrame == null) {
        	configFrame = new JFrame("Configuration");
            configFrame.add(new ConfigPanel(this));
            configFrame.pack();
            Dimension dim = configFrame.getSize();
            configFrame.setLocation(mouseX - dim.width, mouseY-dim.height);
        }
        configFrame.setVisible(visible);    
    };

    
    /**
     * Launch a panel allowing the user to drag-and-drop files.
     */
    private void launchCustomerPortal(boolean visible) {
        if (configFrame == null) {
        	configFrame = new JFrame("Drag-and-Drop Example");
            configFrame.add(new ProjectList(this));
            configFrame.pack();
            Dimension dim = configFrame.getSize();
            configFrame.setLocation(mouseX - dim.width, mouseY-dim.height);
        }
        configFrame.setVisible(visible);    
    };

    
    /**
     * Launch a panel allowing the user to browse 
     * objects of a particular type
     */
    private void launchBrowserPanel(boolean visible) {

    	//Create and set up the window.
    	if (browserFrame == null) {
    		browserFrame = new JFrame("Browser Frame");

    		browserFrame.setContentPane(new ObjectBrowserFrame());
    		    		
        	// ObjectBrowserTreeModel model = new ObjectBrowserTreeModel();
    		// JTree tree = new JTree(model);
    		// browserFrame.getContentPane().add(new JScrollPane(tree));
    		browserFrame.pack();

    		// lower right corner of the frame => mouse position
    		Dimension dim = browserFrame.getSize();
    		browserFrame.setLocation(mouseX - dim.width, mouseY-dim.height);

    		// show the frame
    		browserFrame.show();

    	}
        browserFrame.setVisible(true); 
    };

    
    /**
     * Launch a panel that shows debugging information.
     */
    private void launchDebugPanel(boolean visible) {
        if (debugFrame == null) {
        	debugFrame = new JFrame("Debug");
            debugFrame.add(debugPanel);
            debugFrame.pack();
            Dimension dim = debugFrame.getSize();
            debugFrame.setLocation(mouseX - dim.width, mouseY-dim.height);
        }
        debugFrame.setVisible(visible);    
    };
            
    public TrayIconStarter() {

        if (SystemTray.isSupported()) {

        	// Setup a RESTClient instance that
        	// will handle REST calls from the GUI.
        	new RESTClient(this);
        	
        	// create a new panel and store locally for logging,
        	// even before launching the debug panel GUI.
        	debugPanel = new DebugPanel();

        	// log the application start
            this.logMessage(Logger.INFO, "Application", "Started", "");
            
            MouseListener mouseListener = new MouseListener() {
                
                public void mouseClicked(MouseEvent e) {
                    // System.out.println("Tray Icon - Mouse clicked!" + e.getButton());   
                	
                	// remember the mouse position
                	mouseX = e.getX();
                	mouseY = e.getY();
                    // Take action depending on the button clicked
                    switch (e.getButton()) {
                		case 1: {
                            //Create and set up the window.
                			launchHoursPanel();
                		}
                	}
                }
                public void mouseEntered(MouseEvent e) {
                    // System.out.println("Tray Icon - Mouse entered!");                 
                }
                public void mouseExited(MouseEvent e) {
                	// System.out.println("Tray Icon - Mouse exited!");                 
                }
                public void mousePressed(MouseEvent e) {
                	// System.out.println("Tray Icon - Mouse pressed!");                 
                }
                public void mouseReleased(MouseEvent e) {
                	// System.out.println("Tray Icon - Mouse released!");                 
                }

            };

            // Exit the Tray application
            ActionListener exitListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    System.out.println("Exiting...");
                    System.exit(0);
                }
            };
            
            // Show configuration frame
            ActionListener configListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	launchConfigPanel(true);
                }
            };
            
            // Show configuration frame
            ActionListener browserListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	launchBrowserPanel(true);
                }
            };
            
            
            // Show configuration frame
            ActionListener debugListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	launchDebugPanel(true);
                }
            };
            
            // Show configuration frame
            ActionListener hoursListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
        			launchHoursPanel();                	
                }
            };
            
            // File drag-and-drop example
            ActionListener customerPortalListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
        			launchCustomerPortal(true);                	
                }
            };
            
            // Login to ]po[
            ActionListener loginListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	RESTClient.defaultInstance().restBrowserLogin();
                }
            };
            
            // Build the TrayIcon menu
            PopupMenu popup = new PopupMenu();
            
            MenuItem hoursMenuItem = new MenuItem("Log Hours");
            hoursMenuItem.addActionListener(hoursListener);
            popup.add(hoursMenuItem);

            if( java.awt.Desktop.isDesktopSupported() ) {
                MenuItem loginItem = new MenuItem("Login");
                loginItem.addActionListener(loginListener);
                popup.add(loginItem);
            }

            MenuItem browserItem = new MenuItem("Object Browser");
            browserItem.addActionListener(browserListener);
            popup.add(browserItem);
            
            MenuItem configItem = new MenuItem("Configuration");
            configItem.addActionListener(configListener);
            popup.add(configItem);

            MenuItem customerPortalItem = new MenuItem("Customer Portal");
            customerPortalItem.addActionListener(customerPortalListener);
            popup.add(customerPortalItem);

            MenuItem debugItem = new MenuItem("Debug");
            debugItem.addActionListener(debugListener);
            popup.add(debugItem);

            MenuItem exitItem = new MenuItem("Exit");
            exitItem.addActionListener(exitListener);
            popup.add(exitItem);

            ActionListener actionListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    trayIcon.displayMessage("Action Event", 
                        "An Action Event Has Been Peformed!",
                        TrayIcon.MessageType.INFO);
                    
                    
                    Image updatedImage = Toolkit.getDefaultToolkit().getImage("images/tray.gif");
                    trayIcon.setImage(updatedImage);
                    trayIcon.setImageAutoSize(true);


                }
            };
                     
            // get the image stored together with the classes
            String imagePath = "/org/projectopen/timesheet/po-icon.gif";
            URL fileLocation = getClass().getResource(imagePath);
            Image image = Toolkit.getDefaultToolkit().getImage(fileLocation); 
            
            // java.net.URL imageURL = TrayIconStarter.class.getResource("images/tray.gif");          
            // Image image = Toolkit.getDefaultToolkit().getImage(imagePath);

            String imageStr = "null";
            if (image != null) { imageStr = image.getSource().toString(); }
            this.logMessage(Logger.INFO, "Application", "Loading image from "+imagePath, imageStr);
            
            
            trayIcon = new TrayIcon(image, "Tray Demo", popup);
            trayIcon.setImageAutoSize(true);
            trayIcon.addActionListener(actionListener);
            trayIcon.addMouseListener(mouseListener);

            SystemTray tray = SystemTray.getSystemTray();
            try {
            	tray.add(trayIcon);
            } catch (AWTException e) {
                System.err.println("TrayIcon could not be added.");
            }

        } else {
            System.err.println("System tray is currently not supported.");
        }
    }
    
    /**
     * Start the time sheet logging application.
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {    	
    	// Use Look and Feel?
        if (useSystemLookAndFeel) {
            try {
                UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                System.err.println("Couldn't use system look and feel.");
            }
        }
        
        // Start the main application
        new TrayIconStarter();
        
        // Do we need to cleanup after closing the application?
        // this code could go here...
    }

	/**
	 * Accepts log messages from the RESTClient and
	 * displays them to the user as a TrayIcon message
	 * if they are of level ERROR or higher.
	 */
	public void logMessage(int level, String domain, String message, String details) {

		// send message to debugging panel
		if (null != debugPanel) {
			debugPanel.logMessage(level, domain, message, details);
		}
		
		// Only show ERROR and FATAL to the user as a TrayIcon message
		if (level >= Logger.ERROR) { 
			MessageType errorType = TrayIcon.MessageType.ERROR;
			switch (level) {
			case Logger.DEBUG: errorType = TrayIcon.MessageType.INFO; 
			case Logger.INFO: errorType = TrayIcon.MessageType.INFO; 
			case Logger.WARNING: errorType = TrayIcon.MessageType.WARNING; 
			case Logger.ERROR: errorType = TrayIcon.MessageType.ERROR; 
			case Logger.FATAL: errorType = TrayIcon.MessageType.ERROR; 
			}
			TrayIcon trayIcon = TrayIconStarter.getTrayIcon();
			if (null != trayIcon) {
				trayIcon.displayMessage(domain, message, errorType);
			}
		}
    }
}


