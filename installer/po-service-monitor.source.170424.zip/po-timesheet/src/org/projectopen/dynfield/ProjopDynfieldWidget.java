package org.projectopen.dynfield;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import org.json.simple.JSONObject;
import org.projectopen.debug.DomPrinter;
import org.projectopen.debug.Logger;
import org.projectopen.rest.ProjopObject;
import org.projectopen.rest.ProjopObjectType;
import org.projectopen.rest.RESTClient;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

public class ProjopDynfieldWidget extends ProjopObject {
	
	public ProjopDynfieldWidget() {
			super("user");
	}
    	
	public String toString() {	
		String name = get("username");
		if (name == null) { name = super.toString(); }
		return name;
	}

	@SuppressWarnings("unchecked")
	public static ProjopObject getWidgetFromName(String widgetName) {
		
		// the object type "responsible" for Dynfield Widget
		ProjopObjectType dynfieldWidgetType = ProjopObjectType.getObjectType("im_dynfield_widget");

		TreeMap instances = dynfieldWidgetType.getInstances();
		Iterator iter = instances.values().iterator();
		while (iter.hasNext()) {
			ProjopObject o = (ProjopObject)iter.next();
			String name = o.get("widget_name");
			if (widgetName.equals(name)) { return o; }
		}
		return null;
	}
	
	

	/**
	 * Retreive the values of a DynField widget.
	 * 
	 * @param widgetName	The name of a DynField Widget
	 * @return				A List of ComboBoxValues representing
	 * 						the options for the widget.
	 */
	public static List<String> restListDynfieldWidgetValues(String widgetName) {
		RESTClient rest = RESTClient.defaultInstance();
		
		TreeMap widgets = ProjopObjectType.getObjectType("im_dynfield_widget").getInstances();
		Iterator iter = widgets.values().iterator();
		ProjopObject widget = null;
		while (iter.hasNext()) {
			ProjopObject attr = (ProjopObject)iter.next();
			if (widgetName.equals(attr.get("widget_name"))) {
				widget = attr;
			}
		}
		if (null == widget) {
			rest.logMessage(Logger.ERROR, "Dynfield Widgets", "Didn't find widget with name "+widgetName, "");
			return null; 
		}
		
		int widgetId = Integer.parseInt(widget.get("widget_id"));
		JSONObject dom = null;
		List groups = new ArrayList();
		try {
			String urlPath = "/intranet-rest/dynfield-widget-values?widget_id="+widgetId+"&format=json";
			dom = rest.httpRequest("GET", urlPath, null);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Get the root element
		JSONObject docEle = (JSONObject)dom.get("data");

		// Iterate through the list of <row> entries, 
		// adding the data to the list of projects.
		JSONObject nl = (JSONObject) docEle.get("value");

/* ToDo: Extract values from widget
		if(nl != null && nl.keySet().size() > 0) {
			for(int i = 0 ; i < nl.getLength();i++) {				
				Element el = (Element)nl.item(i);
		        int type = el.getNodeType();
				DomPrinter.walk(el);
		        
		        // skip everything except for element nodes ("real" nodes).
		        if (type != Node.ELEMENT_NODE) { continue; }
		        
				String value = el.getTextContent();
				String key = el.getAttribute("key");
				int keyInt = Integer.parseInt(key);
				// System.out.println("v="+value+", n="+name+", k="+key);		
				
				ComboBoxValue v = new ComboBoxValue(value, keyInt);
				groups.add(v);
			}
		}
*/
		rest.logMessage(Logger.INFO, "RESTClient.restListGroups()", "List all groups in the ]po[ system", groups.toString());
		return groups;
	}

}
