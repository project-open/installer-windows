package org.projectopen.dynfield;

/**
 * This class represents values of a ComboBox.
 * In ]project-open[ we identify every object 
 * uniquely with an integer ID, while object 
 * names may include duplicates etc. 
 *   
 * @author fraber
 *
 */
public class ComboBoxValue {
	private int id = 0;
	private Object object = null;
	
	public ComboBoxValue(Object o, int id) {
		this.id = id;
		this.object = o;
	}
	
	public String toString() { return object.toString(); }
	public int getId() { return id; }
	public void setId(int id) {	this.id = id; }
	public Object getObject() {	return object; }
	public void setObject(Object object) { this.object = object; }
}
