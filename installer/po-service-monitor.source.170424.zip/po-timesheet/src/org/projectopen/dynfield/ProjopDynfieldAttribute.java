package org.projectopen.dynfield;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import org.projectopen.debug.DomPrinter;
import org.projectopen.debug.Logger;
import org.projectopen.rest.*;

@SuppressWarnings("unchecked")

public class ProjopDynfieldAttribute extends ProjopObject {
	
	private static Hashtable objectTypeAttributes = new Hashtable();
	
	public ProjopDynfieldAttribute() {
			super("user");
	}
    
	/**
	 * Returns an ordered list of ProjopDynfieldAttribute objects
	 * for the given object type.
	 * 
	 * @param objectType	The ]po[ object type to look for
	 * @return				A list of ProjopDynfieldAttribute objects.
	 */

	public static List getAttributesFromObjectType(String objectType) {
		RESTClient rest = RESTClient.defaultInstance();
		List attributes = (List)objectTypeAttributes.get(objectType); 
		if (null == attributes) {
			String query = "object_type = '"+objectType+"'"; 
			attributes = rest.fromQuery("im_dynfield_attribute", query);
			objectTypeAttributes.put(objectType, attributes);
		}
		return attributes;
	}
	
	public String toString() {	
		String name = get("username");
		if (name == null) { name = super.toString(); }
		return name;
	}

	
	
}
