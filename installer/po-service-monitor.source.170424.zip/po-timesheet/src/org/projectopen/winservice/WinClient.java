package org.projectopen.winservice;


import java.io.*;
import java.net.*;

public class WinClient {

	private Socket socket = null;
	private PrintWriter out = null;
	private BufferedReader in = null;
	private boolean connectionOpen = false;
	private String serverResponse = null;
	private String serverReturnCodeString = null;
	private int serverReturnCode = 0;
	
	public WinClient() {
		try {
			socket = new Socket("localhost", WinService.winServiceSocket);
			out = new PrintWriter(socket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			connectionOpen = true;
		} catch (UnknownHostException e) {
			System.err.println("Unable to get name for 'localhost'");
		} catch (IOException e) {
			System.err.println("Unable to connect to 'localhost' with port " + WinService.winServiceSocket);
		}
	}
	
	/**
	 * Destructor: Close the connection if still open.
	 */
	protected void finalize() throws Throwable {
		this.close();
	} 

	/**
	 * Close the connection if open
	 */
	public void close() {
		if (connectionOpen) {
			try {
				out.close();
				in.close();
				socket.close();
			} catch (Exception e) {
				System.err.println("Error closing connection");
				System.exit(1);
			}
		}
	} 

	public boolean isOpen() { return connectionOpen; }
	public PrintWriter getOut() { return out; }
	public BufferedReader getIn() { return in; }
	public String getServerResponse() { return serverResponse; }
	public int getReturnCode() { 
		int colonPos = serverReturnCodeString.indexOf(":");
		String returnCodeString = serverReturnCodeString.substring(colonPos+2);
		return new Integer(returnCodeString).intValue();
	}
	
	/**
	 * Execute a command on the server side
	 */
	public String exec(String cmdLine) {

		StringBuffer output = new StringBuffer();
		String line = null;

		// return an error indicator if not open
		if (!connectionOpen) { return null; }

		try {
			// Send input server
			this.getOut().println(cmdLine);

			// Wait until the reply gets ready
			do {
				try {
					Thread.sleep(10);
				} catch(InterruptedException e) { } 
			} while (!"".equals(cmdLine) && !this.getIn().ready());

			// Read until all text has been read 
			int ctr = 0;
			while (this.getIn().ready()) {
				line = in.readLine();
				if (0 == ctr) {
					serverReturnCodeString = line;
				} else {
					output.append(line).append("\n");
				}
				ctr++;
			}
		} catch (IOException e) { }
		
		// Return the result
		serverResponse = output.toString(); 
		return serverResponse;
	}
	
	/**
	 * Testing function with manual client.
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
		WinClient client = new WinClient();
		String userInput;
		
		do {
			// Get one line of input
			userInput = stdIn.readLine();
			String output = client.exec(userInput);
			int returnCode = client.getReturnCode();

			System.out.println("Return Code = " + returnCode);
			System.out.println("Output = " + output);
			
		} while (userInput != null && !"".equals(userInput));

		client.close();
		stdIn.close();
	}

}
