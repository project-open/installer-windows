package org.projectopen.winservice;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.projectopen.debug.Logger;

/**
 * Simple protocol implementation for executing command lines
 * with elevated Windows permissions.
 * 
 * The ]po[ Service Manager needs this background services
 * in order to start or stop ]po[ services while operating 
 * as a non-elevated TrayIcon program  with user level permissions. 
 * 
 * @author frank.bergmann@project-open.com
 *
 */
public class WinServiceProtocol {

	/**
	 * Main and only action of the Protocol:
	 * Check if the command line adheres to security constraints,
	 * execute and send the command line output back to the client.
	 * @param cmdLine A command line to execute
	 * @return The output of the command line
	 */
	public String process(String cmdLine) {
		
		if (cmdLine.isEmpty()) { return "Return Code: 0"; }
		
		Pattern p = Pattern.compile("^sc .*");
		Matcher m = p.matcher(cmdLine);
		if (!m.find()) {
			System.out.println("Security: Somebody tries to fiddle with system security: cmdLine=" + cmdLine);
			return "Return Code: -1";
		}
		
	    String line = null;
		Process process = null;
		int returnCode = -1;
		StringBuffer errorMessageBuffer = new StringBuffer();
		try {
		    process = Runtime.getRuntime().exec(cmdLine);
		    BufferedReader input = new BufferedReader(new InputStreamReader(process.getInputStream()), 13107200);
		    while ((line = input.readLine()) != null) {
		    	if (0 == line.length()) { continue; }
		    	errorMessageBuffer.append(line).append("\n"); 
		    }
		    
		    try {
		    	returnCode = process.waitFor();
	        } catch (InterruptedException e) {
	        	e.printStackTrace();
	        }
		} catch (Exception e) {
		    e.printStackTrace(System.err);
		}
		
		return "Return Code: " + returnCode + "\n" + errorMessageBuffer;
	}


}
