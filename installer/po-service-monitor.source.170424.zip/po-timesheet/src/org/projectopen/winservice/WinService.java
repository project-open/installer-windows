package org.projectopen.winservice;

import java.net.*;
import java.io.*;
import java.security.*;

/**
 * Windows service listening on port 7999 for command lines.
 * The service executes these command lines if they comply
 * with the patters of permissible lines.
 * 
 * This service is designed to be run with "elevated" admin
 * permission in order to start and stop the ]po[ services
 * "aolserver-projop" and "postgresql-8.4". This way we can
 * run the po-service-monitor.jar application with user 
 * permissions and interacting with the TrayIcon while executing
 * certain admin actions for starting and stopping Win 
 * services.
 * 
 * @author frank.bergmann@project-open.com
 *
 */
public class WinService {

	public static int winServiceSocket = 7999;
	/**
	 * Main server routine:
	 * 
	 * Listen for incoming connections and execute them
	 * in the same thread. We don't need to spawn new threads
	 * for occasionally executing a command string.
	 */
	public static void main(String[] args) throws IOException {

		ServerSocket serverSocket = null;
		boolean running = true;

		try {
			serverSocket = new ServerSocket(winServiceSocket);
			Socket socket;

			while(running) {
				socket = serverSocket.accept();
				ConnectionServer connection = new ConnectionServer(socket);
				Thread t = new Thread(connection);
				t.start();
			}
		} catch (IOException e) {
			System.out.println("IOException on socket listen: " + e);
			e.printStackTrace();
		}
		
		serverSocket.close();
	}

}


class ConnectionServer implements Runnable {

	private Socket connection;
	WinServiceProtocol protocol = new WinServiceProtocol();

	ConnectionServer(Socket serverConnection) {
		this.connection = serverConnection;
	}

	public void run () {

		String input = "";
		String output = "";
		try {
			// Get input from the client
			DataInputStream in = new DataInputStream (connection.getInputStream());
			PrintStream out = new PrintStream(connection.getOutputStream());

			// Read exactly one line
			input = in.readLine();
			while (input != null && !"".equals(input)) {
				System.out.println("Overall message is:" + input);

				// Process protocol
				output = protocol.process(input);

				// Now write to the client
				out.println(output);
				
				// read the next line
				input = in.readLine();
			}
			
			// close the connection
			connection.close();
			
		} catch (IOException ioe) {
			System.out.println("IOException on socket listen: " + ioe);
			ioe.printStackTrace();
		}
	}
}
