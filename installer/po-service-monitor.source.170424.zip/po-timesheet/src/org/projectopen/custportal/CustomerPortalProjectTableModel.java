package org.projectopen.custportal;

import java.util.List;
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

import org.projectopen.rest.ProjopProject;
import org.projectopen.rest.RESTClient;

public class CustomerPortalProjectTableModel extends AbstractTableModel {

	private String[] columnNames = {"Project Name", "Project Manager", "Status"};
	private String[] varNames = {"project_name", "project_manager_id", "project_status_id"};
	private List data;
	
	public CustomerPortalProjectTableModel() {
		initialize();
	}

	public int getColumnCount() {
        return columnNames.length;
    }
	
    public int getRowCount() {
        return data.size();
    }
	
	public String getColumnName(int col) {
		return columnNames[col];
	}

    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }
	
    public Object getValueAt(int row, int col) {
    	ProjopProject project = (ProjopProject)data.get(row);
    	return(project.get(varNames[col]));
    }

    private void initialize() {
    	RESTClient rest = RESTClient.defaultInstance();
    	data = rest.fromQuery("im_project", "project_id = 79055");
    	
    	System.out.println("CustomerPortalProjectTableModel initialized");
    }

}
