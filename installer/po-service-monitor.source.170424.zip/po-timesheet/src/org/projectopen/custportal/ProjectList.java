package org.projectopen.custportal;

import java.awt.LayoutManager;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDropEvent;
import java.io.File;
import java.util.List;

import javax.swing.*;
import javax.swing.table.TableModel;

import org.projectopen.timesheet.TrayIconStarter;
import org.projectopen.custportal.CustomerPortalProjectTableModel;

public class ProjectList extends JPanel {

	public ProjectList() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * This is the default constructor
	 */
	public ProjectList(TrayIconStarter p) {
		super();
		initialize();
	}

	
	public ProjectList(LayoutManager arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ProjectList(boolean arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ProjectList(LayoutManager arg0, boolean arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	private void initialize () {
		
		String[] columnNames = {"Project","PM", "Status"};
		
		Object[][] data = {
				{"P1", "PM1", "open"},
				{"P2", "PM1", "open"},
				{"P3", "PM2", "closed"}
		};
		
		TableModel model = new CustomerPortalProjectTableModel();
		JTable table = new JTable(model);
		this.add(table);
		
		
		table.setDropTarget(new DropTarget() {
			private static final long serialVersionUID = 1377460693690256015L;
			public synchronized void drop(DropTargetDropEvent evt) {
		        try {
		            evt.acceptDrop(DnDConstants.ACTION_COPY);
		            List<File> droppedFiles = (List)evt.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
		            for (File file : droppedFiles) {
		                // process files
		            	System.out.println(file.toString());
		            }
		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }
		    }
		});
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
