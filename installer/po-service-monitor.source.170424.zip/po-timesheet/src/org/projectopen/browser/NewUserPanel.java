package org.projectopen.browser;

import java.awt.GridBagLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.GridBagConstraints;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import org.projectopen.rest.ProjopObject;
import org.projectopen.rest.RESTClient;
import java.awt.event.KeyEvent;

public class NewUserPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextField firstNamesTextField = null;
	private JLabel lastNameLabel = null;
	private JTextField lastNameTextField = null;
	private JLabel emailLabel = null;
	private JTextField emailTextField = null;
	private JLabel passwordLabel = null;
	private JPasswordField passwordPasswordField = null;
	private JButton newUserButton = null;
	private JLabel topEmptyLabel = null;
	private JLabel bottomEmptyLabel = null;
	private JLabel nameLabel = null;
	private JLabel usernameLabel = null;
	private JTextField usernameTextField = null;
	private JLabel urlLabel = null;
	private JTextField urlTextField = null;

	private String oldEmail = "";
	private String oldUsername = "";

	/**
	 * This method initializes firstNamesTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getFirstNamesTextField() {
		if (firstNamesTextField == null) {
			firstNamesTextField = new JTextField();
			firstNamesTextField.setPreferredSize(new Dimension(100, 20));
			
			// Save the new parameters
	        KeyListener firstNamesListener = new KeyListener() {
				public void keyPressed(KeyEvent e) { }
				public void keyReleased(KeyEvent e) { updateFields(); }
				public void keyTyped(KeyEvent e) { }
	        };		
			
	        firstNamesTextField.addKeyListener(firstNamesListener);
			
		}
		return firstNamesTextField;
	}

	/**
	 * Update the Email, username etc fields to set reasonable
	 * default values
	 */
	private void updateFields () {
		String first = getFirstNamesTextField().getText();
		String last = getLastNameTextField().getText();
		String email = getEmailTextField().getText();
		String username = getUsernameTextField().getText();
		
		String newEmail = first+"."+last+"@test.com";
		String newUsername = first+"."+last;
		
		if (null == email || "".equals(email) || oldEmail.equals(email)) {
			getEmailTextField().setText(newEmail);
			oldEmail = newEmail;
		}

		if (null == username || "".equals(username) || oldUsername.equals(username)) {
			getUsernameTextField().setText(newUsername);
			oldUsername = newUsername;
		}
	}
	
	/**
	 * This method initializes lastNameTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getLastNameTextField() {
		if (lastNameTextField == null) {
			lastNameTextField = new JTextField();
			lastNameTextField.setPreferredSize(new Dimension(100, 20));
			
			// Save the new parameters
	        KeyListener lastNamesListener = new KeyListener() {
				public void keyPressed(KeyEvent e) { }
				public void keyReleased(KeyEvent e) { updateFields(); }
				public void keyTyped(KeyEvent e) { }
	        };		
			
	        lastNameTextField.addKeyListener(lastNamesListener);

		}
		return lastNameTextField;
	}

	/**
	 * This method initializes emailTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getEmailTextField() {
		if (emailTextField == null) {
			emailTextField = new JTextField();
			emailTextField.setPreferredSize(new Dimension(200, 20));
		}
		return emailTextField;
	}

	/**
	 * This method initializes passwordPasswordField	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getPasswordPasswordField() {
		if (passwordPasswordField == null) {
			passwordPasswordField = new JPasswordField();
			passwordPasswordField.setPreferredSize(new Dimension(100, 20));
			passwordPasswordField.setText("");
		}
		return passwordPasswordField;
	}

	/**
	 * This method initializes newUserButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getNewUserButton() {
		if (newUserButton == null) {
			newUserButton = new JButton();
			
			// Save the new parameters
	        ActionListener newUserButtonListener = new ActionListener() {
				@SuppressWarnings("deprecation")
				public void actionPerformed(ActionEvent e) {
	            	
					ProjopObject userObject = new ProjopObject("user");
	            	userObject.set("email", getEmailTextField().getText());
	            	userObject.set("username", getUsernameTextField().getText());
	            	userObject.set("screen_name", getUsernameTextField().getText());
					userObject.set("first_names", getFirstNamesTextField().getText());
					userObject.set("last_name", getLastNameTextField().getText());
					userObject.set("password", getPasswordPasswordField().getText());
					userObject.set("url", getUrlTextField().getText());
					
					// ToDo: implement
	            	int objectId = 0; // RESTClient.defaultInstance().restCreateObject(userObject);
	            	
	        		final JFrame f =  new JFrame("User Created");
	        		JPanel p = new JPanel();
	        		p.add(new JLabel("User created: " + objectId));
	                f.add(p);
	                f.pack();
	        		f.addWindowListener(new WindowAdapter() {
	        			public void windowClosing(WindowEvent e) {
	        				f.setVisible(false);
	        			}
	        		});
	            	f.setVisible(true);
	            }
	        };		
			
	        newUserButton.addActionListener(newUserButtonListener);
			newUserButton.setText("Create New User");
			newUserButton.setFont(new Font("Dialog", Font.PLAIN, 12));
		}
		return newUserButton;
	}

	/**
	 * This method initializes usernameTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getUsernameTextField() {
		if (usernameTextField == null) {
			usernameTextField = new JTextField();
			usernameTextField.setPreferredSize(new Dimension(100, 20));
		}
		return usernameTextField;
	}

	/**
	 * This method initializes urlTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getUrlTextField() {
		if (urlTextField == null) {
			urlTextField = new JTextField();
			urlTextField.setPreferredSize(new Dimension(200, 20));
			urlTextField.setText("http://www.project-open.com/");
		}
		return urlTextField;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame frame =  new JFrame("New User");
		JPanel panel = new NewUserPanel();
        frame.add(panel);
        frame.pack();
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
        
        frame.setVisible(true); 
	}

	/**
	 * This is the default constructor
	 */
	public NewUserPanel() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		GridBagConstraints gridBagConstraints111 = new GridBagConstraints();
		gridBagConstraints111.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints111.gridy = 5;
		gridBagConstraints111.weightx = 1.0;
		gridBagConstraints111.anchor = GridBagConstraints.WEST;
		gridBagConstraints111.gridx = 1;
		GridBagConstraints gridBagConstraints10 = new GridBagConstraints();
		gridBagConstraints10.gridx = 0;
		gridBagConstraints10.anchor = GridBagConstraints.EAST;
		gridBagConstraints10.gridy = 5;
		urlLabel = new JLabel();
		urlLabel.setText("Url");
		urlLabel.setDisplayedMnemonic(KeyEvent.VK_UNDEFINED);
		urlLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
		gridBagConstraints1.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints1.gridy = 4;
		gridBagConstraints1.weightx = 1.0;
		gridBagConstraints1.anchor = GridBagConstraints.WEST;
		gridBagConstraints1.gridx = 1;
		GridBagConstraints gridBagConstraints = new GridBagConstraints();
		gridBagConstraints.gridx = 0;
		gridBagConstraints.anchor = GridBagConstraints.EAST;
		gridBagConstraints.gridy = 4;
		usernameLabel = new JLabel();
		usernameLabel.setText("Username");
		usernameLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints9 = new GridBagConstraints();
		gridBagConstraints9.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints9.gridwidth = 1;
		gridBagConstraints9.gridx = 1;
		gridBagConstraints9.gridy = 2;
		gridBagConstraints9.weightx = 1.0;
		gridBagConstraints9.anchor = GridBagConstraints.WEST;
		gridBagConstraints9.insets = new Insets(3, 0, 0, 0);
		GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
		gridBagConstraints8.insets = new Insets(0, 0, 0, 0);
		gridBagConstraints8.gridy = 2;
		gridBagConstraints8.anchor = GridBagConstraints.EAST;
		gridBagConstraints8.gridx = 0;
		GridBagConstraints gridBagConstraints71 = new GridBagConstraints();
		gridBagConstraints71.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints71.gridx = 1;
		gridBagConstraints71.gridy = 1;
		gridBagConstraints71.weightx = 1.0;
		gridBagConstraints71.anchor = GridBagConstraints.WEST;
		gridBagConstraints71.insets = new Insets(3, 0, 2, 0);
		GridBagConstraints gridBagConstraints61 = new GridBagConstraints();
		gridBagConstraints61.insets = new Insets(5, 38, 2, 38);
		gridBagConstraints61.gridy = -1;
		gridBagConstraints61.gridx = -1;
		GridBagConstraints gridBagConstraints51 = new GridBagConstraints();
		gridBagConstraints51.gridx = 0;
		gridBagConstraints51.anchor = GridBagConstraints.EAST;
		gridBagConstraints51.gridy = 1;
		nameLabel = new JLabel();
		nameLabel.setText("First Name");
		nameLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints31 = new GridBagConstraints();
		gridBagConstraints31.gridx = 0;
		gridBagConstraints31.anchor = GridBagConstraints.EAST;
		gridBagConstraints31.gridy = 10;
		bottomEmptyLabel = new JLabel();
		bottomEmptyLabel.setText(" ");
		GridBagConstraints gridBagConstraints21 = new GridBagConstraints();
		gridBagConstraints21.gridx = 0;
		gridBagConstraints21.anchor = GridBagConstraints.EAST;
		gridBagConstraints21.gridy = 0;
		topEmptyLabel = new JLabel();
		topEmptyLabel.setText(" ");
		GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
		gridBagConstraints11.gridx = 1;
		gridBagConstraints11.anchor = GridBagConstraints.WEST;
		gridBagConstraints11.gridy = 9;
		GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
		gridBagConstraints7.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints7.gridy = 7;
		gridBagConstraints7.weightx = 1.0;
		gridBagConstraints7.anchor = GridBagConstraints.WEST;
		gridBagConstraints7.gridx = 1;
		GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
		gridBagConstraints6.gridx = 0;
		gridBagConstraints6.anchor = GridBagConstraints.EAST;
		gridBagConstraints6.gridy = 7;
		passwordLabel = new JLabel();
		passwordLabel.setText("Password");
		passwordLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
		gridBagConstraints5.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints5.gridy = 3;
		gridBagConstraints5.weightx = 1.0;
		gridBagConstraints5.anchor = GridBagConstraints.WEST;
		gridBagConstraints5.gridx = 1;
		GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
		gridBagConstraints4.gridx = 0;
		gridBagConstraints4.anchor = GridBagConstraints.EAST;
		gridBagConstraints4.gridy = 3;
		emailLabel = new JLabel();
		emailLabel.setText("Email");
		emailLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		lastNameLabel = new JLabel();
		lastNameLabel.setText("Last Name");
		lastNameLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		this.setSize(300, 200);
		this.setLayout(new GridBagLayout());
		this.add(topEmptyLabel, gridBagConstraints21);
		this.add(nameLabel, gridBagConstraints51);
		this.add(getFirstNamesTextField(), gridBagConstraints71);
		this.add(lastNameLabel, gridBagConstraints8);
		this.add(getLastNameTextField(), gridBagConstraints9);
		this.add(emailLabel, gridBagConstraints4);
		this.add(getEmailTextField(), gridBagConstraints5);
		this.add(passwordLabel, gridBagConstraints6);
		this.add(getPasswordPasswordField(), gridBagConstraints7);
		this.add(getNewUserButton(), gridBagConstraints11);
		this.add(bottomEmptyLabel, gridBagConstraints31);
		this.add(usernameLabel, gridBagConstraints);
		this.add(getUsernameTextField(), gridBagConstraints1);
		this.add(urlLabel, gridBagConstraints10);
		this.add(getUrlTextField(), gridBagConstraints111);
	}

}
