/**
 * 
 */
package org.projectopen.browser;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;

/**
 * @author fraber
 *
 */
public class ObjectListPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JScrollPane objectScrollPane = null;
	private JTable objectTable = null;
	private String objectType = null;
	
	/**
	 * This method initializes objectScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getObjectScrollPane(String objectType) {
		if (objectScrollPane == null) {
			objectScrollPane = new JScrollPane();
			JTable objectTable = getObjectTable(objectType);
			objectScrollPane.setViewportView(objectTable);
			objectTable.setFillsViewportHeight(true);
			objectTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);			
		}
		return objectScrollPane;
	}

	/**
	 * This method initializes objectTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getObjectTable(String objectType) {
		if (objectTable == null) {
			objectTable = new JTable();
			TableModel model = new ObjectListTableModel(objectType);
			objectTable.setModel(model);
			System.out.println();
		}
		return objectTable;
	}

	public ObjectListPanel(String objectType) {
		super();
		this.setObjectType(objectType);
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		GridBagConstraints gridBagConstraints = new GridBagConstraints();
		gridBagConstraints.fill = GridBagConstraints.BOTH;
		gridBagConstraints.gridy = 0;
		gridBagConstraints.weightx = 1.0;
		gridBagConstraints.weighty = 1.0;
		gridBagConstraints.gridx = 0;
		this.setSize(300, 200);
		this.setLayout(new GridBagLayout());
		this.add(getObjectScrollPane(objectType), gridBagConstraints);
	}

	protected String getObjectType() {
		return objectType;
	}

	protected void setObjectType(String oType) {
		if (oType != this.objectType) {
			this.objectType = oType;
		}
	}
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String objectType = "im_ticket";
		JFrame frame =  new JFrame("Objects");
		JComponent panel = new ObjectListPanel(objectType);
        frame.add(panel);
        frame.pack();
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
        
        frame.setVisible(true); 
	}

}
