/**
 * 
 */
package org.projectopen.browser;

import javax.swing.*;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.*;
import java.util.*;
import java.util.regex.*;

import org.projectopen.dynfield.*;
import org.projectopen.rest.*;

@SuppressWarnings("unchecked")

/**
 * @author fraber
 *
 */
public class NewObjectPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JButton newButton = null;
	private String objectTypePrettyName = null;
	
	/**
	 * The objectType for which to create a new object.
	 */
	private String objectType = null;
	
	/**
	 * The hash table of GUI components set up.
	 */
	private Hashtable components = new Hashtable();

	/**
	 * The list of dynfield attributes related to the current objectType
	 */
	private List dynfieldAttributes = null;

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}	
	
	/**
	 * This method initializes newButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getNewButton() {
		if (newButton == null) {
			newButton = new JButton("Create");
			newButton.setFont(new Font("Dialog", Font.PLAIN, 12));
						
			// Button Action: Create new object
	        ActionListener actionListener = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int oid = createObject();

					final JFrame f =  new JFrame("User Created");
					JPanel p = new JPanel();
					p.add(new JLabel(objectTypePrettyName+" created: " + oid));
					f.add(p);
					f.pack();
					f.addWindowListener(new WindowAdapter() {
						public void windowClosing(WindowEvent e) {
							f.setVisible(false);
						}
					});
					f.setVisible(true);
	            }
	        };
	        newButton.addActionListener(actionListener);			
		}
		return newButton;
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String objectType = "im_ticket";
		ProjopObjectType objectTypeObject = ProjopObjectType.getObjectType(objectType);
		String objectTypePrettyName = objectTypeObject.get("pretty_name");
		
		JFrame frame = new JFrame(objectTypePrettyName);
		NewObjectPanel panel = new NewObjectPanel(objectType);
		
        frame.add(panel);
        frame.pack();
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
        
        frame.setVisible(true); 	
    }

	/**
	 * This is the default constructor
	 */
	public NewObjectPanel(String objectType) {
		super();
		this.objectType = objectType;
		initialize();
	}
	
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {

		// get the pretty name of the object type
		RESTClient.defaultInstance();
		ProjopObjectType objectTypeObject = ProjopObjectType.getObjectType(objectType);
		objectTypePrettyName = objectTypeObject.get("pretty_name");

		// Setup the window itself
		this.setSize(300, 200);
		this.setLayout(new GridBagLayout());

		// Add a label into the left upper corner as a spacer
		JLabel lefttopLabel = new JLabel(" ");
		GridBagConstraints cLeftTop = new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, 0, new Insets(0,0,0,0), 1, 1); 
		this.add(lefttopLabel, cLeftTop);
		
		// Read the list of DynField Attributes for this object type
		dynfieldAttributes = ProjopDynfieldAttribute.getAttributesFromObjectType(objectType);

		// Sort by attribute_name
		// TODO: Replace by ypos
		Collections.sort(dynfieldAttributes, new Comparator() {
		    public int compare(Object o1, Object o2) {		    	
		        return ((ProjopObject)o1).get("attribute_name").compareTo(((ProjopObject)o2).get("attribute_name"));
		    }}
		);
		
		Iterator iter = dynfieldAttributes.iterator();
		int gridY = 1;
		while (iter.hasNext()) {
			ProjopObject attrib = (ProjopObject)iter.next();
			String attributeName = attrib.get("attribute_name");
			String prettyName = attrib.get("pretty_name");
			String widgetName = attrib.get("widget_name");
			String alsoHardCodedPString = attrib.get("also_hard_coded_p");
			boolean alsoHardCodedP = "t".equals(alsoHardCodedPString); 

			// skip this attribute if it's not absolutely necessary
			if (!alsoHardCodedP) { continue; }

			JLabel label = new JLabel(prettyName);
			label.setFont(new Font("Dialog", Font.PLAIN, 12));	
			GridBagConstraints cLabel = new GridBagConstraints(1, gridY, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, 0, new Insets(0,0,0,0), 1, 1);
			this.add(label, cLabel);

			// Create a new component depending on the widget.
			JComponent comp = this.newComponentForWidget(widgetName);
			components.put(attributeName, comp);
			GridBagConstraints cComp = new GridBagConstraints(2, gridY, 1, 1, 1.0, 1.0, GridBagConstraints.WEST, 0, new Insets(0,0,0,0), 1, 1);
			this.add(comp, cComp);
			
			gridY = gridY + 1;
		}
		
		// Add the "New Object" button
		JButton button = this.getNewButton();
		GridBagConstraints cButton = new GridBagConstraints(2, gridY, 1, 1, 1.0, 1.0, GridBagConstraints.WEST, 0, new Insets(0,0,0,0), 1, 1);
		this.add(button, cButton);
		
		// Add a label into the lower right corner as a spacer
		gridY = gridY + 1;
		JLabel rightbotLabel = new JLabel(" ");
		GridBagConstraints cRightBot = new GridBagConstraints(3, gridY, 1, 1, 1.0, 1.0, GridBagConstraints.EAST, 0, new Insets(0,0,0,0), 1, 1); 
		this.add(rightbotLabel, cRightBot);
	}

	/**
	 * Return a suitable Java widget for the specified
	 * ]project-open[ widget.
	 * @param widgetName	Name of the ]po[ widget
	 * @return				Java widget JComponent
	 */
	private JComponent newComponentForWidget(String widgetName) {
		RESTClient rest = RESTClient.defaultInstance();
		ProjopObjectType imDynfieldWidgetOtype = ProjopObjectType.getObjectType("im_dynfield_widget");
		Iterator itr = imDynfieldWidgetOtype.getInstances().values().iterator();
		ProjopObject widget = null;
		while (itr.hasNext()) {
			ProjopObject w = (ProjopObject)itr.next();
			if (widgetName.equals(w.get("widget_name"))) {
				widget = w;
			}
		}
		
		// Return a reasonable message if not found
		if (null == widget) { return new JLabel("Widget '"+widgetName+"' not found"); }
		System.out.println(widget);
		
		// the TCL Widget is the TCL procedure to render the widget.
		String tclWidget = widget.get("widget");
		String widgetParameters = widget.get("parameters");

		if ("generic_sql".equals(tclWidget)) {

			// Get a list of ComboBoxValue objects.
			List<String> widgetValues = ProjopDynfieldWidget.restListDynfieldWidgetValues(widgetName);
			Object cats[] = widgetValues.toArray();
			
			JComboBox result = new JComboBox(cats);
			result.setEnabled(true);
			result.setName(widgetName);
			result.setEditable(false);
			result.setFont(new Font("Dialog", Font.PLAIN, 12));	
			return result;
			
		} else if ("im_category_tree".equals(tclWidget)) {

			// Expect something like: "{custom {category_type "Intranet Company Type"}}"
			Pattern p = Pattern.compile("\"[^\"]*\"");
			Matcher m = p.matcher(widgetParameters);
			String categoryType = null;
			if (m.find()) {
				categoryType = m.group();
			}
			if (null == categoryType) {
				return new JLabel("Didn't  find category type in widget's parameter field: "+widgetParameters);
			}
			categoryType = categoryType.substring(1, categoryType.length()-1);
			
			// store the category_type into the object. Ugly, but we'll need the value later.
			widget.set("category_type", categoryType);
			
			Object[] cats = ProjopCategory.comboBoxCategories(categoryType);
			JComboBox result = new JComboBox(cats);
			result.setEnabled(true);
			result.setName(widgetName);
			result.setEditable(false);
			result.setFont(new Font("Dialog", Font.PLAIN, 12));	
			return result;

		} else if ("textarea".equals(tclWidget)) {

			// Expect something like: "{html {cols 40 rows 4} {nospell}}"
			// Pattern p = Pattern.compile("cols [0-9]+");
			// Matcher m = p.matcher(widgetParameters);
			int cols = 20;
			int rows = 5;

			JTextArea textArea = new JTextArea(rows, cols);
			textArea.setName(widgetName);
			textArea.setEditable(true);
			textArea.setFont(new Font("Dialog", Font.PLAIN, 12));	
			JScrollPane scrollPane = new JScrollPane(textArea);
			
			return scrollPane;
			
		} else if ("text".equals(tclWidget)) {

			// Expect something like: "{html {size 18 maxlength 30}}"
			// Pattern p = Pattern.compile("cols [0-9]+");
			// Matcher m = p.matcher(widgetParameters);
			int cols = 20;

			JTextField textField = new JTextField();
			textField.setColumns(cols);
			textField.setName(widgetName);
			textField.setEditable(true);
			textField.setFont(new Font("Dialog", Font.PLAIN, 12));	
			
			return textField;
			
		} else {
			
			return new JLabel("TCL widget '"+tclWidget+"' not implemented yet");			

		}		
	}	
	
	
	private int createObject() {
		RESTClient rest = RESTClient.defaultInstance();
		ProjopObject userObject = new ProjopObject(objectType);
		Iterator iter = dynfieldAttributes.iterator();
		while (iter.hasNext()) {
			ProjopObject attrib = (ProjopObject)iter.next();
			String attributeName = attrib.get("attribute_name");
			String widgetName = attrib.get("widget_name");
			ProjopObject widgetObject = ProjopDynfieldWidget.getWidgetFromName(widgetName);

			// get the GUI component responsible for rendering the attribute
			JComponent comp = (JComponent)components.get(attributeName);
			if (null == comp) { continue; }

			// Extract the value from the various GUI elements
			String compValue = null;
			if (JComboBox.class == comp.getClass()) {

				String comboValue = ((JComboBox)comp).getSelectedItem().toString();
				String categoryType = widgetObject.get("category_type");
				int categoryInt = ProjopCategory.categoryIdFromCategory(categoryType, comboValue);
				compValue = ""+categoryInt;

			} else if (JTextField.class == comp.getClass()) {
				compValue = ((JTextField)comp).getText();
			} else if (JTextArea.class == comp.getClass()) {
				compValue = ((JTextArea)comp).getText();
			} else {
				// internal error: New type???
				continue;
			}

			if (null == compValue) { continue; }
			userObject.set(attributeName, compValue);
		}				

		int objectId = userObject.getObjectId();
		return objectId;
	}


}
