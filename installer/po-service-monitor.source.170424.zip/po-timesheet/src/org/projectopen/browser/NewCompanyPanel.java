/**
 * 
 */
package org.projectopen.browser;

import java.awt.GridBagLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import org.projectopen.rest.ProjopCategory;
import org.projectopen.rest.ProjopObject;
import org.projectopen.rest.RESTClient;

/**
 * @author fraber
 *
 */
public class NewCompanyPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel topemptyLabel = null;
	private JLabel nameLabel = null;
	private JLabel pathLabel = null;
	private JLabel statusLabel = null;
	private JLabel typeLabel = null;
	private JLabel loweremptyLabel = null;
	private JTextField nameTextField = null;
	private JTextField pathTextField1 = null;
	private JComboBox statusComboBox = null;
	private JComboBox typeComboBox = null;
	private JLabel leftemptyLabel = null;
	private JLabel rightemptyLabel = null;
	private JButton newButton = null;
	/**
	 * This method initializes nameTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getNameTextField() {
		if (nameTextField == null) {
			nameTextField = new JTextField();
			nameTextField.setPreferredSize(new Dimension(150, 20));
		}
		return nameTextField;
	}

	/**
	 * This method initializes pathTextField1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getPathTextField1() {
		if (pathTextField1 == null) {
			pathTextField1 = new JTextField();
			pathTextField1.setPreferredSize(new Dimension(150, 20));
		}
		return pathTextField1;
	}

	/**
	 * This method initializes statusComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getStatusComboBox() {
		if (statusComboBox == null) {
			Object[] cats = ProjopCategory.comboBoxCategories("Intranet Company Status");
			statusComboBox = new JComboBox(cats);
			statusComboBox.setEnabled(true);
			statusComboBox.setName("Status");
			statusComboBox.setEditable(false);
			statusComboBox.setFont(new Font("Dialog", Font.PLAIN, 12));
		}
		return statusComboBox;
	}

	/**
	 * This method initializes typeComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getTypeComboBox() {
		if (typeComboBox == null) {
			Object[] cats = ProjopCategory.comboBoxCategories("Intranet Company Type");
			typeComboBox = new JComboBox(cats);	
			typeComboBox.setEditable(false);
			typeComboBox.setName("Type");
			typeComboBox.setFont(new Font("Dialog", Font.PLAIN, 12));
		}
		return typeComboBox;
	}

	/**
	 * This method initializes newButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getNewButton() {
		if (newButton == null) {
			newButton = new JButton();
			newButton.setText("New Company");
			newButton.setFont(new Font("Dialog", Font.PLAIN, 12));
			
			
			// Save the new parameters
	        ActionListener actionListener = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
	            	
					ProjopObject userObject = new ProjopObject("im_company");
	            	userObject.set("company_name", nameTextField.getText());
	            	userObject.set("company_nr", pathTextField1.getText());
	            	userObject.set("company_path", pathTextField1.getText());
	            	int companyStatusId = ProjopCategory.categoryIdFromCategory("Intranet Company Status", statusComboBox.getSelectedItem());
	            	int companyTypeId = ProjopCategory.categoryIdFromCategory("Intranet Company Type", typeComboBox.getSelectedItem());
	            	userObject.set("company_status_id",""+companyStatusId); 
	            	userObject.set("company_type_id",""+companyTypeId); 
	            	
	            	// ToDo: Not implemented
	            	int objectId = 0; // RESTClient.defaultInstance().restCreateObject(userObject);
	            	
	        		final JFrame f =  new JFrame("User Created");
	        		JPanel p = new JPanel();
	        		p.add(new JLabel("User  created: " + objectId));
	                f.add(p);
	                f.pack();
	        		f.addWindowListener(new WindowAdapter() {
	        			public void windowClosing(WindowEvent e) {
	        				f.setVisible(false);
	        			}
	        		});
	            	f.setVisible(true);
	            }
	        };
	        newButton.addActionListener(actionListener);			
		}
		return newButton;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame frame =  new JFrame("New Company");
		JPanel panel = new NewCompanyPanel();
        frame.add(panel);
        frame.pack();
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
        
        frame.setVisible(true); 	
    }

	/**
	 * This is the default constructor
	 */
	public NewCompanyPanel() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		GridBagConstraints gridBagConstraints14 = new GridBagConstraints();
		gridBagConstraints14.gridx = 2;
		gridBagConstraints14.anchor = GridBagConstraints.WEST;
		gridBagConstraints14.gridy = 5;
		GridBagConstraints gridBagConstraints13 = new GridBagConstraints();
		gridBagConstraints13.gridx = 3;
		gridBagConstraints13.gridy = 0;
		rightemptyLabel = new JLabel();
		rightemptyLabel.setText(" ");
		GridBagConstraints gridBagConstraints12 = new GridBagConstraints();
		gridBagConstraints12.gridx = 0;
		gridBagConstraints12.gridy = 0;
		leftemptyLabel = new JLabel();
		leftemptyLabel.setText(" ");
		GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
		gridBagConstraints11.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints11.gridy = 4;
		gridBagConstraints11.weightx = 1.0;
		gridBagConstraints11.anchor = GridBagConstraints.WEST;
		gridBagConstraints11.gridx = 2;
		GridBagConstraints gridBagConstraints10 = new GridBagConstraints();
		gridBagConstraints10.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints10.gridy = 3;
		gridBagConstraints10.weightx = 1.0;
		gridBagConstraints10.anchor = GridBagConstraints.WEST;
		gridBagConstraints10.gridx = 2;
		GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
		gridBagConstraints8.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints8.gridy = 2;
		gridBagConstraints8.weightx = 1.0;
		gridBagConstraints8.anchor = GridBagConstraints.WEST;
		gridBagConstraints8.gridx = 2;
		GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
		gridBagConstraints7.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints7.gridy = 1;
		gridBagConstraints7.weightx = 1.0;
		gridBagConstraints7.anchor = GridBagConstraints.WEST;
		gridBagConstraints7.gridx = 2;
		GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
		gridBagConstraints5.gridx = 1;
		gridBagConstraints5.anchor = GridBagConstraints.EAST;
		gridBagConstraints5.gridy = 6;
		loweremptyLabel = new JLabel();
		loweremptyLabel.setText(" ");
		GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
		gridBagConstraints4.gridx = 1;
		gridBagConstraints4.anchor = GridBagConstraints.EAST;
		gridBagConstraints4.gridy = 4;
		typeLabel = new JLabel();
		typeLabel.setText("Type");
		typeLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
		gridBagConstraints3.gridx = 1;
		gridBagConstraints3.anchor = GridBagConstraints.EAST;
		gridBagConstraints3.gridy = 3;
		statusLabel = new JLabel();
		statusLabel.setText("Status");
		statusLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
		gridBagConstraints2.gridx = 1;
		gridBagConstraints2.anchor = GridBagConstraints.EAST;
		gridBagConstraints2.gridy = 2;
		pathLabel = new JLabel();
		pathLabel.setText("Path");
		pathLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
		gridBagConstraints1.gridx = 1;
		gridBagConstraints1.anchor = GridBagConstraints.EAST;
		gridBagConstraints1.gridy = 1;
		nameLabel = new JLabel();
		nameLabel.setText("Name");
		nameLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints = new GridBagConstraints();
		gridBagConstraints.gridx = 1;
		gridBagConstraints.anchor = GridBagConstraints.EAST;
		gridBagConstraints.gridy = 0;
		topemptyLabel = new JLabel();
		topemptyLabel.setText(" ");
		this.setSize(300, 200);
		this.setLayout(new GridBagLayout());
		this.add(topemptyLabel, gridBagConstraints);
		this.add(nameLabel, gridBagConstraints1);
		this.add(pathLabel, gridBagConstraints2);
		this.add(statusLabel, gridBagConstraints3);
		this.add(typeLabel, gridBagConstraints4);
		this.add(loweremptyLabel, gridBagConstraints5);
		this.add(getNameTextField(), gridBagConstraints7);
		this.add(getPathTextField1(), gridBagConstraints8);
		this.add(getStatusComboBox(), gridBagConstraints10);
		this.add(getTypeComboBox(), gridBagConstraints11);
		this.add(leftemptyLabel, gridBagConstraints12);
		this.add(rightemptyLabel, gridBagConstraints13);
		this.add(getNewButton(), gridBagConstraints14);
	}

}
