/**
 * 
 */
package org.projectopen.browser;

import java.util.*;

import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import org.projectopen.rest.ProjopObject;
import org.projectopen.rest.ProjopObjectType;

@SuppressWarnings("unchecked")

/**
 * TreeModel that shows the ]po[ object type hierarchy and 
 * the objects that belong to each object type.
 * 
 * @author Frank Bergmann
 *
 */
public class ObjectBrowserTreeModel implements TreeModel {
	ProjopObject root = null;
	Hashtable objectTypes = new Hashtable(50);

	// Static list of object types available in the system
	private static String otypes[][] = {
		{"acs_object","","ACS Object"},
		{"im_biz_object_member","relationship","Biz Object Relation"},
		{"im_biz_object","acs_object","Business Object"},
		{"im_company","im_biz_object","Company"},
		{"im_company_employee_rel","im_biz_object_member","#intranet-contacts.company_employee_rel#"},
		{"im_component_plugin","acs_object","Component Plugin"},
		{"im_conf_item","im_biz_object","Configuration Item"},
		{"im_conf_item_project_rel","relationship","Conf Item Project Rel"},
		{"im_cost","acs_object","Cost"},
		{"im_dynfield_attribute","acs_object","Dynfield Attribute"},
		{"im_dynfield_widget","acs_object","Dynfield Widget"},
		{"im_expense","im_cost","Expense"},
		{"im_expense_bundle","im_cost","Expense Bundle"},
		{"im_forum_topic","acs_object","Forum Topic"},
		{"im_gantt_person","person","GanttPerson"},
		{"im_gantt_project","im_project","GanttProject"},
		{"im_indicator","im_report","Indicator"},
		{"im_investment","im_repeating_cost","Investment"},
		{"im_invoice","im_cost","Invoice"},
		{"im_key_account_rel","im_biz_object_member","#intranet-contacts.key_account_rel#"},
		{"im_office","im_biz_object","Office"},
		{"im_profile","group","Profile"},
		{"im_project","im_biz_object","Project"},
		{"im_release_item","relationship","Release Member"},
		{"im_repeating_cost","im_cost","Repeating Cost"},
		{"im_report","acs_object","Report"},
		{"im_ticket","im_project","Ticket"},
		{"im_ticket_queue","group","Ticket Queue"},
		{"im_ticket_ticket_rel","relationship","Ticket Ticket Rel"},
		{"im_timesheet_invoice","im_invoice","Timesheet Invoice"},
		{"im_timesheet_task","im_project","Timesheet Task"},
		{"im_trans_invoice","im_invoice","Trans Invoice"},
		{"im_trans_task","acs_object","Translation Task"},
		{"im_user_absence","acs_object","Absence"},
		{"calendar","acs_object","Calendar"},
		{"cal_item","acs_event","Calendar Item"},
		{"group","party","Group"},
		{"party","acs_object","Party"},
		{"person","party","Person"},
		{"user","person","User"},
		{"admin_rel","membership_rel","Administrator Relation"},
		{"composition_rel","relationship","Composition Relation"},
		{"membership_rel","relationship","Membership Relation"},
		{"relationship","acs_object","Relationship"},
		{"user_blob_response_rel","relationship","User Blob Response"},
		{"user_portrait_rel","relationship","User Portrait"},
		{"ticket_generic_wf","workflow","Generic Ticket Workflow"},
		{"ticket_workflow_generic_wf","workflow","Ticket Workflow Generic"},
		{"timesheet_approval_wf","workflow","Timesheet Approval"},
		{"vacation_approval_wf","workflow","Vacation Approval"},
		{"expense_approval_wf","workflow","Expense Approval"},
		{"feature_request_wf","workflow","Feature Request"},
		{"project_approval_wf","workflow","Project Approval"},
		{"rfc_approval_wf","workflow","RFC Approval"},
		{"acs_event","acs_object","ACS Event"},
		{"dynamic_group_type","group","Dynamic Group Type"},
		{"rel_segment","party","Relational Party Segment"},
		{"workflow_lite","acs_object","Workflow Lite"},
		{"im_invoice_item","acs_object","Invoice Item"},
		{"im_mail_from","relationship","Mail From"},
		{"im_mail_to","relationship","Mail To"},
		{"im_mail_related_to","relationship","Mail Related To"},
		{"im_hour","acs_object","Timesheet Hour"},
		{"duplicate_token_test_wf","workflow","Duplicate Token Test"},
		{"workflow","acs_object","Workflow"}
	};


	@SuppressWarnings("unused")
	private static String obsoleteOTypes[][] = {
		{"acs_activity","acs_object","Activity"},
		{"im_material","acs_object","Material"},
		{"im_menu","acs_object","Menu"},
		{"im_note","acs_object","Note"},
		{"im_rest_object_type","acs_object","REST Object Type"},
		{"survsimp_question","acs_object","Simple Survey Question"},
		{"survsimp_response","acs_object","Simple Survey Response"},
		{"survsimp_survey","acs_object","Simple Survey"},
		{"rel_constraint","acs_object","Relational Constraint"},
		{"site_node","acs_object","Site Node"},
		{"im_timesheet_conf_object","acs_object","Timesheet Confirmation Object"},

	{"acs_mail_body","acs_mail_gc_object","ACS Mail Body"},
	{"acs_mail_gc_object","acs_object","ACS Mail Object"},
	{"acs_mail_link","acs_object","ACS Mail Message"},
	{"acs_mail_multipart","acs_mail_gc_object","ACS Mail Multipart Object"},
	{"acs_mail_queue_message","acs_mail_link","Queued Message"},
	{"acs_message","content_item","Message"},
	{"authority","acs_object","Authority"},
	{"bt_bug","acs_object","Bug"},
	{"bt_bug_revision","content_revision","Bug Revision"},
	{"bt_patch","acs_object","Patch"},
	{"notification","acs_object","Notification"},
	{"notification_delivery_method","acs_object","Notification Delivery Method"},
	{"notification_interval","acs_object","Notification Interval"},
	{"notification_reply","acs_object","Notification Reply"},
	{"notification_request","acs_object","Notification Request"},
	{"notification_type","acs_object","Notification Type"},
	{"apm_application","apm_package","Application"},
	{"apm_package","acs_object","Package"},
	{"apm_package_version","acs_object","Package Version"},
	{"apm_parameter","acs_object","Package Parameter"},
	{"apm_parameter_value","acs_object","APM Package Parameter Value"},
	{"apm_service","apm_package","Service"},
	{"cr_item_child_rel","acs_object","Child Item"},
	{"cr_item_rel","acs_object","Item Relationship"},
	{"acs_message_revision","content_revision","Message Revision"},
	{"acs_named_object","acs_object","Named Object"},
	{"acs_reference_repository","acs_object","ACS Reference Repository"},
	{"acs_sc_contract","acs_object","ACS SC Contract"},
	{"acs_sc_implementation","acs_object","ACS SC Implementation"},
	{"acs_sc_msg_type","acs_object","ACS SC Message Type"},
	{"acs_sc_operation","acs_object","ACS SC Operation"},
	{"ams_object_revision","content_revision","AMS Object"},
	{"application_group","group","Application Group"},
	{"content_extlink","content_item","External Link"},
	{"content_folder","content_item","Content Folder"},
	{"content_item","acs_object","Content Item"},
	{"content_keyword","acs_object","Content Keyword"},
	{"content_module","content_item","Content Module"},
	{"content_symlink","content_item","Content Symlink"},
	{"content_template","content_item","Content Template"},
	{"etp_page_revision","content_revision","ETP managed page"},
	{"image","content_revision","Image"},
	{"news_item","etp_page_revision","News Item"},
	{"journal_article","etp_page_revision","Journal Article"},
	{"journal_issue","etp_page_revision","Journal Issue"},
	{"journal_entry","acs_object","Journal Entry"},
	{"workflow_case_log_entry","content_revision","Workflow Case Log Entry"},
	{"content_revision","acs_object","Basic Item"},
	{"chat_room","acs_object","Chat Room"},
	{"chat_transcript","acs_object","Chat Transcript"},
	{"postal_address","acs_object","Postal Address"},
	{"im_cost_center","acs_object","Cost Center"},
	{"im_freelance_rfq","acs_object","Freelance RFQ"},
	{"im_freelance_rfq_answer","acs_object","Freelance RFQ Answer"},
	{"im_fs_file","acs_object","Filestorage File"}
	};

	
	/**
	 * Construct by setting up a type hierarchy equivalent to ]po[
	 */
	public ObjectBrowserTreeModel() {
		initialize();
	}

	/**
	 * Setup the object type hierarchy from constant definition.
	 */
	private void initialize() {
		System.out.println("ObjectBrowserTreeModel.initialize");
	
		// Go through the "otypes" array and add all object types
		for (int i = 0; i < otypes.length; i++) {
			ProjopObject o = new ProjopObjectType();
			String objectType = new String(otypes[i][0]);
			o.set("object_type", objectType);
			o.set("supertype", otypes[i][1]);
			o.set("pretty_name", otypes[i][2]);
			objectTypes.put(objectType, o);
			
			// The root is the "acs_object" object type
			if (i==0) {
				root = o;				
			}
		}
		
		// Iterate through all object types and set the parent and 
		// child relationships for each of them.
		Enumeration e = objectTypes.elements();
		while(e.hasMoreElements()) {
			ProjopObjectType ot = (ProjopObjectType)e.nextElement();
			String stString = ot.get("supertype");
			if (null != stString && "" != stString) {
				ProjopObjectType st = (ProjopObjectType)(objectTypes.get(stString));
				ot.setParentType(st);
				st.getChildObjectTypes().add(ot);
			}
		}
	}

	public void addTreeModelListener(TreeModelListener arg0) {
		// TODO Auto-generated method stub

	}
	
	/**
	 * Returns the Nth child of the object "o".
	 * The procedure checks if this is a leaf object type
	 * and will then present the list of objects of that type.
	 */
	public Object getChild(Object o, int index) {

		// find out the object type of the object:
		String oType = ((ProjopObject)o).getObjectType();
		
		// If this is an object type, then we have to check
		// if we are in a leaf, because there we need to return
		// the list of objects
		if ("acs_object_type" == oType) {
			List children = ((ProjopObjectType)o).getChildrenForObjectBrowser();
			return children.get(index);
		}
		
		// We should never get here.
		return null;
	}

	public int getChildCount(Object o) {

		// find out the object type of the object:
		String oType = ((ProjopObject)o).getObjectType();
		
		// If this is an object type, then we have to check
		// if we are in a leaf, because there we need to return
		// the list of objects
		if ("acs_object_type" == oType) {
			List children = ((ProjopObjectType)o).getChildrenForObjectBrowser();
			return children.size();
		}
		
		// We should never get here.
		return 0;

	}
		
	public int getIndexOfChild(Object o, Object arg1) {

		// find out the object type of the object:
		String oType = ((ProjopObject)o).getObjectType();
		
		// If this is an object type, then we have to check
		// if we are in a leaf, because there we need to return
		// the list of objects
		if ("acs_object_type" == oType) {
			List children = ((ProjopObjectType)o).getChildrenForObjectBrowser();
			
			return children.indexOf(arg1);
		}

		// We should never get here.
		return 0;
	}

	public Object getRoot() { return root; }

	public boolean isLeaf(Object o) {
		return (getChildCount(o) == 0);
	}

	public void removeTreeModelListener(TreeModelListener arg0) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.TreeModel#valueForPathChanged(javax.swing.tree.TreePath, java.lang.Object)
	 */
	@Override
	public void valueForPathChanged(TreePath arg0, Object arg1) {
		// TODO Auto-generated method stub

	}

}
