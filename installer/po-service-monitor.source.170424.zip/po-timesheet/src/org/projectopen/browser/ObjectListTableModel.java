package org.projectopen.browser;

import java.util.AbstractMap;
import java.util.List;

import javax.swing.table.AbstractTableModel;
import org.projectopen.rest.ProjopObject;
import org.projectopen.rest.ProjopObjectType;

@SuppressWarnings("unchecked")

public class ObjectListTableModel extends AbstractTableModel {

	private static final long serialVersionUID = 2655637231029122476L;
	private String objectType = null;
	
	public ObjectListTableModel(String oType) {
		super();
		this.objectType = oType;
	}
	
	public String getColumnName(int columnIndex) {
		ProjopObjectType oType = (ProjopObjectType)ProjopObjectType.getObjectType(objectType);
		List varList = oType.getVarList();
		Object o = varList.get(columnIndex);
		
		return (String)o;
	}

	public Class getColumnClass(int columnIndex) {
		return String.class;
	}
	
	
	@Override
	public int getColumnCount() {
		ProjopObjectType oType = (ProjopObjectType)ProjopObjectType.getObjectType(objectType);
		if (null == oType) { return 0; }
		AbstractMap instances = oType.getInstances();
		if (null == instances || instances.isEmpty()) { return 0; }
		ProjopObject first = (ProjopObject)instances.values().iterator().next();
		if (null == first) { return 0; }
		return first.getVars().size();
	}

	@Override
	public int getRowCount() {
		ProjopObjectType oType = (ProjopObjectType)ProjopObjectType.getObjectType(objectType);
		if (null == oType) { return 0; }
		AbstractMap instances = oType.getInstances();
		if (null == instances || instances.isEmpty()) { return 0; }
		return instances.size();
	}

	@Override
	public Object getValueAt(int row, int col) {
		ProjopObjectType oType = (ProjopObjectType)ProjopObjectType.getObjectTypes().get(this.objectType);
		if (null == oType) { return null; }
		AbstractMap instances = oType.getInstances();
		if (null == instances || instances.isEmpty()) { return null; }
		ProjopObject o = (ProjopObject)instances.values().toArray()[row];
		return o.getVars().values().toArray()[col];
	}

}
