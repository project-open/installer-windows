package org.projectopen.browser;

import java.awt.GridBagLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JComboBox;
import javax.swing.JButton;

import org.projectopen.rest.ProjopCategory;
import org.projectopen.rest.ProjopObject;
import org.projectopen.rest.RESTClient;

public class NewUserAbsencePanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel topLabel = null;
	private JLabel nameLabel = null;
	private JLabel startLabel = null;
	private JLabel endLabel = null;
	private JLabel typeLabel = null;
	private JLabel statusLabel = null;
	private JLabel bottomLabel = null;
	private JTextField nameTextField = null;
	private JTextField startTextField = null;
	private JTextField endTextField = null;
	private JComboBox typeComboBox = null;
	private JComboBox statusComboBox = null;
	private JLabel leftLabel = null;
	private JLabel rightLabel = null;
	private JButton newButton = null;
	/**
	 * This method initializes nameTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getNameTextField() {
		if (nameTextField == null) {
			nameTextField = new JTextField();
			nameTextField.setPreferredSize(new Dimension(150, 20));
		}
		return nameTextField;
	}

	/**
	 * This method initializes startTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getStartTextField() {
		if (startTextField == null) {
			startTextField = new JTextField();
			startTextField.setPreferredSize(new Dimension(80, 20));
			startTextField.setText("YYYY-MM-DD");
		}
		return startTextField;
	}

	/**
	 * This method initializes endTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getEndTextField() {
		if (endTextField == null) {
			endTextField = new JTextField();
			endTextField.setPreferredSize(new Dimension(80, 20));
			endTextField.setText("YYYY-MM-DD");
		}
		return endTextField;
	}

	/**
	 * This method initializes typeComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getTypeComboBox() {
		if (typeComboBox == null) {
			Object[] cats = ProjopCategory.comboBoxCategories("Intranet Absence Status");
			typeComboBox = new JComboBox(cats);
			typeComboBox.setFont(new Font("Dialog", Font.PLAIN, 12));
		}
		return typeComboBox;
	}

	/**
	 * This method initializes statusComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getStatusComboBox() {
		if (statusComboBox == null) {
			Object[] cats = ProjopCategory.comboBoxCategories("Intranet Absence Type");
			statusComboBox = new JComboBox(cats);
			statusComboBox.setFont(new Font("Dialog", Font.PLAIN, 12));
		}
		return statusComboBox;
	}

	/**
	 * This method initializes newButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getNewButton() {
		if (newButton == null) {
			newButton = new JButton();
			newButton.setText("New Absence");
			newButton.setFont(new Font("Dialog", Font.PLAIN, 12));
			
			// Save the new parameters
	        ActionListener actionListener = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
	            	
					ProjopObject userObject = new ProjopObject("im_user_absence");
	            	userObject.set("absence_name", nameTextField.getText());
	            	userObject.set("start_date", startTextField.getText());
	            	userObject.set("end_date", endTextField.getText());
	            	int statusId = ProjopCategory.categoryIdFromCategory("Intranet Absence Status", statusComboBox.getSelectedItem());
	            	int typeId = ProjopCategory.categoryIdFromCategory("Intranet Absence Type", typeComboBox.getSelectedItem());
	            	userObject.set("absence_status_id",""+statusId); 
	            	userObject.set("absence_type_id",""+typeId); 
	            	
	            	// ToDo: implement
	            	int objectId = 0; // RESTClient.defaultInstance().restCreateObject(userObject);
	            	
	        		final JFrame f =  new JFrame("User Created");
	        		JPanel p = new JPanel();
	        		p.add(new JLabel("User  created: " + objectId));
	                f.add(p);
	                f.pack();
	        		f.addWindowListener(new WindowAdapter() {
	        			public void windowClosing(WindowEvent e) {
	        				f.setVisible(false);
	        			}
	        		});
	            	f.setVisible(true);
	            }
	        };
	        newButton.addActionListener(actionListener);			

			
		}
		return newButton;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame frame =  new JFrame("New Absence");
		JPanel panel = new NewUserAbsencePanel();
        frame.add(panel);
        frame.pack();
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
        
        frame.setVisible(true); 	
    }


	/**
	 * This is the default constructor
	 */
	public NewUserAbsencePanel() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		GridBagConstraints gridBagConstraints14 = new GridBagConstraints();
		gridBagConstraints14.gridx = 2;
		gridBagConstraints14.anchor = GridBagConstraints.WEST;
		gridBagConstraints14.gridy = 7;
		GridBagConstraints gridBagConstraints13 = new GridBagConstraints();
		gridBagConstraints13.gridx = 3;
		gridBagConstraints13.gridy = 0;
		rightLabel = new JLabel();
		rightLabel.setText(" ");
		GridBagConstraints gridBagConstraints12 = new GridBagConstraints();
		gridBagConstraints12.gridx = 0;
		gridBagConstraints12.gridy = 0;
		leftLabel = new JLabel();
		leftLabel.setText(" ");
		GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
		gridBagConstraints11.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints11.gridy = 6;
		gridBagConstraints11.weightx = 1.0;
		gridBagConstraints11.anchor = GridBagConstraints.WEST;
		gridBagConstraints11.gridx = 2;
		GridBagConstraints gridBagConstraints10 = new GridBagConstraints();
		gridBagConstraints10.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints10.gridy = 5;
		gridBagConstraints10.weightx = 1.0;
		gridBagConstraints10.anchor = GridBagConstraints.WEST;
		gridBagConstraints10.gridx = 2;
		GridBagConstraints gridBagConstraints9 = new GridBagConstraints();
		gridBagConstraints9.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints9.gridy = 3;
		gridBagConstraints9.weightx = 1.0;
		gridBagConstraints9.anchor = GridBagConstraints.WEST;
		gridBagConstraints9.gridx = 2;
		GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
		gridBagConstraints8.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints8.gridy = 2;
		gridBagConstraints8.weightx = 1.0;
		gridBagConstraints8.anchor = GridBagConstraints.WEST;
		gridBagConstraints8.gridx = 2;
		GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
		gridBagConstraints7.fill = GridBagConstraints.VERTICAL;
		gridBagConstraints7.gridy = 1;
		gridBagConstraints7.weightx = 1.0;
		gridBagConstraints7.anchor = GridBagConstraints.WEST;
		gridBagConstraints7.gridx = 2;
		GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
		gridBagConstraints6.gridx = 1;
		gridBagConstraints6.gridy = 10;
		bottomLabel = new JLabel();
		bottomLabel.setText(" ");
		GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
		gridBagConstraints5.gridx = 1;
		gridBagConstraints5.anchor = GridBagConstraints.EAST;
		gridBagConstraints5.gridy = 6;
		statusLabel = new JLabel();
		statusLabel.setText("Status");
		statusLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
		gridBagConstraints4.gridx = 1;
		gridBagConstraints4.anchor = GridBagConstraints.EAST;
		gridBagConstraints4.gridy = 5;
		typeLabel = new JLabel();
		typeLabel.setText("Type");
		typeLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
		gridBagConstraints3.gridx = 1;
		gridBagConstraints3.anchor = GridBagConstraints.EAST;
		gridBagConstraints3.gridy = 3;
		endLabel = new JLabel();
		endLabel.setText("End");
		endLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
		gridBagConstraints2.gridx = 1;
		gridBagConstraints2.anchor = GridBagConstraints.EAST;
		gridBagConstraints2.gridy = 2;
		startLabel = new JLabel();
		startLabel.setText("Start");
		startLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
		gridBagConstraints1.gridx = 1;
		gridBagConstraints1.anchor = GridBagConstraints.EAST;
		gridBagConstraints1.gridy = 1;
		nameLabel = new JLabel();
		nameLabel.setText("Name");
		nameLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gridBagConstraints = new GridBagConstraints();
		gridBagConstraints.gridx = 1;
		gridBagConstraints.gridy = 0;
		topLabel = new JLabel();
		topLabel.setText(" ");
		topLabel.setFont(new Font("Dialog", Font.BOLD, 12));
		this.setSize(300, 200);
		this.setLayout(new GridBagLayout());
		this.add(topLabel, gridBagConstraints);
		this.add(nameLabel, gridBagConstraints1);
		this.add(startLabel, gridBagConstraints2);
		this.add(endLabel, gridBagConstraints3);
		this.add(typeLabel, gridBagConstraints4);
		this.add(statusLabel, gridBagConstraints5);
		this.add(bottomLabel, gridBagConstraints6);
		this.add(getNameTextField(), gridBagConstraints7);
		this.add(getStartTextField(), gridBagConstraints8);
		this.add(getEndTextField(), gridBagConstraints9);
		this.add(getTypeComboBox(), gridBagConstraints10);
		this.add(getStatusComboBox(), gridBagConstraints11);
		this.add(leftLabel, gridBagConstraints12);
		this.add(rightLabel, gridBagConstraints13);
		this.add(getNewButton(), gridBagConstraints14);
	}

}
