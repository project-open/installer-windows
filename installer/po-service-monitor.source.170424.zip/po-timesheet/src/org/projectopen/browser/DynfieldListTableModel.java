package org.projectopen.browser;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import org.projectopen.dynfield.ProjopDynfieldAttribute;
import org.projectopen.rest.ProjopObject;

@SuppressWarnings("unchecked")

/**
 * This table model represents the dynamic fields
 * that belong to a certain object type
 */
public class DynfieldListTableModel extends AbstractTableModel {

	private static final long serialVersionUID = -181295859700418641L;
	static final String cname[] = {
		"ID", "Name", "Table", "Column", 
		"Type", "Widget", "Hard Coded?", "Sort Order"
	};

	static final String cvar[] = {
		"attribute_id", "pretty_name", "table_name", "attribute_name", 
		"datatype",	"widget_name", "also_hard_coded_p", "sort_order"
	};

	static final Class ctype[] = {
		String.class, String.class, String.class, String.class, 
		String.class, String.class, String.class, String.class
	};
	
	private String objectType = null;
	
	public DynfieldListTableModel(String oType) {
		super();
		this.objectType = oType;
	}
	
	public String getColumnName(int columnIndex) {
		return cname[columnIndex];
	}
	public Class getColumnClass(int columnIndex) {
		return ctype[columnIndex];
	}
	
	@Override
	public int getColumnCount() {
		return cname.length;
	}

	@Override
	public int getRowCount() {
		List attrs = ProjopDynfieldAttribute.getAttributesFromObjectType(objectType);
		return attrs.size();
	}

	@Override
	public Object getValueAt(int row, int col) {
		List attrs = ProjopDynfieldAttribute.getAttributesFromObjectType(objectType);
		ProjopObject a = (ProjopObject)attrs.get(row);
		String colName = cvar[col];
		String value = a.get(colName);
		return value;
	}

}
