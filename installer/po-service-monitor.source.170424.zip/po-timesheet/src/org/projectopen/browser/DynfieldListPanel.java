/**
 * 
 */
package org.projectopen.browser;

import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.table.TableModel;

/**
 * @author fraber
 *
 */
public class DynfieldListPanel extends JScrollPane {

	private static final long serialVersionUID = 7110486062789525401L;
	private JTable attrsTable = null;
	private String objectType = null;
	
	protected String getObjectType() { return objectType; }
	protected void setObjectType(String oType) { this.objectType = oType; }	

	/**
	 * This method initializes objectTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getObjectTable(String objectType) {
		if (attrsTable == null) {
			attrsTable = new JTable();
			TableModel model = new DynfieldListTableModel(objectType);
			attrsTable.setModel(model);
		}
		return attrsTable;
	}

	public DynfieldListPanel(String objectType) {
		super();
		this.setObjectType(objectType);
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		
		this.setPreferredSize(new Dimension(500,300));
		// this.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		// this.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

		JViewport port = new JViewport();
		JTable attrTable = getObjectTable(objectType);
		// attrTable.setPreferredScrollableViewportSize(new Dimension(800,600));
		port.setView(attrTable);
		this.setViewport(port);
		
		attrTable.setFillsViewportHeight(true);
		attrTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
	}


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String objectType = "im_ticket";
		JFrame frame =  new JFrame("DynField panel");
		JComponent panel = new DynfieldListPanel(objectType);
        frame.add(panel);
        frame.pack();
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
        
        frame.setVisible(true); 
	}
}
