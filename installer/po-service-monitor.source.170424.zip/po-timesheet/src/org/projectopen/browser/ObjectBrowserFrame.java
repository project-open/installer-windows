/**
 * 
 */
package org.projectopen.browser;

import java.net.*;
import java.util.*;
import java.util.List;
import java.util.regex.Pattern;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;

import java.lang.reflect.Constructor;

import org.projectopen.rest.*;
import org.projectopen.debug.Logger;
import org.projectopen.dynfield.ProjopDynfieldAttribute;

@SuppressWarnings("unchecked")

/**
 * @author Frank Bergmann
 *
 */
public class ObjectBrowserFrame extends JSplitPane implements TreeSelectionListener {

	private static final long serialVersionUID = 1L;
	private JTree objectTree = null;
	private JPanel objectPanel = null;
	private JTabbedPane objectTabbedPane = null;
	private JScrollPane objectScrollPane = null;

	/**
	 * 
	 */
	public ObjectBrowserFrame() {
		super();
		initialize();
	}

	/**
	 * This method initializes objectTree	
	 * 	
	 * @return javax.swing.JTree	
	 */
	private JTree getObjectTree() {
		if (objectTree == null) {
			objectTree = new JTree(new ObjectBrowserTreeModel());
			
			// allow only one node to be selected
		    objectTree.getSelectionModel().setSelectionMode
            (TreeSelectionModel.SINGLE_TREE_SELECTION);
		    
		    // listen to tree selection events
		    objectTree.addTreeSelectionListener(this);
		    objectTree.setPreferredSize(new Dimension(400, 400));
		}
		return objectTree;
	}

	/**
	 * This method initializes objectTabbedPane	
	 * 	
	 * @return javax.swing.JTabbedPane
	 */
	private JTabbedPane getObjectTabbedPane(String objectType) {
		if (objectTabbedPane == null) {
			objectTabbedPane = new JTabbedPane();
			// objectTabbedPane.setPreferredSize(new Dimension(400, 400));
			
			// show "ACS Object" object information by default
			setupTabbedPaneForObjectType("acs_object");
		}
		return objectTabbedPane;
	}

	@SuppressWarnings("unused")
	private JPanel getObjectPanel() {
		if (objectPanel == null) {
			objectPanel = new JPanel();
			this.setLayout(new GridBagLayout());
			// objectPanel.setPreferredSize(new Dimension(500, 500));
		}
		return objectPanel;
	}
	/**
	 * This method initializes objectScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getObjectScrollPane() {
		if (objectScrollPane == null) {
			objectScrollPane = new JScrollPane(getObjectTree());
			objectScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			objectScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		}

		return objectScrollPane;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame frame =  new JFrame("Object Browser");
		JSplitPane panel = new ObjectBrowserFrame();
        frame.add(panel);
        frame.pack();
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
        
        frame.setVisible(true); 
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		
		this.setOneTouchExpandable(true);
		this.setDividerLocation(200);

		this.setLeftComponent(getObjectScrollPane());
		this.setRightComponent(getObjectTabbedPane(""));

		// Dimension minimumSize = new Dimension(300, 300);
		// objectTree.setMinimumSize(minimumSize);
		// objectTabbedPane.setMinimumSize(minimumSize);	
	}

	@Override
	public void valueChanged(TreeSelectionEvent e) {

		//Returns the last path element of the selection.
		//This method is useful only when the selection model allows a single selection.
		Object node = objectTree.getLastSelectedPathComponent();

		//Nothing is selected?
		if (node == null) { return; }
				
		String objectType = ((ProjopObjectType)node).get("object_type");
		this.setupTabbedPaneForObjectType(objectType);
	}

	/**
	 * Check if there is a class with name New-ObjectType-Panel
	 * and return the class if it exists. Returns null otherwise
	 * @param objectType
	 * @return The class of the NewPanel for creating an object
	 * 			of the given object_type
	 */
	private Class getNewPanelClassForObjectType(String objectType) {

		// convert ]po[ style object types into Java style 
		// Split ]po[ object_type by "_"
		Pattern p = Pattern.compile("_");
		String[] pieces = p.split(objectType);
		String classBodyName = "";
		for (int i = 0; i < pieces.length; i++) {
			String r = pieces[i];
			classBodyName = classBodyName + r.substring(0,1).toUpperCase() + r.substring(1,r.length());
		}	
		String className = "org.projectopen.browser."+"New"+classBodyName+"Panel";
		Class c = null;
		try {
			c = Class.forName(className); 
		} catch (Exception e3) { }
		
		// Not successful: Check if the class is supported
		// with DynFields.
		if (null == c) {
			List attributes = ProjopDynfieldAttribute.getAttributesFromObjectType(objectType);
			if (attributes.size() > 0) {
				return NewObjectPanel.class;
			}
		}
		
		return c;
	}	
	
	/**
	 * Returns a Panel showing ]po[ documentation about 
	 * the specified object type
	 * @param objectType	]po[ object type (ex: "im_project")
	 * @return				JPanel with documentation about the 
	 * 						objectType.
	 */
	private JComponent getInfoPane(String objectType) {

		JTextPane textPane = new JTextPane();
		JScrollPane textScrollPane = new JScrollPane();
		textScrollPane.getViewport().add(textPane);
		
		try {
			URL url = new URL("http://www.project-open.org/documentation/object_type_"+objectType+"?no_template_p=1");
			textPane.setPage(url);
		} catch (Exception e2) {
			RESTClient.defaultInstance().logMessage(Logger.WARNING, "Object Info Panel", "Didn't find documentation for objectType="+objectType, e2.toString());
		}
		
		return textScrollPane;
	}

	/**
	 * Returns a Panel showing ]po[ documentation about 
	 * the specified object type
	 * @param objectType	]po[ object type (ex: "im_project")
	 * @return				JPanel with documentation about the 
	 * 						objectType.
	 */
	private JComponent getDynFieldPane(String objectType) {

        JTextArea textArea = new JTextArea(30, 40);
        textArea.setEditable(false);
        // use a relatively small font
        textArea.setFont(new Font("Tahoma", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(textArea);
        List attributes = ProjopDynfieldAttribute.getAttributesFromObjectType(objectType);
        Iterator iter = attributes.iterator();
        while (iter.hasNext()) {
        	ProjopObject a = (ProjopObject)iter.next();
        	String name = a.get("attribute_name");
        	String prettyName = a.get("pretty_name");
        	String widget = a.get("widget");
        	String dataType = a.get("datatype");
        	textArea.append(prettyName+": column="+name+", widget="+widget+", datatype="+dataType);
        	textArea.append("\n");
        }
		
        if (0 == attributes.size()) {
        	textArea.append("No DynFields available for object type "+objectType+"");
        	textArea.append("\n");
        }
		return scrollPane;
	}
	

	/**
	 * Returns a Panel allowing to create a new object instance. 
	 * @param objectType	]po[ object type (ex: "im_project")
	 * @return				JPanel allowing to create a new object.
	 */
	private JComponent getNewPanel(String objectType) {

		Class newPanelClass = this.getNewPanelClassForObjectType(objectType);
		if (newPanelClass == null) { return null; }
		
		Constructor ctor = null;
		Object newInstance = null;

		// Check if there is a constructor that doesn't take arguments
		// This is the case for the specific New-Panels
		try {
			Class[] ctorArgs = new Class[0];
			ctor = newPanelClass.getConstructor(ctorArgs);
			newInstance = ctor.newInstance(new Object[0]);
		} catch (Exception e2) {
			// e2.printStackTrace();
		}

		// Check if there is a constructor with a single String argument.
		// This is the case of a NewObjectPanel class.
		try {
			Class[] ctorArgs1 = { String.class };
			ctor = newPanelClass.getConstructor(ctorArgs1);
			Object args[] = new Object[1];
			args[0] = objectType;
			newInstance = ctor.newInstance(args);
		} catch (Exception e3) {
			// e3.printStackTrace();
		}
		return (JComponent)newInstance;
	}
	
	
	/**
	 * Add various tabs in the TabbedPane to show information
	 * about an object type.
	 * @param objectType
	 */
	private void setupTabbedPaneForObjectType(String objectType) {

		// cleanup all previous tabs
		this.objectTabbedPane.removeAll();

		// get the object's pretty name
		ProjopObjectType oType = (ProjopObjectType)ProjopObjectType.getObjectTypes().get(objectType);
		String prettyName = oType.get("pretty_name");

		// Get and deploy the "Info" panel
		JComponent textPanel = getInfoPane(objectType);
		objectTabbedPane.addTab(prettyName+" Info", null, textPanel, "]po[ documentation about the object type");
		objectTabbedPane.setMnemonicAt(0, KeyEvent.VK_1);
		objectTabbedPane.setPreferredSize(new Dimension(200, 300));

		// Get and deploy the "DynFields" panel
		JComponent dynfieldPanel = this.getDynFieldPane(objectType);
		objectTabbedPane.addTab(prettyName+" DynFields", null, dynfieldPanel, "List of object attributes");
		objectTabbedPane.setMnemonicAt(1, KeyEvent.VK_2);
		objectTabbedPane.setPreferredSize(new Dimension(200, 300));

		// Setup the "Instances" panel
		JComponent instancesPanel = new ObjectListPanel(objectType);
		objectTabbedPane.addTab(prettyName + " Instances", null, instancesPanel, "Instances of the object type");
		objectTabbedPane.setMnemonicAt(2, KeyEvent.VK_3);
		objectTabbedPane.setPreferredSize(new Dimension(200, 300));
		
		// Setup the new component
		JComponent newPanel = this.getNewPanel(objectType);
		objectTabbedPane.addTab("New "+prettyName, null, newPanel, "Create a new instance");
		objectTabbedPane.setMnemonicAt(3, KeyEvent.VK_4);
		objectTabbedPane.setPreferredSize(new Dimension(200, 300));
	}
	
}  //  @jve:decl-index=0:visual-constraint="10,10"







