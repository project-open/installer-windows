package org.projectopen.debug;

import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;

import org.projectopen.serverstatus.TrayIconServiceStarter;

public class SystemLogger implements Logger {

	public void logMessage(int level, String domain, String message, String details) {
		
		String levelString = "undefined";
		switch (level) {
			case Logger.DEBUG: levelString = "DEBUG"; break; 
			case Logger.INFO: levelString = "INFO"; break; 
			case Logger.WARNING: levelString = "WARNING"; break; 
			case Logger.ERROR: levelString = "ERROR"; break; 
			case Logger.FATAL: levelString = "FATAL"; break; 
		}
		
		String msg = levelString + ": " + domain + ": " + message;
		System.out.println(msg);
	}

}
