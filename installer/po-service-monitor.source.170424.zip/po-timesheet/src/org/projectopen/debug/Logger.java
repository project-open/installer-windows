package org.projectopen.debug;

/**
 * Simple logger interface.
 * 
 * We use this interface to allow the TrayIconStarter
 * (or other starter classes) to be used to display
 * debug and error messages to the user.
 *
 * @author Frank Bergmann
 *
 */
public interface Logger {
	public static final int DEBUG = 0;		// Normal operations
	public static final int INFO = 1;		// Inform user about a situation which might not be an error
	public static final int WARNING = 2;	// System can deal with the issue itself.
	public static final int ERROR = 3;		// Important application error - requires user action 
	public static final int FATAL = 4;		// Can't continue the application after that

	/**
	 * Print out an error message at a suitable location.
	 * @param level		Debug level between 0=DEBUG and 4=FATAL.
	 * 					Please see static constants
	 * @param domain	Short sized error domain ("Application error", "Server error", ...)
	 * @param message	Medium sized Message string (20-300 characters)
	 * @param details	Details of the message (potentially very long)
	 */
	public void logMessage(int level, String domain, String message, String details);
}
