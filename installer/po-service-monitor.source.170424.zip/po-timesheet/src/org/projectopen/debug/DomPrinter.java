package org.projectopen.debug;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

import java.io.*;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import com.sun.org.apache.xerces.internal.parsers.DOMParser;

/**
 * Simple XML Document printer.
 * This class is used to debug the replies from the 
 * ]po[ REST Web Service.
 * 
 * @autor Frank Bergmann <frank.bergmann@project-open.com>
 */
public class DomPrinter
{
    boolean validation = true;
    DOMParser myDOMParser;
    String xmlFile = null;
    InputStream stream = null;
    Document doc;
    
    public DomPrinter(String fileName) { xmlFile = fileName;  }
    public DomPrinter(InputStream s) { stream = s; }
    
    /**
     * Print out the contents of an correctly initialized
     * DomPrinter. 
     * 
     * However, to print out an Element it's easier to use
     * the static walk() method below. 
     */
    public void print()
    {
        try {
           myDOMParser = (DOMParser) new DOMParser();
         
           //To validate or not
           myDOMParser.setFeature( "http://xml.org/sax/features/validation", validation); 
           
           if (xmlFile != null) {
        	   myDOMParser.parse(xmlFile);
           } else {
        	   InputSource source = new InputSource (stream);
        	   myDOMParser.parse(source);
           }

           doc = myDOMParser.getDocument();
           walk(doc);
        }   
        catch(Exception e) { System.out.println("Errors " + e); }

    }
    
    /**
     * Walk the DOM tree and print as you go
     * @param node
     */
    public static void walk(Node node)
    {
    	if (node == null) { return; }
        int type = node.getNodeType();
        switch(type) {
            case Node.DOCUMENT_NODE: {
              System.out.println("<?xml version=\"1.0\" encoding=\"" + "UTF-8" + "\"?>");  
              break;                  
            }
            case Node.ELEMENT_NODE: {
                System.out.print('<' + node.getNodeName() );
                NamedNodeMap nnm = node.getAttributes();
                if(nnm != null ) {
                    int len = nnm.getLength() ;
                    Attr attr;
                    for ( int i = 0; i < len; i++ ) {
                        attr = (Attr)nnm.item(i);
                        System.out.print(' ' + attr.getNodeName() + "=\"" + attr.getNodeValue() +  '"' );
                    }
                }
                System.out.print('>');                
                break;
            }
            case Node.ENTITY_REFERENCE_NODE: {
               System.out.print('&' + node.getNodeName() + ';' );
               break;
            }
            case Node.CDATA_SECTION_NODE: {
                    System.out.print( "<![CDATA[" + node.getNodeValue() + "]]>" );
                     break;
            }
            case Node.TEXT_NODE: {
                System.out.print(node.getNodeValue());
                break;
            }
            case Node.PROCESSING_INSTRUCTION_NODE: {
                System.out.print("<?" + node.getNodeName());
                String data = node.getNodeValue();
                if ( data != null && data.length() > 0 ) {
                    System.out.print(' ');
                    System.out.print(data);
                }
                System.out.println("?>");
                break;
             }
        }
              
        // recurse
        for(Node child = node.getFirstChild(); child != null; child = child.getNextSibling()) {
            walk(child);
        }
        
        // without this the ending tags will miss
        if ( type == Node.ELEMENT_NODE ) {
            System.out.print("</" + node.getNodeName() + ">");
        }
    }   
}