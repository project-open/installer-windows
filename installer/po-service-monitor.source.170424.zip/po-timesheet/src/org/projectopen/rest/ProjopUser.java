package org.projectopen.rest;

import java.util.List;

import org.projectopen.debug.Logger;


/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

/**
 * Represents a ]project-open[ user object.
 */
public class ProjopUser extends ProjopObject {
	
	public ProjopUser() {
			super("user");
	}
    	
	public String toString() {	
		String name = get("username");
		if (name == null) { name = super.toString(); }
		return name;
	}

	/**
	 * What is the ]po[ userId of the user that is logged in?
	 * This function asks the REST server, based on the email
	 * of the login credentials.
	 * However, the RESTClient contains a cached version of this
	 * ID which it gets during intialization, so you probably
	 * never have to call this function.
	 * 
	 * @return userId of the user currently logged into the REST interface.
	 */
	public static int getMyUserIdFromServer() {
		int userId = -1;
		RESTClient client = RESTClient.defaultInstance();
		String email = client.getProperties().getProperty("email");
		ProjopObject user = ProjopUser.fromEmail(email);
		if (null != user) {
			userId = Integer.parseInt(user.get("user_id"));
		}
		return userId;
	}

	/**
	 * Retrieve all information about a ]po[ specific user, identified
	 * by the user's email (which is unique in ]po[).
	 *   
	 * @param email The email of a ]po[ user
	 * @return a ProjopObject of type "user" with everything about the user.
	 */
	public static ProjopObject fromEmail(String email) {
		RESTClient client = RESTClient.defaultInstance();
		client.logMessage(Logger.INFO, "RESTClient.restReadUserFromEmail("+email+")", "Query the REST server for a user with the specified email", "");

		List<ProjopObject> objects = client.fromQuery("user", "email = '"+email+"'");

		if (objects == null) { return null; }
		if (objects.isEmpty()) { return null; }
		ProjopObject o = objects.get(0);
		client.logMessage(Logger.INFO, "RESTClient.restReadUserFromEmail("+email+")", "Query the REST server for a user with the specified email", o.toString());
		
		return o;
	}
	


}
