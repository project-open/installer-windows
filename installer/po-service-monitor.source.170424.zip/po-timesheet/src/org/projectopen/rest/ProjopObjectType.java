package org.projectopen.rest;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

import java.util.*;

public class ProjopObjectType extends ProjopObject {
	
	// A cache for object types, so that every object type
	// only exists once in the system.
	private static Hashtable<String,ProjopObjectType> objectTypes = new Hashtable<String,ProjopObjectType>();
	
	// Parent object type. "acs_object" is the root of all object
	// types. Only acs_objects has NULL as parentObjectType.
	private ProjopObjectType parentObjectType = null;
	
	// List of object types that are inheriting from this one.
	private Vector<ProjopObjectType> childObjectTypes = new Vector<ProjopObjectType>();
	
	// Sorted list of objects of this object type.
	private TreeMap<Integer,ProjopObject> instances = null;
	
	// A sorted vector of children, so that the ObjectBrowser
	// can show them as a sorted list.
	private Vector<ProjopObjectType> childrenForObjectBrowser = null;
	
	// A list of variables available in the an arbitrary
	// first element of this object type.
	private ArrayList<String> varList = null;
	
	public ProjopObjectType() { 
		super("acs_object_type"); 
	}

	/**
	 * Returns an ordered list of all variable names
	 * available for this object type. The order of the 
	 * variables is arbitrary at the moment. In the future
	 * this should be replaced by data from DynFields.
	 * @return
	 */
	public ArrayList<String> getVarList() {
		if (null == varList) {
			varList = new ArrayList<String>();
			Object firstKey = this.getInstances().firstKey();
			Object first = this.instances.get(firstKey);
			ProjopObject o = (ProjopObject)first;
			Hashtable<String,String> vars = o.getVars();
			Enumeration<String> keys = vars.keys();
			while (keys.hasMoreElements()) {
				String key = (String)keys.nextElement();
				varList.add(key);
			}
		}
		return varList;
	}

	
	public static Hashtable<String,ProjopObjectType> getObjectTypes() { return objectTypes; }
	public static ProjopObjectType getObjectType(String objectType) {
		if (null == objectTypes.get(objectType)) {
			ProjopObjectType t = new ProjopObjectType();
			t.set("object_type",objectType);
			objectTypes.put(objectType, t);
		}
		return (ProjopObjectType)objectTypes.get(objectType);
	}
	
	public ProjopObjectType getParentObjectType() { return parentObjectType; }
	public void setParentType(ProjopObjectType parentType) { this.parentObjectType = parentType; }
	public void setChildTypes(Vector<ProjopObjectType> childTypes) { this.childObjectTypes = childTypes; }
	public Vector<ProjopObjectType> getChildObjectTypes() { Collections.sort(childObjectTypes); return childObjectTypes; }  

	public void set(String varName, String value) {
		super.set(varName, value);
		
		// Add this object to the list of object types
		// to maintain a global cache
		if ("object_type" == varName) {
			objectTypes.put(value, this);
		}
	}
	
	public TreeMap<Integer,ProjopObject> getInstances() {
		RESTClient rest = RESTClient.defaultInstance();
		if (null == instances) {
			// Get the list of instances
			List<ProjopObject> is = null;
			String objectTypeString = this.get("object_type");
			if ("acs_object_type" != objectTypeString) {
				is = rest.fromQuery(objectTypeString, "");
			}
			
			// Setup the new instanceHash
			instances = new TreeMap<Integer,ProjopObject>();

			if (null != is) {
				Iterator<ProjopObject> e = is.iterator();
				while(e.hasNext()) {
					ProjopObject o = (ProjopObject)e.next();
					Integer i = new Integer(o.getObjectId());
					instances.put(i, o);
				}
			}
		}
		
		return instances; 
	}  
	
	/**
	 * Return an ordered list of children suitable for
	 * being displayed in the ObjectBrowserTreeModel.
	 * @return	A list of 1) sub-object types and 2)
	 * 			of instance objects.
	 */
	public List<ProjopObjectType> getChildrenForObjectBrowser() {
		if (null == childrenForObjectBrowser) {
			// clone the child object types
			childrenForObjectBrowser = new Vector<ProjopObjectType>(getChildObjectTypes());
		}
		return childrenForObjectBrowser;
	}
	
	public String toString() {
		String name = this.get("pretty_name");
		if (null == name || "" == name) { name = this.get("object_type"); }
		return name;
	}

}
