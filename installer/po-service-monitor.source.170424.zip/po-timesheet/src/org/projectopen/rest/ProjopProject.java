package org.projectopen.rest;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

import java.util.*;
import org.json.simple.*;


// @SuppressWarnings("unchecked")

/**
 * Class representing a ]po[ Project.
 * Values are stored in a key-value list, so the object adapts
 * to whatever attributes the REST interface returns.
 * Values are stored as strings using TCL string representation, 
 * independent from the actual type. Convenient... 
 */
public class ProjopProject extends ProjopObject {
	
	public ProjopProject() {
			super("im_project");				// ]po[ name of this object type
	}

	public ProjopProject(JSONObject el) {
		super("im_project", el);				// ]po[ name of this object type
	}
    	
	public String toString() {	
		String name = get("project_name");
		if (name == null) { name = super.toString(); }
		return name;
	}

	
	/**
	 * Query the REST server for a list projects available for 
	 * timesheet logging
	 * 
	 * @return	A list of ProjopHour objects representing the hours
	 * 			logged today.
	 */
	public static List<ProjopObject> myTimesheetProjects() {
		RESTClient rest = RESTClient.defaultInstance();
		String urlPath = "/intranet-reporting/view?format=json&report_code=rest_my_timesheet_projects";
		return rest.fromURL("im_project", urlPath);
	}

	
}
