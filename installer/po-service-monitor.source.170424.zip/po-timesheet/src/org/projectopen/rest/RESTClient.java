package org.projectopen.rest;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.Pattern;

import org.json.simple.*;
import org.json.simple.parser.*;
import org.projectopen.debug.*;

import sun.misc.BASE64Encoder;

// @SuppressWarnings({ "unchecked", "deprecation" })

/**
 * Main interface class to the ]project-open[ REST interface.
 * This class encapsulates all HTTP communication with the 
 * server and provides the rest of the application with access
 * to the application specific functionality.
 */
public class RESTClient implements Logger {
	
	/**
	 * Configuration properties including server, email and password.
	 */
	private Properties properties = null;
	
	/*
	 * Default instance for singleton pattern.
	 */
	private static RESTClient defaultInstance = null;
	
	/**
	 * Link to calling application that needs to implement the logger 
	 * interface to show system messages.
	 */
	private Logger logger = null;
	
	/**
	 * UserId of the user currently logged into the REST server.
	 */
	protected int myUserId = 0;
	
	// REST Version Management
	private static String clientRESTVersion = "3.0";
	private String serverRESTVersion = null;

	// -----------------------------------------------------------------------
	// 
	// -----------------------------------------------------------------------

	/**
	 * Constructor - requires to be started from an applet with 
	 * logging functionality.
	 * 
	 * @param starterApp
	 */
	public RESTClient(Logger starterApp) {
		super();
		logger = starterApp;			// Save for logging output
		RESTClient.defaultInstance = this;
		
		// Check if we can work with the REST version on the server side
		serverRESTVersion = restReadServerRESTVersion();
		this.checkRESTVersionCompatibility(serverRESTVersion);
		
		// GET the ID of the login user.
		myUserId = ProjopUser.getMyUserIdFromServer();
	}
	
	/**
	 * Return a default RESTClient.
	 * Most applications in this world will only need one connection
	 * to a REST server...
	 * @return	A default RESTClient
	 */
	public static RESTClient defaultInstance () {
		if (null == defaultInstance) {
			System.out.println("ERROR: default instance not yet initialized, so we can't write out error. Please call RESTClient.setupDefaultInstance(..) first.");
			defaultInstance = new RESTClient(null);
		}
		return defaultInstance;
	}
	
	
	// -----------------------------------------------------------------------
	// REST Version Methods
	// -----------------------------------------------------------------------

	/**
	 * Determines the server's REST version.
	 * Major changes in the version digit indicate incompatibilities.
	 * Minor changes indicated protocol additions.
	 * 
	 * @return The server's REST protocol version
	 */
	public String restReadServerRESTVersion() {

		JSONObject dom = null;
		logMessage(Logger.INFO, "RESTClient.restReadVersion", "Get the server's REST version", "");

		try {
			String urlPath = "/intranet-rest/version?format=json";
			dom = this.httpRequest("GET", urlPath, null);
		} catch (Exception e) {
			logMessage(Logger.ERROR, "RESTClient.restReadVersion", "Error connecting to server.", e.toString());
			return "";
		}

		if (null == dom) return "";
		return ((String)dom.get("version")).trim();
	}
	
	/**
	 * Check if we can deal with the REST version on
	 * the server.
	 */
	private void checkRESTVersionCompatibility(String serverRESTVersion) {
		// Expect something like: "2.11"
		Pattern p = Pattern.compile("\\.");
		String serverPieces[] = p.split(serverRESTVersion);
		int len = serverPieces.length;
		String clientPieces[] = p.split(clientRESTVersion);
		int clientPiecesLen = clientPieces.length;
		if (clientPiecesLen < len) { len = clientPiecesLen; }

		boolean ok = true;

		// Check the "major" version.
		// Incompatible if different
		if ("" == serverPieces[0]) {
			this.logMessage(Logger.FATAL, "REST version retreival error", "The server did not provide a major REST version.", "");
			System.exit(0);
		}
		int serverVer = Integer.parseInt(serverPieces[0]);
		int clientVer = Integer.parseInt(clientPieces[0]);
		if (clientVer != serverVer) { ok = false; }

		// Check the "minor" version.
		// It's OK if the server version is higher.
		if ("" == serverPieces[1]) {
			this.logMessage(Logger.FATAL, "REST version retreival error", "The server did not provide a minor REST version.", "");
			System.exit(0);
		}
		serverVer = Integer.parseInt(serverPieces[1]);
		clientVer = Integer.parseInt(clientPieces[1]);
		if (serverVer < clientVer) { ok = false; }

		if (!ok) {
			this.logMessage(Logger.FATAL, "REST Protocol Mismatch", "The server doesn't provide the required version of the REST interface.", "REST V"+serverRESTVersion + " incompatible with REST V" + clientRESTVersion);
			System.exit(0);
		} else {
			this.logMessage(Logger.INFO, "REST Protocol Match", "The client and server REST protocol versions are compatible. Server: "+serverRESTVersion + ", Client: "+clientRESTVersion,"");			
		}
	}

	
	// -----------------------------------------------------------------------
	// Properties Methods
	// -----------------------------------------------------------------------

	/**
	 * Determine the parameters necessary to connect to the
	 * server. Properties are initialized with the a default
	 * login to the ]po[ main demo server.
	 * User can modify these properties and store them in the
	 * local application folder.
	 * 
	 * @return A properties object with the configuration. 
	 */
	public Properties getProperties() {
		if (properties == null) {

			// Setup the "Ben Bigboss" account. Ben is the
			// head of the "Tigerpond" ]po[ sample company.
			properties = new Properties();
			properties.put("server", "http://192.168.52.128/");
			properties.put("email", "bbigboss@tigerpond.com");
			properties.put("password", "ben");

			try {
				// now load properties from last invocation
				FileInputStream in = new FileInputStream("config.properties");
				properties.load(in);
				in.close();

			} catch (Exception e) {
				// ignore if not there
				// e.printStackTrace();
			}
			logMessage(Logger.INFO, "RESTClient.getProperties()", "Loaded properties from 'config.properties'", properties.toString());
		}
		return properties;
	}
	
	/**
	 * Store modified properties to the local application directory.
	 */
	public void storeProperties() {
		logMessage(Logger.INFO, "RESTClient.storeProperties()", "Storing properties to 'config.properties'", properties.toString());

		FileOutputStream out;
		try {
			out = new FileOutputStream("config.properties");
			properties.store(out, "--- Parameters to access a ]project-open[ server ---");
			out.close();
		} catch (Exception e) {		
			logMessage(Logger.ERROR, "RESTClient.storeProperties()", "Error storing properties to 'config.properties'", e.toString());
		}
	}

	/**
	 * Delete all cached information.
	 * This is necessary when changing the configuration 
	 * or when the next day has started if the application
	 * is running at night.
	 */
	public void flushCache() {
		properties = null;
		// parent: don't touch
		// defaultInstance: don't touch
	}


	/**
	 * Accepts log messages from the REST interactions 
	 * and GUI elements and logs them 1) to the DebugPanel
	 * and 2) to the TrayIconStarter, where ERROR and FATAL
	 * messages are displayed to the user.
	 */
	public void logMessage(int level, String domain, String message, String details) {
		// Always write to System.out
		String levelString = "undefined";
		switch (level) {
		case Logger.DEBUG: levelString = "DEBUG"; break;
		case Logger.INFO: levelString = "INFO"; break;
		case Logger.WARNING: levelString = "WARNING"; break;
		case Logger.ERROR: levelString = "ERROR"; break;
		case Logger.FATAL: levelString = "FATAL"; break;
		}
		
		System.out.println(levelString + ": " + domain + ": " + message + ": "+details);		
		
		if (null != logger) { 		// pass the log message to the parent, if it's set correctly.
			logger.logMessage(level, domain, message, details); 
		}
	}

	/**
	 * Launch a Web browser in the user's desktop with a 
	 * URL including his password for automatic login.
	 */
	public void restBrowserLogin() {
		logMessage(Logger.INFO, "RESTClient.restBrowserLogin()", "Launch a Web browser.", "");
		String server = getProperties().getProperty("server");
		String email = getProperties().getProperty("email");
		String password = getProperties().getProperty("password");
		try {
			URI uri = new java.net.URI(server + "/intranet/auto-login?email=" + email + "&password="+password + "&url=/intranet-timesheet2/hours/index");
			java.awt.Desktop.getDesktop().browse(uri);
		} catch (Exception e1) {
			System.err.println(e1.getMessage());
		}
	};
	
	// -----------------------------------------------------------------------
	// REST HTTP Level Methods
	// -----------------------------------------------------------------------

	/**
	 * The server has returned a reply like this one:
	 * { success: 'false', message: 'Not authenticated' }
	 */
	protected void httpError(int httpResponseCode, URL url, JSONObject obj) {
		// Extract the information from the XML error text
		String message = (String)obj.get("message");

		// Format a nice message that will be sent to the user's tray icon
		String urlQuery = url.getQuery();
		if (urlQuery == null) { urlQuery = ""; } else { urlQuery = "/"+urlQuery; }
		String details = "" +
		"Status: " + httpResponseCode +
		"\nURL: " + url.getPath() + urlQuery; 
		logMessage(Logger.ERROR, "Application Error", "Server returned: "+message + "\n", details);
	}

	/**
	 * Perform a REST HTTP request.
	 * 
	 * @param method	Either "GET" or "POST"
	 * @param urlPath	The path part of the URL including a leading slash, 
	 * 					for example "/intranet-rest/index"
	 * @param body		Input stream for the XML data to send to the server 
	 * 					for POST operations. Ignored for GET operations.
	 * @return			A XML document with the parsed REST response.
	 * 					Returns NULL in case of an error.
	 */
	@SuppressWarnings("deprecation")
	public JSONObject httpRequest(String method, String urlPath, InputStream body) {
		String server = getProperties().getProperty("server");
		String email = getProperties().getProperty("email");
		String password = getProperties().getProperty("password");

		HttpURLConnection connection;
		int httpResponseCode = 0;

		// Determine the right URL
		URL url = null;
		try {
			url = new URL(server + urlPath);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		logMessage(Logger.DEBUG, "HTTP Interaction", "-> " + method + ": " + url, "");

		// Open the connection
		try {
			connection = (HttpURLConnection)url.openConnection();
			connection.setRequestMethod(method);
		} catch (IOException e1) {
			logMessage(Logger.ERROR, " Connection Error", "Unable to connect to server " + server, "");
			return null;
		}

		// Create and write Basic HTTP Authentication header
		BASE64Encoder encoder = new BASE64Encoder();
		String encodedCredential = encoder.encode( (email + ":" + password).getBytes() );
		connection.setRequestProperty("Authorization", "BASIC " + encodedCredential);

		// Write body if we're doing POST or PUT
		byte buffer[] = new byte[8192];
		int read = 0;
		if (body != null && method != "DELETE") {
			try {
				connection.setDoOutput(true);
				OutputStream output = connection.getOutputStream();
				while ((read = body.read(buffer)) != -1) { output.write(buffer, 0, read); }
			} catch (IOException e2) {
				logMessage(Logger.ERROR, "Connection Error", "Unable to write to connection to server " + server, "");
				return null;
			}
		}

		// do request
		try {
			connection.connect();
			httpResponseCode = connection.getResponseCode();
		} catch (IOException e2) {
			logMessage(Logger.ERROR, "Connection Error", "Unable to connect to server " + server, "");
			return null;
		}

		logMessage(Logger.DEBUG, "HTTP Interaction", "<- httpResponseCode="+httpResponseCode +" from " + url, "");

		/*
		 * Check for connection errors. In particular, deal with
		 * application specific errors like insufficient permissions
		 * etc.
		 */
		InputStream responseBodyStream = null;
		String response = "";
		// 200 = HTTP Success.
		if (200 == httpResponseCode) {
			try {
				responseBodyStream = connection.getInputStream();
				InputStreamReader reader = new InputStreamReader(responseBodyStream);
				BufferedReader br = new BufferedReader(reader);
				String line;
				while ((line = br.readLine()) != null) {
					response += line + "\n";
				}
			} catch (IOException e) {
				logMessage(Logger.ERROR, "Connection Error", "Unable to read from server", "");
				return null;
			}
		} else {
			// Any code != 200 means application error
			try {
				// Take the "ErrorStream" from the connection to check for an error message
				responseBodyStream = connection.getErrorStream();

				char charBuffer[] = new char[8192];
				StringBuilder errorXmlString = new StringBuilder();
				Reader in = new InputStreamReader(responseBodyStream, "UTF-8");
				do {
					read = in.read(charBuffer, 0, buffer.length);
					if (read > 0) { errorXmlString.append(charBuffer, 0, read); }
				} while (read >= 0);

				logMessage(Logger.ERROR, "Application Error", "The REST server reports an application error.", errorXmlString.toString());
				responseBodyStream = new StringBufferInputStream(errorXmlString.toString());            	

			} catch (IOException e) {
				logMessage(Logger.ERROR, "Connection Error", "Unable to read from server " + server, "");
				return null;
			}
		}

		JSONObject dom = null;
		try {
			JSONParser p = new JSONParser();
			dom = (JSONObject)p.parse(response);
		} catch (Exception e1) {
			logMessage(Logger.ERROR, "Application Error", "Unable to parse the JSON reply from server " + server + " / " + urlPath, response);
			return null;
		}

		// Check if the returned object contains a "success" field
		Object success = dom.get("success");
		if (success == null) {
			logMessage(Logger.ERROR, "Application Error", "JSON reply does not contain a 'success' field: " + server + " / " + urlPath, response);
			return null;
		}
		
		String successClass = success.getClass().getSimpleName();
		switch (successClass) {
		case "Boolean":
			Boolean successBoolean = (Boolean)success;
			if (successBoolean != true) {
				logMessage(Logger.ERROR, "Application Error", "JSON request returned a 'false' boolean success status from: " + server + " / " + urlPath, response);
				return null;			
			}
			break;
		case "String":
			String successString = (String)success;
			if (!"true".equals(successString)) {
				logMessage(Logger.ERROR, "Application Error", "JSON request returned a 'false' string success status from: " + server + " / " + urlPath, response);
				return null;			
			}			
			break;
		default:
			logMessage(Logger.ERROR, "Application Error", "JSON request returned a success status of type: " + successClass + " from: " + server + " / " + urlPath, response);
			return null;
		}


		// An error response (responseCode != 200) contains an error 
		// message that we can pass to the user as a TrayIcon message
		if (httpResponseCode != 200) {
			httpError(httpResponseCode, url, dom);  
			dom = null;						// Reset the dom to NULL as a
		}
		return dom;
	}

	/**
	 * GET a single object identified by an objectType and an objectId.
	 * 
	 * Please use this method only in special cases, because retreiving
	 * each object this way would cause a lot of HTTP traffic and be very
	 * slow.
	 * 
	 * @param objectType	]po[ object type ("im_project", "user", "im_hour", ...)
	 * @param objectId		]po[ object ID
	 * @return				ProjopObject filled with the object's information
	 * 						or NULL in case of an error.
	 */
	public ProjopObject fromId(String objectType, int objectId) {
		logMessage(Logger.INFO, "RESTClient.restReadObjectFromId("+objectType+","+objectId+")", "Retreive a specific object", "");
		
		JSONObject dom = null;
		try {
			String urlPath = "/intranet-rest/"+objectType+"/"+objectId+"?format=json";
			dom = this.httpRequest("GET", urlPath, null);
		} catch (Exception e) {
			logMessage(Logger.ERROR, "RESTClient.readObjectFromId("+objectType+","+objectId+")", "Error reading server data", "");
			e.printStackTrace();
			return null;
		}

		// Extract object from. "data" should contain a list with exactly one instance.
		if (null == dom) { return null; }
		Object data = dom.get("data");
		if (!(data instanceof JSONArray)) {
			logMessage(Logger.ERROR, "RESTClient.readObjectFromId("+objectType+","+objectId+")", "Server returned invalid data.", data.toString());
			return null;
		}
		JSONArray projectList = (JSONArray)data;
		if (projectList.size() == 0) {
			logMessage(Logger.ERROR, "RESTClient.readObjectFromId("+objectType+","+objectId+")", "Server returned a list with zero objects", data.toString());
			return null;
		}
		if (projectList.size() > 1) {
			logMessage(Logger.WARNING, "RESTClient.readObjectFromId("+objectType+","+objectId+")", "Server returned more than one object, ignoring all but the first one.", data.toString());	
		}
		JSONObject oJSON = (JSONObject)projectList.get(0);
		ProjopObject o = new ProjopObject(objectType, oJSON);

		// Validity check: Make sure the new object contains an objectId
		int oid = o.getObjectId();
		if (oid != objectId) {
			logMessage(Logger.WARNING, "RESTClient.readObjectFromId("+objectType+","+objectId+")", "Server returned an object with an objectId different from the one requested: "+oid+" != "+objectId, data.toString());	
			String objectIdField = ProjopObject.getObjectIdField(objectType);
			o.set(objectIdField, ""+objectId);
		}
		
		// Add the new object to the list of instances of this object type
		ProjopObjectType.getObjectType(objectType).getInstances().put(new Integer(objectId), o);

		// show a log message
		logMessage(Logger.INFO, "RESTClient.readObjectFromId("+objectType+","+objectId+")", "Successfully retreived object", o.toString());

		return o;
	}

	/**
	 * GET a list of objects. The REST server returns objects always in the same format.
	 * 
	 * @param objectType	]po[ object type ("im_project", "im_hour", "user", ...)
	 * @param query			A SQL where clause with fields matching the object_type.
	 * 						For example, the "user" object defines the fields "email",
	 * 						"first_names" etc.
	 * @return				A list of ProjopObject who have matched the SQL query.
	 */
	public List<ProjopObject> fromURL(String objectType, String urlPath) {
		logMessage(Logger.INFO, "RESTClient.readObjectsFromURL("+objectType+","+urlPath+")", "Read objects from REST server", "");

		List<ProjopObject> myObjects = new ArrayList<ProjopObject>();
		JSONObject dom = httpRequest("GET", urlPath, null);

		if (dom == null) { return null; }
		Object data = dom.get("data");
		if (!(data instanceof JSONArray)) {
			logMessage(Logger.ERROR, "RESTClient.readObjectsFromURL("+objectType+","+urlPath+")", "Server returned an invalid list of objects.", data.toString());
		}
		
		// Iterate through the list of <row> entries, adding the data to the list
		JSONArray dataJSON = (JSONArray)data; 
		for (int i = 0; i < dataJSON.size(); i++) {
			JSONObject el = (JSONObject)dataJSON.get(i);
			ProjopObject p = new ProjopObject(objectType, el);
			myObjects.add(p);
		}

		logMessage(Logger.INFO, "RESTClient.readObjectsFromURL("+objectType+","+urlPath+")", "Successfully retreived "+myObjects.size()+" objects from REST server", "");
		return myObjects;
	}

	
	

	/**
	 * Create or update an object on the REST Server:
	 * 
	 * Accepts a newly setup ProjopObject that doesn't yet contain an objectId.
	 * It uses the generic "Create" POST operation to create a new object on 
	 * the ]po[ server and stores the returned objectId in the ProjopObject.
	 * 
	 * Creating new ]po[ objects requires a number of parameters that depend on 
	 * the object type. Please consult the ]po[ documentation for details on 
	 * these required fields.
	 * 
	 * @param objectType	The type of the new object to be created
	 * @param vars			A Hashtable with variable-value pairs to
	 * 						be sent to the server
	 * @return				Returns the objectId of the new ]po[ object.
	 */
	public void createUpdateObject(ProjopObject o) {
		
		// Convert into a string that can be passed directly to the ]po[ REST interface.
		String json = o.toJSONString();						// Convert into marshalling format
		String objectType = o.getObjectType();
		String urlPath = "/intranet-rest/"+objectType; 		// Determine the URL for the REST request.

		// Check if we are going to "create" or "update"
		// Create uses the generic urlPath, update ads the objectId.
		// These are standard REST conventions.
		int objectId = o.getObjectId();
		if (0 != objectId) {
			urlPath = urlPath + "/" + objectId;
		}
		
		// Perform the actual HTTP request to update/create the object in ]project-open[
		JSONObject response = null;
		try {
			StringBuffer buf = new StringBuffer(json);
			ByteArrayInputStream bis = new ByteArrayInputStream(buf.toString().getBytes("UTF-8"));
			response = this.httpRequest("POST", urlPath, bis);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Check the returned value. We'll need to extract the object_id and it to the object.
		if (response == null) {
			this.logMessage(Logger.ERROR, "Application Error", "Problems saving an object "+o.getObjectName(), "The server returned an empty reply");
			return;
		}

		// Check if the returned object contains a "success" field
		Object success = response.get("success");
		if (null == success) { 
			this.logMessage(Logger.ERROR, "Application Error", "Server returned JSON without 'success' field from: " + urlPath, response.toString());
			return; 
		}
		String successClass = success.getClass().getSimpleName();
		switch (successClass) {
		case "Boolean":
			Boolean successBoolean = (Boolean)success;
			if (successBoolean != true) {
				this.logMessage(Logger.ERROR, "Application Error", "JSON request returned a 'false' boolean success status from: " + urlPath, response.toString());
				return;			
			}
			break;
		case "String":
			String successString = (String)success;
			if (!"true".equals(successString)) {
				this.logMessage(Logger.ERROR, "Application Error", "JSON request returned a 'false' string success status from: " + urlPath, response.toString());
				return;			
			}			
			break;
		default:
			this.logMessage(Logger.ERROR, "Application Error", "JSON request returned a success status of type: " + successClass + " from: " + urlPath, response.toString());
			return;
		}		
			
		if (0 == objectId) {
			// We tried to create a new object.
			// Check if the JSON return data include an object_id field (which they should in case of a create)
			Object objectIdString = response.get("object_id");
			this.logMessage(Logger.INFO, "Received object_id", "CREATE: Received object_id from server.", ""+objectIdString);
			
			if (objectIdString instanceof Integer) {
				String idField = ProjopObject.getObjectIdField(o.getObjectType());
				objectId = Integer.parseInt(""+objectIdString);
				o.set(idField, ""+objectId);
				this.logMessage(Logger.INFO, "CREATE", "Successfully created the object #"+objectId + " via " + urlPath, "");
			} else {
				this.logMessage(Logger.ERROR, "Application Error", "CREATE: Received bad objectId from server: " + urlPath, ""+objectId);			
			}
		} else {
			this.logMessage(Logger.INFO, "UPDATE", "Successfully updated the object #"+objectId + " via " + urlPath, "");
		}
		
		
		return;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * Generic "list" request towards the REST server that will return a list of objects 
	 * according to the specified SQL query string.
	 * @param objectType	]po[ object type ("im_project", "im_hour", "user", ...)
	 * @param query			A SQL where clause with fields matching the object_type.
	 * 						For example, the "user" object defines the fields "email",
	 * 						"first_names" etc.
	 * @return				A list of ProjopObject who have matched the SQL query.
	 */
	public List<ProjopObject> fromQuery(String objectType, String query) {
		logMessage(Logger.INFO, "RESTClient.readObjectsFromQuery("+objectType+","+query+")", "Query REST server for objects matching the SQL where clause", "");

		String encodedQuery = null;
		try {
			encodedQuery = URLEncoder.encode(query, "UTF-8");			
		} catch (Exception e) {
			logMessage(Logger.ERROR, "RESTClient.readObjectsFromQuery("+objectType+","+query+")", "Error encoding query", query);
			e.printStackTrace();
			return null;
		}

		// http://demo.project-open.net/intranet-rest/user?format=json&query=username%20like%20'sys%'
		String urlPath = "/intranet-rest/" + objectType + "?format=json&query="+encodedQuery;
		List<ProjopObject> list = this.fromURL(objectType, urlPath);
		logMessage(Logger.INFO, "RESTClient.readObjectsFromQuery("+objectType+","+query+")", "Query REST server for objects matching the SQL where clause", list.toString());
		return list;
	}

	public int getMyUserId() { return myUserId;	}

}
