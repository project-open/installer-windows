package org.projectopen.rest;

import java.util.List;
import org.projectopen.debug.Logger;


/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

/**
 * Represents a ]project-open[ group object.
 */
public class ProjopGroup extends ProjopObject {
	
	 public ProjopGroup() {
			super("group");
	}
    	
	public String toString() {	
		String name = get("group_name");
		if (name == null) { name = super.toString(); }
		return name;
	}

	/**
	 * Query the REST server for the list of available groups in the system.
	 * 
	 * @return	List of ProjopObjects representing the current ]po[ groups.
	 */
	public List<ProjopObject> fromAll() {
		RESTClient rest = RESTClient.defaultInstance();
		List<ProjopObject> groups = rest.fromQuery("group", "");
		rest.logMessage(Logger.INFO, "RESTClient.restListGroups()", "List all groups in the ]po[ system", groups.toString());
		return groups;
	}

}
