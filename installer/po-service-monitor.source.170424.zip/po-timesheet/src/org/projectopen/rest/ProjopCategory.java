package org.projectopen.rest;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

import java.net.URLEncoder;
import java.util.*;

import org.json.simple.JSONObject;
import org.projectopen.debug.DomPrinter;
import org.projectopen.debug.Logger;
import org.w3c.dom.*;

@SuppressWarnings("unchecked")

public class ProjopCategory extends ProjopObject {

	private static Hashtable<String,List<ProjopObject>> categoriesPerType = new Hashtable<String,List<ProjopObject>>(); 
	
	public ProjopCategory() {
		super("im_category");
	}
 	
	/**
	 * Converts a list of ProjopCategory objects into an
	 * array of category strings suitable for a combo box.
	 * 
	 * @return	An array of formatted categories, suitable
	 * 			to be used in the JComboBox constructor.
	 */
	public static Object[] comboBoxCategories(String categoryType) {
		List<ProjopObject> categories = ProjopCategory.getCategoryObjectsFromType(categoryType);
		Iterator<ProjopObject> iter = categories.iterator();
		ArrayList<String> categoryStrings = new ArrayList<String>();
		while (iter.hasNext()) {
			ProjopCategory cat = (ProjopCategory)iter.next();
			String s = cat.get("category");
			int level = cat.get("tree_sortkey").length() / 8 - 1;
			for (int i = 0; i < level; i++) { s = "        "+s; }
			categoryStrings.add(s);
		}
		return categoryStrings.toArray();
	}

	/**
	 * Get the list of categories for a given category type.
	 * Example: "Intranet Project Status" returns "Open", "Closed", ...
	 * @param categoryType	The ]po[ category type.
	 * @return				A List of ProjopCategory objects.
	 */
	public static List<ProjopObject> getCategoryObjectsFromType(String categoryType) {
		RESTClient rest = RESTClient.defaultInstance();
		
		// Check the cache
		List<ProjopObject> categories = categoriesPerType.get(categoryType);
		if (null == categories) {
			// Nothing found in the cache - load from REST
			List<ProjopObject> categoryObjectList = new ArrayList<ProjopObject>();
			String categoryTypeEncoded = null;
			try {
				categoryTypeEncoded = URLEncoder.encode("'"+categoryType+"'", "UTF-8");
			} catch (Exception e) {	}
			String urlPath = "/intranet-reporting/view?format=json&report_code=rest_category_type&category_type="+categoryTypeEncoded;
			categories = rest.fromURL("im_category", urlPath);
			rest.logMessage(Logger.INFO, "RESTClient.restListCategories()", "List a category type", categories.toString());

			// Write into cache
			categoriesPerType.put(categoryType, categories);
		}
		return categories;
	}
	 
	/**
	 * Return the category_id of the input variable.
	 * The input can either be a 
	 * @param o
	 * @return
	 */
	public static int categoryIdFromCategory(String categoryType, Object o) {
		RESTClient rest = RESTClient.defaultInstance();
		if (null == o || null == categoryType) { return 0; }
		if (String.class != o.getClass()) {
			rest.logMessage(Logger.ERROR, "GUI", "Calling categoryIdFromCategory with a non-string object", o.toString());
			return 0;
		}
		
		String searchString = o.toString().trim();
		if (null == searchString) { return 0; }
		
		List<ProjopObject> categories = getCategoryObjectsFromType(categoryType);	
		Iterator<ProjopObject> iter = categories.iterator();
		while (iter.hasNext()) {
			ProjopObject cat = (ProjopObject)iter.next();
			String type = cat.get("category_type");
			if (!categoryType.equals(type)) { continue; }
			if (!searchString.equals(cat.get("category"))) { continue; }
			return cat.getObjectId();
		}
		return 0;
	}    

}
