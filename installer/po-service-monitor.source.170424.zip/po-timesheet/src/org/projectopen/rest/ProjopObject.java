package org.projectopen.rest;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

import java.util.*;
import org.json.simple.*;

@SuppressWarnings("unchecked")

/*
 * A ProjopObject mainly consists of a lists of variables
 */
public class ProjopObject implements Comparable<ProjopObject> {
	
	/** 
	 * Meta-information about the type of the object.
	 * Examples: "im_project", "im_company", ...
	 */
	private String objectType;
	
	/**
	 * Contents of the object, coming directly from the database.
	 * All values are stored as strings.
	 */
	private Hashtable<String,String> vars;

	protected ProjopObject parentObject = null;
	protected Vector<ProjopObject> childObjects = new Vector<ProjopObject>();

	
	/**
	 * Meta information in order to determine where to store the
	 * object_id, status_id and type_id information.
	 */
	private static String[] otypeFieldArray =  {"category", "im_hour", "im_project", "user"};
	private static String[] idFieldArray =     {"category_id", "hour_id", "project_id", "user_id"};
	private static String[] nameFieldArray =   {"category", "hour_id", "project_name", "username"};
	private static String[] statusFieldArray = {"", "", "project_status_id", ""};
	private static String[] typeFieldArray =   {"", "", "project_type_id", ""};
	
	/**
	 * Constructor: Every ProjopObject needs an object type.
	 * @param objectType	One of the ]po[ object types
	 * 						(im_project, user, ...)
	 */
	public ProjopObject(String objectType) {
		this.objectType = objectType;
		vars = new Hashtable<String,String>(20);
	}
	
	/**
	 * Constructor: Create from JSON object.
	 * @param objectType	One of the ]po[ object types (im_project, user, ...)
	 * @param o				JSONObject with a key-value map of Strings
	 */
    public ProjopObject(String objectType, JSONObject o) {
		this.objectType = objectType;
		vars = new Hashtable<String,String>(20);
	
		// Write key-value pairs from JSON to Hashmap
		if (null == o) { return; }
		Iterator<Map.Entry<String,String>> it = o.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry<String,String> pair = (Map.Entry<String,String>)it.next();
			String value = (String)pair.getValue();
			if (value.isEmpty()) continue;                     // skip empty fields
			String key = (String)pair.getKey();
			this.set(key, value);
			it.remove();
		}
    }

	
	/**
	 * Converts an object into a JSON representation.
	 * @return	A JSON string with a sorted list of all fields.
	 */
	public String toJSONString() {
		StringBuffer buf = new StringBuffer();
		List<String> l = new ArrayList<String>(vars.keySet());
		Collections.sort(l);
		Iterator<String> it = l.iterator();
    	while(it.hasNext()){
    		String var = it.next();
    		if (buf.length() > 0) buf.append(", ");
    		buf.append("\"" + var.toString() +"\": \"" + vars.get(var) + "\"");
    	}		
		String result = "{" + buf + "}\n";
		return result;
	}
	
	public ProjopObject getParent() {
		return parentObject;
	}

	public void setParent(ProjopObject parentObject) {
		this.parentObject = parentObject;
	}

	public void setChildObjects(Vector<ProjopObject> childObjects) {
		this.childObjects = childObjects;
	}

	public Vector<ProjopObject> getChildObjects() {
		return childObjects;
	}    
	
	/*
	 * Small helper for working with XML in string representation
	 */
	public static String htmlEncode(String s) {
		String result = s;
		result = result.replaceAll("&", "&amp;");
		result = result.replaceAll("<", "&lt;");
		result = result.replaceAll(">", "&gt;");
		result = result.replaceAll("\"", "&quot;");
				
		return result;		
	}
	
	/**
	 * Fetch a new ProjopObject based on objectType and ID.
	 * 
	 * @param objectType The ]po[ object type ("im_project", ...)
	 * @param oid		 The ]po[ objectId
	 * @return			 A ProjopObject with all available fields
	 */
	public static ProjopObject fromId(String objectType, int oid) {
		RESTClient rest = RESTClient.defaultInstance();
		ProjopObject o = rest.fromId(objectType, oid);
		return o; 
	}

	/**
	 * Get a value from the object.
	 * 
	 * @param varName
	 * @return String value of varName, or an empty string if it doesn't exist.
	 */
	public String get(String varName) {
		if (!(vars.containsKey(varName))) return "";				// Default: return an empty string.		
		return (String)vars.get(varName); 
	}

	/**
	 * Get a value from the object and convert to integer.
	 * Will throw an exception of that fails.
	 * @param varName
	 * @return String value of varName, or an empty string if it doesn't exist.
	 */
	public int getInt(String varName) {
		return Integer.parseInt(this.get(varName)); 
	}

	
	/**
	 * Set a value of the object.
	 * @param varName
	 * @param value
	 */
	public void set(String varName, String value) { 
		vars.put(varName, value); 
	}
	
	public String getObjectType() {	
		return objectType; 
	}
	
	/**
	 * Determines the position of an object type in the static list
	 * of object types.
	 * @param objectType Object type of the object
	 * @return The index of the object, or -1 if not supported or found.
	 */
	private static int getObjectTypeIdx(String objectType) {
		int idx = -1;
		for (int i = 0; i < otypeFieldArray.length; i++) { 
			if (otypeFieldArray[i] == objectType) {
				idx = i;
				break;
			}
		}
		return idx;
	}
	
	public static String getObjectIdField(String objectType) {
		int idx = getObjectTypeIdx(objectType);
		if (idx < 0) return "";
		return idFieldArray[idx];
	}
	
	/**
	 * Every ProjopObject should(!) have a field with the object
	 * type. Whether this is really the case depends on the data
	 * returned from the ]po[ REST interface, amongst other sources.
	 * @return the objectId of the object.
	 */
	public int getObjectId() {
		String field = getObjectIdField(this.objectType);
		if ("" == field) return 0;
		String value = this.get(field);
		if (null == value) return 0;
		if ("" == value) return 0;
		return Integer.parseInt(value);
	}

	/**
	 * Every ProjopObject should(!) have a field with the object
	 * name. Whether this is really the case depends on the data
	 * returned from the ]po[ REST interface, amongst other sources.
	 * @return the objectId of the object.
	 */
	public String getObjectName() {
		int idx = getObjectTypeIdx(this.objectType);
		if (idx < 0) return "";
		String field = nameFieldArray[idx];
		String value = this.get(field);
		if (null == value) return "";
		return value;
	}

	/**
	 * Most ProjopObject have a field with a statusId.
	 * Whether this is really the case depends on the data
	 * returned from the ]po[ REST interface, amongst other sources.
	 * @return the statusId of the object.
	 */
	public int getStatusId() {
		int idx = getObjectTypeIdx(this.objectType);
		if (idx < 0) return 0;
		String field = statusFieldArray[idx];
		String value = this.get(field);
		if (null == value) return 0;
		if ("" == value) return 0;
		return Integer.parseInt(value);
	}
	
	/**
	 * Most ProjopObject have a field with a typeId.
	 * Whether this is really the case depends on the data
	 * returned from the ]po[ REST interface, amongst other sources.
	 * @return the typeId of the object.
	 */
	public int getTypeId() {
		int idx = getObjectTypeIdx(this.objectType);
		if (idx < 0) return 0;
		String field = typeFieldArray[idx];
		String value = this.get(field);
		if (null == value) return 0;
		if ("" == value) return 0;
		return Integer.parseInt(value);
	}

	/**
	 * @return The raw key-value hash of the object.
	 */
	public Hashtable<String,String> getVars() { return vars; }

	

	// -----------------------------------------------------------------------
	// REST Application Level Methods
	// -----------------------------------------------------------------------


	
	/**
	 * Try to construct an object name from name field, type and objectId.
	 */
	public String toString() {
		String name = this.getObjectName();
		String type = this.getObjectType();
		int id = this.getObjectId();
		if (type != "") { name = name + " (" + type + ")"; }
		if (type != "") { name = name + " +" + id; }
		return name;
	}
	
	
	/**
	 * Implementation of Comparable...
	 */
	public int compareTo(ProjopObject o) {
		if (!(o instanceof ProjopObject)) { return -1; };
		ProjopObject oObj = (ProjopObject)o;
		
		int typeComp = this.objectType.compareTo(oObj.objectType);
		if (0 != typeComp) return typeComp;
		
		// The object type is the same...
		return this.getObjectName().compareTo(oObj.getObjectName());
	}
	
	/**
	 * Write object to REST Server:
	 * 
	 * Accepts a newly setup ProjopObject that doesn't yet contain an objectId.
	 * It uses the generic "Create" POST operation to create a new object on 
	 * the ]po[ server and stores the returned objectId in the ProjopObject.
	 * 
	 * Creating new ]po[ objects requires a number of parameters that depend on 
	 * the object type. Please consult the ]po[ documentation for details on 
	 * these required fields.
	 * 
	 * @param objectType	The type of the new object to be created
	 * @param vars			A Hashtable with variable-value pairs to
	 * 						be sent to the server
	 * @return				Returns the objectId of the new ]po[ object.
	 */
	public void persist() {
		RESTClient rest = RESTClient.defaultInstance();
		rest.createUpdateObject(this);
	}
	
	
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	ProjopObject o1 = new ProjopObject("im_project");
    	
    	System.out.println("Retriving all keys from the Hashtable");
    	Enumeration<String> e = o1.getVars().keys();
    	while( e.hasMoreElements() ){
    		System.out.println( e.nextElement() );
    	}
    }
}
