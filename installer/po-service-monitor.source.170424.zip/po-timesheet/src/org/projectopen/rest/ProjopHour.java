package org.projectopen.rest;

import java.util.List;
import org.json.simple.JSONObject;

/*
 * Copyright (C) 2010 ]project-open[ 
 *
 * This program is free software. You can redistribute it
 * and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option)
 * any later version. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * @author Frank Bergmann (frank.bergmann@project-open.com)
 * 
 */

public class ProjopHour extends ProjopObject {
	public ProjopHour() {
			super("im_hour");
	}
	public ProjopHour(JSONObject el) {
		super("im_hour", el);				// ]po[ name of this object type
	}
	
	/**
	 * Query the REST server the hours logged by the current user today.  
	 * @return	A list of ProjectHour objects
	 */
	public static List<ProjopObject> fromToday() {
		RESTClient rest = RESTClient.defaultInstance();
		String urlPath = "/intranet-reporting/view?format=json&report_code=rest_my_hours";
		return rest.fromURL("im_hour", urlPath);
	}  

}
